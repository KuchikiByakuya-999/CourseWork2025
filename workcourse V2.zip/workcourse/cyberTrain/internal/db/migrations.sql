
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS password_challenges (
    id SERIAL PRIMARY KEY,
    password VARCHAR(255) NOT NULL,
    hint TEXT,
    strength INT CHECK (strength >= 1 AND strength <= 5),
    is_weak BOOLEAN NOT NULL,
    category VARCHAR(50),
    difficulty INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS phishing_mails (
    id SERIAL PRIMARY KEY,
    level INT CHECK (level >= 0 AND level <= 2),
    channel VARCHAR(50),
    sender VARCHAR(255),
    subject VARCHAR(255),
    body TEXT,
    url VARCHAR(255),
    has_attach BOOLEAN,
    is_phishing BOOLEAN,
    explanation TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS phishing_red_flags (
    id SERIAL PRIMARY KEY,
    mail_id INT REFERENCES phishing_mails(id) ON DELETE CASCADE,
    text TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS phishing_results (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES users(id),
    mode INT,
    level INT,
    score INT,
    correct INT,
    wrong INT,
    skipped INT,
    max_combo INT,
    duration INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS network_incidents (
    id SERIAL PRIMARY KEY,
    type VARCHAR(50),
    logs TEXT[],
    action VARCHAR(50),
    difficulty INT,
    description TEXT,
    real_impact TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS network_results (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES users(id),
    incident_id INT REFERENCES network_incidents(id),
    action_chosen VARCHAR(50),
    correct BOOLEAN,
    score INT,
    time_spent INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS game_results (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES users(id),
    game_type VARCHAR(50),
    score INT,
    max_score INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS cryptochallenges (
    id SERIAL PRIMARY KEY,
    ciphertype VARCHAR(50) NOT NULL,
    ciphertext TEXT NOT NULL,
    plaintext TEXT NOT NULL,
    hint TEXT,
    keyvalue VARCHAR(255),
    difficulty INT CHECK (difficulty >= 1 AND difficulty <= 3),
    createdat TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS cryptoresults (
    id SERIAL PRIMARY KEY,
    userid INT REFERENCES users(id),
    challengeid INT REFERENCES cryptochallenges(id),
    correct BOOLEAN,
    timespent INT,
    attempts INT,
    createdat TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_cryptochallenges_difficulty ON cryptochallenges(difficulty);
CREATE INDEX IF NOT EXISTS idx_cryptoresults_user ON cryptoresults(userid);

CREATE TABLE IF NOT EXISTS crypto_results (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES users(id),
    challenge_id INT REFERENCES crypto_challenges(id),
    correct BOOLEAN,
    time_spent INT,
    attempts INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS malware_challenges (
    id SERIAL PRIMARY KEY,
    malware_type VARCHAR(50),
    behavior TEXT,
    iocs TEXT[],
    symptoms TEXT[],
    mitigation TEXT[],
    difficulty INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS malware_results (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES users(id),
    challenge_id INT REFERENCES malware_challenges(id),
    malware_types_found TEXT[],
    actions_found TEXT[],
    correct INT,
    wrong INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS social_engineering_challenges (
    id SERIAL PRIMARY KEY,
    scenario_type VARCHAR(50),
    scenario TEXT NOT NULL,
    correct_answers TEXT[] NOT NULL,
    wrong_answers TEXT[],
    explanation TEXT,
    difficulty INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS social_engineering_results (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES users(id),
    challenge_id INT REFERENCES social_engineering_challenges(id),
    answer_chosen VARCHAR(255),
    correct BOOLEAN,
    time_spent INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS malware_detection_challenges (
    id SERIAL PRIMARY KEY,
    artifact_name VARCHAR(255),
    hash_value VARCHAR(255),
    is_clean BOOLEAN,
    threat_name VARCHAR(255),
    evidence TEXT[],
    difficulty INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS malware_detection_results (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES users(id),
    challenge_id INT REFERENCES malware_detection_challenges(id),
    decision VARCHAR(50),
    correct BOOLEAN,
    confidence INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS achievements (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES users(id),
    achievement_type VARCHAR(50),
    description TEXT,
    unlocked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, achievement_type)
);

CREATE TABLE IF NOT EXISTS user_stats (
    id SERIAL PRIMARY KEY,
    user_id INT UNIQUE REFERENCES users(id),
    total_games_played INT DEFAULT 0,
    total_score INT DEFAULT 0,
    best_streak INT DEFAULT 0,
    modules_completed TEXT[],
    last_played TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ==========================================
-- ИНДЕКСЫ ДЛЯ ПРОИЗВОДИТЕЛЬНОСТИ
-- ==========================================

CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_password_challenges_difficulty ON password_challenges(difficulty);
CREATE INDEX IF NOT EXISTS idx_phishing_mails_level ON phishing_mails(level);
CREATE INDEX IF NOT EXISTS idx_network_incidents_type ON network_incidents(type);
CREATE INDEX IF NOT EXISTS idx_crypto_challenges_difficulty ON crypto_challenges(difficulty);
CREATE INDEX IF NOT EXISTS idx_malware_challenges_type ON malware_challenges(malware_type);
CREATE INDEX IF NOT EXISTS idx_game_results_user ON game_results(user_id);
CREATE INDEX IF NOT EXISTS idx_phishing_results_user ON phishing_results(user_id);
CREATE INDEX IF NOT EXISTS idx_network_results_user ON network_results(user_id);
CREATE INDEX IF NOT EXISTS idx_crypto_results_user ON crypto_results(user_id);
CREATE INDEX IF NOT EXISTS idx_malware_results_user ON malware_results(user_id);
CREATE INDEX IF NOT EXISTS idx_forensics_results_user ON forensics_results(user_id);
CREATE INDEX IF NOT EXISTS idx_vulnerability_results_user ON vulnerability_results(user_id);
CREATE INDEX IF NOT EXISTS idx_incident_response_results_user ON incident_response_results(user_id);
CREATE INDEX IF NOT EXISTS idx_achievements_user ON achievements(user_id);