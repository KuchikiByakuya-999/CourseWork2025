package repository

import (
	"context"
	"cyber-skeleton/internal/domain"
	"database/sql"
)

type passwordRepository struct{ db *sql.DB }

func NewPasswordRepository(db *sql.DB) PasswordRepository {
	return &passwordRepository{db: db}
}

func (r *passwordRepository) GetRandomChallenges(ctx context.Context, count int) ([]domain.PasswordChallenge, error) {
	rows, err := r.db.QueryContext(ctx,
		`SELECT id, password, hint, strength, is_weak
         FROM password_challenges
         ORDER BY RANDOM() LIMIT $1`, count)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var res []domain.PasswordChallenge
	for rows.Next() {
		var ch domain.PasswordChallenge
		if err := rows.Scan(&ch.ID, &ch.Password, &ch.Hint, &ch.Strength, &ch.IsWeak); err != nil {
			return nil, err
		}
		res = append(res, ch)
	}
	return res, rows.Err()
}
