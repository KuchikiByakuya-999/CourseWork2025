package screens

import (
	"context"
	"cyber-skeleton/internal/domain"
	"cyber-skeleton/internal/security"
	"cyber-skeleton/internal/usecase"
	"errors"
	"strings"

	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/container"
	"fyne.io/fyne/v2/dialog"
	"fyne.io/fyne/v2/widget"
)

type LoginRouter interface {
	NavigateToDashboard(u *domain.User)
	ShowRegisterScreen()
}

type LoginScreen struct {
	window fyne.Window
	router LoginRouter
	uc     *usecase.AuthUsecase
}

func NewLoginScreen(w fyne.Window, r LoginRouter, uc *usecase.AuthUsecase) *LoginScreen {
	return &LoginScreen{window: w, router: r, uc: uc}
}

func (s *LoginScreen) Build() fyne.CanvasObject {
	loginEntry := widget.NewEntry()
	loginEntry.SetPlaceHolder("Логин или email")

	passwordEntry := widget.NewPasswordEntry()
	passwordEntry.SetPlaceHolder("Пароль")

	loginBtn := widget.NewButton("Войти", func() {
		login := strings.TrimSpace(loginEntry.Text)
		pass := passwordEntry.Text

		if login == "" || pass == "" {
			dialog.ShowError(errors.New("заполните все поля"), s.window)
			return
		}

		login = security.SanitizeInput(login)
		pass = security.SanitizeInput(pass)

		if len(login) > 64 {
			login = login[:64]
		}
		if len(pass) > 128 {
			pass = pass[:128]
		}

		u, err := s.uc.Login(context.Background(), login, pass)
		if err != nil {
			dialog.ShowError(err, s.window)
			return
		}

		s.router.NavigateToDashboard(u)
	})

	registerLink := widget.NewButton("Создать аккаунт", func() {
		s.router.ShowRegisterScreen()
	})

	form := container.NewVBox(
		widget.NewLabelWithStyle("Вход", fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
		widget.NewLabel("Логин или email"),
		loginEntry,
		widget.NewLabel("Пароль"),
		passwordEntry,
		loginBtn,
		registerLink,
	)

	return container.NewCenter(form)
}
