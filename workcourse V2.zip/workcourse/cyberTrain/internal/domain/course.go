package domain

type CourseStepType int

const (
	CourseStepTheory CourseStepType = iota
	CourseStepGame
)

type CourseStep struct {
	ID       string
	Title    string
	Module   string
	StepType CourseStepType
	GameCode string
	MinScore int
}

type CourseChapter struct {
	ID    string
	Title string
	Steps []CourseStep
}
