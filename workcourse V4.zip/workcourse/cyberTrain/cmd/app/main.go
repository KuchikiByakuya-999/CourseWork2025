package main

import (
	"cyber-skeleton/internal/config"
	"cyber-skeleton/internal/db"
	"cyber-skeleton/internal/delivery/fyneui"
	"cyber-skeleton/internal/repository"
	"cyber-skeleton/internal/usecase"
	"log"

	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/app"
)

func main() {
	cfg, err := config.Load()
	if err != nil {
		log.Fatal(err)
	}

	postgres, err := db.NewPostgres(cfg.DatabaseURL)
	if err != nil {
		log.Fatal(err)
	}

	defer postgres.Close()

	var repo repository.Repository
	repo = repository.NewPostgresRepository(postgres.DB)
	phishRepo := repository.NewPhishingRepository(postgres.DB)
	passwordRepo := repository.NewPasswordRepository(postgres.DB)
	networkRepo := repository.NewNetworkRepository(postgres.DB)

	authUC := usecase.NewAuthUsecase(repo)
	gameUC := usecase.NewGameUsecase(repo)
	phishUC := usecase.NewPhishingUsecase(phishRepo)
	passwordUC := usecase.NewPasswordUsecase(passwordRepo)
	networkUC := usecase.NewNetworkUsecase(networkRepo)

	a := app.NewWithID("cyber.skeleton")
	w := a.NewWindow("Cyber Skeleton - Киберзащита")
	w.Resize(fyne.NewSize(1366, 768))
	w.CenterOnScreen()
	w.SetMaster()

	router := fyneui.NewRouter(
		w,
		authUC,
		phishUC,
		passwordUC,
		networkUC,
		gameUC,
	)

	router.NavigateToAuth()
	w.ShowAndRun()
}
