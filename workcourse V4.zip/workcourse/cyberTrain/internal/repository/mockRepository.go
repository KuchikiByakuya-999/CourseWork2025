package repository

import (
	"context"
	"cyber-skeleton/internal/domain"
	"errors"
	"strings"
	"sync"
)

type MockRepository struct {
	mu      sync.RWMutex
	users   map[int64]*domain.User
	byUN    map[string]int64
	byEM    map[string]int64
	nextID  int64
	results []domain.GameResult
}

func NewMockRepository() Repository {
	return &MockRepository{
		users:   make(map[int64]*domain.User),
		byUN:    make(map[string]int64),
		byEM:    make(map[string]int64),
		nextID:  1,
		results: make([]domain.GameResult, 0),
	}
}

func (m *MockRepository) Close() error { return nil }

func (m *MockRepository) CreateUser(ctx context.Context, username, email, passwordHash string) (*domain.User, error) {
	m.mu.Lock()
	defer m.mu.Unlock()

	if _, ok := m.byUN[username]; ok {
		return nil, errors.New("логин уже используется")
	}
	if _, ok := m.byEM[email]; ok {
		return nil, errors.New("email уже используется")
	}

	id := m.nextID
	m.nextID++

	u := &domain.User{
		ID:           id,
		Username:     username,
		Email:        email,
		PasswordHash: passwordHash,
	}
	m.users[id] = u
	m.byUN[username] = id
	m.byEM[email] = id

	return u, nil
}

func (m *MockRepository) GetUserByUsername(ctx context.Context, username string) (*domain.User, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()

	id, ok := m.byUN[username]
	if !ok {
		return nil, errors.New("пользователь не найден")
	}
	return m.users[id], nil
}

func (m *MockRepository) GetUserByLoginOrEmail(ctx context.Context, loginOrEmail string) (*domain.User, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()

	if id, ok := m.byUN[loginOrEmail]; ok {
		return m.users[id], nil
	}
	for em, id := range m.byEM {
		if strings.EqualFold(em, loginOrEmail) {
			return m.users[id], nil
		}
	}
	return nil, errors.New("пользователь не найден")
}

func (m *MockRepository) SaveGameResult(ctx context.Context, res *domain.GameResult) error {
	m.mu.Lock()
	defer m.mu.Unlock()

	res.ID = int64(len(m.results) + 1)
	m.results = append(m.results, *res)
	return nil
}

func (m *MockRepository) GetLastResults(ctx context.Context, userID int64, limit int) ([]domain.GameResult, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()

	var out []domain.GameResult
	for i := len(m.results) - 1; i >= 0 && len(out) < limit; i-- {
		if m.results[i].UserID == userID {
			out = append(out, m.results[i])
		}
	}
	return out, nil
}

func (m *MockRepository) GetXP(ctx context.Context, userID int64) (int, error) {
	return 0, nil
}

func (m *MockRepository) GetModuleStats(ctx context.Context, userID int64) (map[string]domain.ModuleStat, error) {
	return map[string]domain.ModuleStat{}, nil
}
