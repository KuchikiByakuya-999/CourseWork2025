package repository

import (
	"context"
	"cyber-skeleton/internal/domain"
	"database/sql"
)

type CryptoRepository interface {
	GetRandomChallenges(ctx context.Context, count int, difficulty int) ([]domain.CryptoChallenge, error)
	SaveResult(ctx context.Context, userID int64, challengeID int64, correct bool, attempts int, timeSpent int64) error
}

type PostgresCryptoRepo struct {
	db *sql.DB
}

func NewPostgresCryptoRepo(db *sql.DB) *PostgresCryptoRepo {
	return &PostgresCryptoRepo{db: db}
}

func (r *PostgresCryptoRepo) GetRandomChallenges(ctx context.Context, count int, difficulty int) ([]domain.CryptoChallenge, error) {
	query := `
        SELECT id, ciphertype, ciphertext, plaintext, hint, keyvalue, difficulty
        FROM cryptochallenges
        WHERE difficulty = $1
        ORDER BY RANDOM()
        LIMIT $2
    `

	rows, err := r.db.QueryContext(ctx, query, difficulty, count)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var challenges []domain.CryptoChallenge
	for rows.Next() {
		var ch domain.CryptoChallenge
		err := rows.Scan(
			&ch.ID,
			&ch.CipherType,
			&ch.Ciphertext,
			&ch.Plaintext,
			&ch.Hint,
			&ch.Key,
			&ch.Difficulty,
		)
		if err != nil {
			continue
		}
		challenges = append(challenges, ch)
	}

	if len(challenges) == 0 {
		gen := NewCryptoGenerator()
		challenges = gen.GenerateMany(count, difficulty)

		go r.saveChallenges(context.Background(), challenges)
	}

	return challenges, nil
}

func (r *PostgresCryptoRepo) saveChallenges(ctx context.Context, challenges []domain.CryptoChallenge) {
	query := `
        INSERT INTO cryptochallenges (ciphertype, ciphertext, plaintext, hint, keyvalue, difficulty)
        VALUES ($1, $2, $3, $4, $5, $6)
        ON CONFLICT DO NOTHING
    `

	for _, ch := range challenges {
		r.db.ExecContext(ctx, query, ch.CipherType, ch.Ciphertext, ch.Plaintext, ch.Hint, ch.Key, ch.Difficulty)
	}
}

func (r *PostgresCryptoRepo) SaveResult(ctx context.Context, userID int64, challengeID int64, correct bool, attempts int, timeSpent int64) error {
	query := `
        INSERT INTO cryptoresults (userid, challengeid, correct, timespent, attempts, createdat)
        VALUES ($1, $2, $3, $4, $5, NOW())
    `

	_, err := r.db.ExecContext(ctx, query, userID, challengeID, correct, timeSpent, attempts)
	return err
}
