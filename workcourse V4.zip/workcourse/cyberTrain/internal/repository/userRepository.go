package repository

import (
	"context"
	"cyber-skeleton/internal/domain"
	"database/sql"
	"time"
)

type postgresRepository struct {
	db *sql.DB
}

func NewPostgresRepository(db *sql.DB) Repository {
	return &postgresRepository{db: db}
}

func (r *postgresRepository) Close() error {
	return r.db.Close()
}

func (r *postgresRepository) CreateUser(ctx context.Context, username, email, passwordHash string) (*domain.User, error) {
	var id int64
	err := r.db.QueryRowContext(ctx,
		`INSERT INTO users (username, email, password_hash) VALUES ($1,$2,$3) RETURNING id`,
		username, email, passwordHash,
	).Scan(&id)
	if err != nil {
		return nil, err
	}
	return &domain.User{
		ID:       id,
		Username: username,
		Email:    email,
	}, nil
}

func (r *postgresRepository) GetUserByUsername(ctx context.Context, username string) (*domain.User, error) {
	u := &domain.User{}
	err := r.db.QueryRowContext(ctx,
		`SELECT id, username, email, password_hash FROM users WHERE username = $1`,
		username,
	).Scan(&u.ID, &u.Username, &u.Email, &u.PasswordHash)
	if err != nil {
		return nil, err
	}
	return u, nil
}

func (r *postgresRepository) GetUserByLoginOrEmail(ctx context.Context, loginOrEmail string) (*domain.User, error) {
	u := &domain.User{}
	err := r.db.QueryRowContext(ctx,
		`SELECT id, username, email, password_hash FROM users 
         WHERE username = $1 OR email = $1`,
		loginOrEmail,
	).Scan(&u.ID, &u.Username, &u.Email, &u.PasswordHash)
	if err != nil {
		return nil, err
	}
	return u, nil
}

func (r *postgresRepository) SaveGameResult(ctx context.Context, res *domain.GameResult) error {
	_, err := r.db.ExecContext(ctx,
		`INSERT INTO game_results (user_id, game_code, score, max_score, created_at)
         VALUES ($1,$2,$3,$4,NOW())`,
		res.UserID, res.GameCode, res.Score, res.MaxScore,
	)
	return err
}

func (r *postgresRepository) GetLastResults(ctx context.Context, userID int64, limit int) ([]domain.GameResult, error) {
	rows, err := r.db.QueryContext(ctx,
		`SELECT id, user_id, game_code, score, max_score, created_at
         FROM game_results
         WHERE user_id = $1
         ORDER BY created_at DESC
         LIMIT $2`,
		userID, limit,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var res []domain.GameResult
	for rows.Next() {
		var gr domain.GameResult
		if err := rows.Scan(&gr.ID, &gr.UserID, &gr.GameCode, &gr.Score, &gr.MaxScore, &gr.CreatedAt); err != nil {
			return nil, err
		}
		res = append(res, gr)
	}
	return res, rows.Err()
}

func (r *postgresRepository) GetXP(ctx context.Context, userID int64) (int, error) {
	var xp int
	err := r.db.QueryRowContext(ctx,
		`SELECT COALESCE(SUM(score), 0) FROM game_results WHERE user_id = $1`,
		userID,
	).Scan(&xp)
	return xp, err
}

func (r *postgresRepository) GetModuleStats(ctx context.Context, userID int64) (map[string]domain.ModuleStat, error) {
	rows, err := r.db.QueryContext(ctx,
		`SELECT game_code, score, created_at
		   FROM game_results
		  WHERE user_id = $1
		  ORDER BY created_at`,
		userID,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	stats := make(map[string]domain.ModuleStat)
	for rows.Next() {
		var code string
		var score int
		var ts time.Time
		if err := rows.Scan(&code, &score, &ts); err != nil {
			return nil, err
		}
		st := stats[code]
		st.GameCode = code
		st.Attempts++
		if score > st.BestScore {
			st.BestScore = score
		}
		st.LastScore = score
		st.TotalScore += score
		st.LastPlayed = ts
		stats[code] = st
	}
	return stats, rows.Err()
}
