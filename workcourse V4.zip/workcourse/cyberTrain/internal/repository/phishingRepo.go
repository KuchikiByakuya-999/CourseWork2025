package repository

import (
	"context"
	"cyber-skeleton/internal/domain"
	"database/sql"
)

type PhishingRepository interface {
	GetMails(ctx context.Context, lvl domain.PhishingLevel) ([]domain.PhishingMail, error)
	SaveResult(ctx context.Context, res *domain.PhishingResult) error
}

type phishingRepo struct {
	db *sql.DB
}

func NewPhishingRepository(db *sql.DB) PhishingRepository {
	return &phishingRepo{db: db}
}

func (r *phishingRepo) GetMails(ctx context.Context, lvl domain.PhishingLevel) ([]domain.PhishingMail, error) {
	rows, err := r.db.QueryContext(ctx, `
		SELECT id, level, channel, sender, subject, body, url, has_attach, is_phishing, explanation
		FROM phishing_mails
		WHERE level = $1
		ORDER BY id
	`, int(lvl))
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var mails []domain.PhishingMail
	for rows.Next() {
		var m domain.PhishingMail
		var lvlInt int
		var urlNull sql.NullString
		var explanationNull sql.NullString

		err := rows.Scan(
			&m.ID,
			&lvlInt,
			&m.Channel,
			&m.From,
			&m.Subject,
			&m.Body,
			&urlNull,
			&m.HasAttach,
			&m.IsPhishing,
			&explanationNull,
		)
		if err != nil {
			return nil, err
		}

		m.Level = domain.PhishingLevel(lvlInt)

		if urlNull.Valid {
			m.Url = urlNull.String
		}
		if explanationNull.Valid {
			m.Explanation = explanationNull.String
		}

		flags, err := r.loadRedFlags(ctx, m.ID)
		if err != nil {
			return nil, err
		}
		m.RedFlags = flags

		mails = append(mails, m)
	}
	return mails, rows.Err()
}

func (r *phishingRepo) loadRedFlags(ctx context.Context, mailID int64) ([]string, error) {
	rows, err := r.db.QueryContext(ctx, `
        SELECT text FROM phishing_red_flags WHERE mail_id = $1 ORDER BY id
    `, mailID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var res []string
	for rows.Next() {
		var t string
		if err := rows.Scan(&t); err != nil {
			return nil, err
		}
		res = append(res, t)
	}
	return res, rows.Err()
}

func (r *phishingRepo) SaveResult(ctx context.Context, res *domain.PhishingResult) error {
	_, err := r.db.ExecContext(ctx, `
        INSERT INTO phishing_results (user_id, mode, level, score, correct, wrong, skipped, max_combo, duration)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
    `,
		res.UserID,
		int(res.Mode),
		int(res.Level),
		res.Score,
		res.Correct,
		res.Wrong,
		res.Skipped,
		res.MaxCombo,
		int(res.Duration.Seconds()),
	)
	return err
}
