package domain

import "time"

type PhishingLevel int

const (
	PhishingLevelEasy PhishingLevel = iota + 1
	PhishingLevelMedium
	PhishingLevelHard
)

type PhishingMode int

const (
	PhishingModeTraining PhishingMode = iota + 1
	PhishingModeChallenge
	PhishingModeCareer
)

type PhishAction int

const (
	ActionReportPhish PhishAction = iota
	ActionDelete
	ActionAllow
	ActionQuarantine
)

type PhishingMail struct {
	ID          int64
	Level       PhishingLevel
	Channel     string
	From        string
	Subject     string
	Body        string
	Url         string
	HasAttach   bool
	IsPhishing  bool
	Explanation string
	RedFlags    []string
}

type PhishingResult struct {
	ID        int64
	UserID    int64
	Mode      PhishingMode
	Level     PhishingLevel
	Score     int
	Correct   int
	Wrong     int
	Skipped   int
	MaxCombo  int
	Duration  time.Duration
	CreatedAt time.Time
}
