package domain

type Achievement struct {
	Code        string
	Title       string
	Description string
	Unlocked    bool
}
