package usecase

import "cyber-skeleton/internal/domain"

type CourseUsecase struct {
	chapters []domain.CourseChapter
}

func NewCourseUsecase() *CourseUsecase {
	return &CourseUsecase{
		chapters: []domain.CourseChapter{
			{
				ID:    "ch1",
				Title: "Введение и пароли",
				Steps: []domain.CourseStep{
					{ID: "intro-passwords", Title: "Основы надёжных паролей", Module: "passwords", StepType: domain.CourseStepTheory},
					{ID: "game-passwords-basic", Title: "Практика: базовые пароли", Module: "passwords", StepType: domain.CourseStepGame, GameCode: "passwords", MinScore: 150},
				},
			},
			{
				ID:    "ch2",
				Title: "Фишинг и социнженерия",
				Steps: []domain.CourseStep{
					{ID: "intro-phishing", Title: "Как распознать фишинг", Module: "phishing", StepType: domain.CourseStepTheory},
					{ID: "game-phishing-easy", Title: "Практика: простые письма", Module: "phishing", StepType: domain.CourseStepGame, GameCode: "phishing", MinScore: 200},
				},
			},
			{
				ID:    "ch3",
				Title: "Сетевые инциденты",
				Steps: []domain.CourseStep{
					{ID: "intro-network", Title: "Основы реагирования на инциденты", Module: "network", StepType: domain.CourseStepTheory},
					{ID: "game-network-basic", Title: "Практика: базовые инциденты", Module: "network", StepType: domain.CourseStepGame, GameCode: "network", MinScore: 200},
				},
			},
		},
	}
}

func (c *CourseUsecase) Chapters() []domain.CourseChapter {
	return c.chapters
}
