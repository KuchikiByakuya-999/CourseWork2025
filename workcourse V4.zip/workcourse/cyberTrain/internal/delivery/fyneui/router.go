package fyneui

import (
	"cyber-skeleton/internal/delivery/fyneui/screens"
	"cyber-skeleton/internal/domain"
	"cyber-skeleton/internal/usecase"

	"fyne.io/fyne/v2"
)

type Router struct {
	w            fyne.Window
	curUser      *domain.User
	phishingUC   *usecase.PhishingUsecase
	passwordUC   *usecase.PasswordUsecase
	networkUC    *usecase.NetworkUsecase
	gameUC       *usecase.GameUsecase
	authUC       *usecase.AuthUsecase
	cryptoUC     *usecase.CryptoUsecase
	themeManager *screens.ThemeManager
}

func NewRouter(
	w fyne.Window,
	authUC *usecase.AuthUsecase,
	phishingUC *usecase.PhishingUsecase,
	passwordUC *usecase.PasswordUsecase,
	networkUC *usecase.NetworkUsecase,
	gameUC *usecase.GameUsecase,
) *Router {
	return &Router{
		w:            w,
		authUC:       authUC,
		phishingUC:   phishingUC,
		passwordUC:   passwordUC,
		networkUC:    networkUC,
		gameUC:       gameUC,
		cryptoUC:     usecase.NewCryptoUsecase(),
		themeManager: screens.NewThemeManager(),
	}
}

func (r *Router) NavigateToAuth() {
	screen := screens.NewLoginScreen(r.w, r, r.authUC)
	r.w.SetContent(screen.Build())
}

func (r *Router) ShowLoginScreen() {
	r.NavigateToAuth()
}

func (r *Router) ShowRegisterScreen() {
	r.NavigateToRegister()
}

func (r *Router) NavigateToRegister() {
	screen := screens.NewRegisterScreen(r.w, r, r.authUC)
	r.w.SetContent(screen.Build())
}

func (r *Router) NavigateToDashboard(u *domain.User) {
	if u == nil {
		u = r.curUser
	}
	r.curUser = u
	screen := screens.NewDashboardScreenV2(r.w, r, u, r.phishingUC, r.passwordUC, r.networkUC, r.gameUC, r.themeManager)
	r.w.SetContent(screen.Build())
}

func (r *Router) NavigateToProfile(u *domain.User) {
	if u == nil {
		u = r.curUser
	}
	screen := screens.NewProfileScreenV2(r.w, r, u, r.gameUC)
	r.w.SetContent(screen.Build())
}

func (r *Router) NavigateToPhishing(u *domain.User, mode domain.PhishingMode, level domain.PhishingLevel) {
	if u == nil {
		u = r.curUser
	}
	screen := screens.NewPhishingScreen(r.w, r, u, r.phishingUC, mode, level)
	r.w.SetContent(screen.Build())
}

func (r *Router) NavigateToPhishingGame() {
	r.NavigateToPhishing(r.curUser, 1, domain.PhishingLevelEasy)
}

func (r *Router) NavigateToPassword(u *domain.User) {
	if u == nil {
		u = r.curUser
	}
	screen := screens.NewPasswordScreenV2(r.w, r, u, r.passwordUC, r.gameUC)
	r.w.SetContent(screen.Build())
}

func (r *Router) NavigateToPasswordGame() {
	r.NavigateToPassword(r.curUser)
}

func (r *Router) NavigateToNetwork(u *domain.User) {
	if u == nil {
		u = r.curUser
	}
	screen := screens.NewNetworkScreenV2(r.w, r, u, r.networkUC, r.gameUC, r.themeManager)
	r.w.SetContent(screen.Build())
}

func (r *Router) NavigateToNetworkGame() {
	r.NavigateToNetwork(r.curUser)
}

func (r *Router) NavigateToCrypto(u *domain.User) {
	if u == nil {
		u = r.curUser
	}
	screen := screens.NewCryptoScreen(r.w, r, u, r.gameUC)
	r.w.SetContent(screen.Build())
}

func (r *Router) NavigateToCryptoGame() {
	r.NavigateToCrypto(r.curUser)
}

func (r *Router) NavigateToMalware(u *domain.User) {
	if u == nil {
		u = r.curUser
	}
	screen := screens.NewMalwareScreen(r.w, r, u, r.gameUC)
	r.w.SetContent(screen.Build())
}

func (r *Router) NavigateToMalwareGame() {
	r.NavigateToMalware(r.curUser)
}
