package screens

import (
	"context"
	"cyber-skeleton/internal/domain"
	"cyber-skeleton/internal/usecase"
	"fmt"
	"math/rand"
	"strings"
	"time"

	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/container"
	"fyne.io/fyne/v2/dialog"
	"fyne.io/fyne/v2/layout"
	"fyne.io/fyne/v2/widget"
)

type CryptoRouter interface {
	NavigateToDashboard(u *domain.User)
}

type CryptoScreen struct {
	w          fyne.Window
	router     CryptoRouter
	user       *domain.User
	gameUC     *usecase.GameUsecase
	showTheory bool

	challenges []CryptoChallenge
	cur        int

	start    time.Time
	cancel   context.CancelFunc
	score    int
	correct  int
	wrong    int
	combo    int
	maxCombo int

	timerLbl      *widget.Label
	scoreLbl      *widget.Label
	comboLbl      *widget.Label
	list          *widget.List
	ciphertextLbl *widget.Label
	cipherTypeLbl *widget.Label
	answerEntry   *widget.Entry
}

type CryptoChallenge struct {
	CipherType string
	Ciphertext string
	Plaintext  string
	Hint       string
	Difficulty int
}

var cryptoTheoryText = `ТЕОРИЯ: КЛАССИЧЕСКИЕ ШИФРЫ


ЧТО ТАКОЕ КРИПТОГРАФИЯ?
Наука о защите информации. Основные операции:
• Шифрование — преобразование открытого текста в зашифрованный
• Дешифрование — обратное преобразование с ключом
• Ключ — секретный параметр алгоритма



---


## ШИФР ЦЕЗАРЯ (Caesar Cipher)

Принцип: каждая буква сдвигается на фиксированное число позиций.

Пример (сдвиг +3):
• A → D, B → E, C → F
• "HELLO" → "KHOOR"


Как расшифровать:
• Попробуйте разные сдвиги от 1 до 25
• Самая частая буква в английском — E, в русском — О
• Если видите осмысленное слово — это правильный сдвиг!


Подсказка: "Сдвиг +5 означает: A→F, B→G, C→H..."

---

##ШИФР ПОДСТАНОВКИ (Substitution Cipher)

Принцип: каждая буква заменяется другой по таблице.

Пример:
• Алфавит: ABCDEFGHIJKLMNOPQRSTUVWXYZ
• Замена:   QWERTYUIOPASDFGHJKLZXCVBNM
• "HELLO" → "ITSSG"

 Как расшифровать:
• Частотный анализ: самая частая буква → E/O
• Короткие слова: A, I, TO, IS легко угадать
• Ищите повторяющиеся буквы

Подсказка: "Если видите односимвольное слово — это A или I"

---

## ШИФР ВИЖЕНЕРА (Vigenère Cipher)

Принцип: Цезарь с меняющимся сдвигом по ключевому слову.

Пример (ключ KEY):
Текст:  ATTACK
Ключ:   KEYKEY
Шифр:   KXVMCU

Каждая буква ключа даёт свой сдвиг:
• K (позиция 10) → сдвиг +10
• E (позиция 4) → сдвиг +4
• Y (позиция 24) → сдвиг +24

Как расшифровать:
• Если знаете длину ключа — каждая позиция это отдельный Цезарь
• Попробуйте короткие слова: КОТ, ЛЕС, ДОМ, KEY, GO
• Частотный анализ по каждой позиции

Подсказка: "Ключ длиной 3. Попробуйте: КОТ, ДОМ, ЛЕС"

---

##СОВРЕМЕННАЯ КРИПТОГРАФИЯ

В реальной жизни используются:
• **AES-256** — симметричное шифрование (WiFi, VPN, диски)
• **RSA-4096** — асимметричное (SSL/TLS, почта)
• **SHA-256** — хеширование (пароли, блокчейн)
• **bcrypt** — специально для паролей с SALT

Классические шифры (Caesar, Vigenère) легко ломаются за секунды!
Используются только для обучения принципам криптографии.

---

ОСНОВНЫЕ ПРАВИЛА:
1. Никогда не храните пароли открытым текстом
2. Используйте современные алгоритмы (AES-256, RSA-4096)
3. Добавляйте SALT к хешам паролей
4. Классические шифры — только для учебы!`

func NewCryptoScreen(
	w fyne.Window,
	r CryptoRouter,
	u *domain.User,
	gameUC *usecase.GameUsecase,
) *CryptoScreen {
	return &CryptoScreen{
		w:          w,
		router:     r,
		user:       u,
		gameUC:     gameUC,
		showTheory: true,
	}
}

func (s *CryptoScreen) showTheoryDialog() {
	richText := widget.NewRichTextFromMarkdown(cryptoTheoryText)
	richText.Wrapping = fyne.TextWrapWord

	scroll := container.NewVScroll(richText)
	scroll.SetMinSize(fyne.NewSize(1100, 700))

	dialog.ShowCustom("Теория: Классические шифры", "Закрыть", scroll, s.w)
}

func (s *CryptoScreen) buildMenu() fyne.CanvasObject {
	btnTheory := widget.NewButton("Теория: Классические шифры", func() {
		s.showTheoryDialog()
	})
	btnTheory.Importance = widget.LowImportance

	btnStart := widget.NewButton("Начать игру", func() {
		s.showTheory = false
		s.w.SetContent(s.Build())
	})
	btnStart.Importance = widget.HighImportance

	btnBack := widget.NewButton("Назад", func() {
		s.router.NavigateToDashboard(s.user)
	})

	menu := container.NewVBox(
		widget.NewLabelWithStyle("МОДУЛЬ: КРИПТОГРАФИЯ",
			fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
		widget.NewLabel(""),
		widget.NewLabel("Научитесь расшифровывать простые шифры."),
		widget.NewLabel("В игре только 3 типа: Caesar, Подстановка, Vigenère."),
		widget.NewLabel(""),
		widget.NewSeparator(),
		widget.NewLabel(""),
		btnTheory,
		btnStart,
		widget.NewLabel(""),
		btnBack,
	)

	return container.NewCenter(menu)
}

func (s *CryptoScreen) Build() fyne.CanvasObject {
	if s.showTheory {
		return s.buildMenu()
	}

	if s.timerLbl == nil {
		s.timerLbl = widget.NewLabel("Время: 00:00")
		s.scoreLbl = widget.NewLabel("Очки: 0")
		s.comboLbl = widget.NewLabel("Комбо: 0")

		s.ciphertextLbl = widget.NewLabel("")
		s.ciphertextLbl.Wrapping = fyne.TextWrapWord
		s.ciphertextLbl.TextStyle = fyne.TextStyle{Monospace: true, Bold: true}

		s.cipherTypeLbl = widget.NewLabel("")

		s.answerEntry = widget.NewEntry()
		s.answerEntry.SetPlaceHolder("Введите расшифрованный текст...")

		s.list = widget.NewList(
			func() int { return len(s.challenges) },
			func() fyne.CanvasObject {
				return widget.NewLabel("")
			},
			func(id widget.ListItemID, o fyne.CanvasObject) {
				if id < 0 || id >= len(s.challenges) {
					return
				}
				ch := s.challenges[id]
				o.(*widget.Label).SetText(
					fmt.Sprintf("#%d - %s", id+1, ch.CipherType),
				)
			},
		)

		s.list.OnSelected = func(id widget.ListItemID) {
			s.cur = int(id)
			s.showChallenge()
		}
	}

	btnSubmit := widget.NewButton("Проверить ответ", func() { s.checkAnswer() })
	btnSubmit.Importance = widget.HighImportance

	btnHint := widget.NewButton("Подсказка", func() { s.showHint() })

	btnSkip := widget.NewButton("Пропустить", func() { s.skip() })

	btnBack := widget.NewButton("Выйти", func() {
		if s.cancel != nil {
			s.cancel()
		}
		s.router.NavigateToDashboard(s.user)
	})

	topBar := container.NewHBox(
		s.timerLbl,
		layout.NewSpacer(),
		s.scoreLbl,
		widget.NewLabel("|"),
		s.comboLbl,
	)

	info := container.NewVBox(
		widget.NewLabelWithStyle("Зашифрованный текст:", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		s.ciphertextLbl,
		widget.NewLabel(""),
		widget.NewLabelWithStyle("Тип шифра:", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		s.cipherTypeLbl,
		widget.NewLabel(""),
		widget.NewLabelWithStyle("Ваш ответ:", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		s.answerEntry,
	)

	actions := container.NewVBox(
		btnSubmit,
		btnHint,
		btnSkip,
		layout.NewSpacer(),
		btnBack,
	)

	right := container.NewBorder(
		topBar,
		actions,
		nil,
		nil,
		container.NewVScroll(info),
	)

	split := container.NewHSplit(s.list, right)
	split.SetOffset(0.3)

	s.loadChallenges()
	return split
}

func (s *CryptoScreen) loadChallenges() {
	ctx, cancel := context.WithCancel(context.Background())
	s.cancel = cancel

	s.challenges = s.generateSimpleChallenges()

	s.cur = 0
	s.list.Refresh()
	s.list.Select(0)
	s.showChallenge()

	s.start = time.Now()
	go s.timerLoop(ctx)
}

// ТОЛЬКО 3 типа шифров: Caesar, Substitution, Vigenere
func (s *CryptoScreen) generateSimpleChallenges() []CryptoChallenge {
	rand.Seed(time.Now().UnixNano())

	challenges := []CryptoChallenge{
		{
			CipherType: "Caesar (сдвиг +3)",
			Plaintext:  "HELLO",
			Ciphertext: "KHOOR",
			Hint:       "Каждая буква сдвинута на 3 позиции. A→D, B→E, C→F",
			Difficulty: 1,
		},
		{
			CipherType: "Caesar (сдвиг +5)",
			Plaintext:  "ATTACK",
			Ciphertext: "FYYFHP",
			Hint:       "Сдвиг на 5. Попробуйте вычесть 5 из каждой буквы.",
			Difficulty: 1,
		},
		{
			CipherType: "ROT13 (Caesar +13)",
			Plaintext:  "SECRET",
			Ciphertext: "FRPERG",
			Hint:       "ROT13 — сдвиг ровно на 13. Симметричный шифр.",
			Difficulty: 1,
		},
		{
			CipherType: "Подстановка",
			Plaintext:  "HELLO",
			Ciphertext: "ITSSG",
			Hint:       "H→I, E→T, L→S, O→G. Частотный анализ: E — самая частая буква.",
			Difficulty: 2,
		},
		{
			CipherType: "Подстановка",
			Plaintext:  "CAT",
			Ciphertext: "ECV",
			Hint:       "Короткое слово. C→E, A→C, T→V.",
			Difficulty: 2,
		},
		{
			CipherType: "Подстановка",
			Plaintext:  "CODE",
			Ciphertext: "EQFG",
			Hint:       "C→E, O→Q, D→F. Попробуйте найти закономерность.",
			Difficulty: 2,
		},
		{
			CipherType: "Vigenère (ключ: KEY)",
			Plaintext:  "ATTACK",
			Ciphertext: "KXVMCU",
			Hint:       "Ключ KEY (длина 3). K(+10), E(+4), Y(+24) повторяются.",
			Difficulty: 3,
		},
		{
			CipherType: "Vigenère (ключ: GO)",
			Plaintext:  "HELLO",
			Ciphertext: "NIJUP",
			Hint:       "Ключ GO (длина 2). G(+6), O(+14) чередуются.",
			Difficulty: 3,
		},
		{
			CipherType: "Vigenère (ключ: CAT)",
			Plaintext:  "SECRET",
			Ciphertext: "UGERGA",
			Hint:       "Ключ CAT (длина 3). C(+2), A(+0), T(+19) повторяются.",
			Difficulty: 3,
		},
	}

	rand.Shuffle(len(challenges), func(i, j int) {
		challenges[i], challenges[j] = challenges[j], challenges[i]
	})

	return challenges
}

func (s *CryptoScreen) timerLoop(ctx context.Context) {
	ticker := time.NewTicker(time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			el := time.Since(s.start).Truncate(time.Second)
			min := int(el.Minutes())
			sec := int(el.Seconds()) % 60
			txt := fmt.Sprintf("Время: %02d:%02d", min, sec)

			fyne.Do(func() {
				s.timerLbl.SetText(txt)
			})
		}
	}
}

func (s *CryptoScreen) showChallenge() {
	if s.cur < 0 || s.cur >= len(s.challenges) {
		return
	}

	ch := s.challenges[s.cur]
	s.ciphertextLbl.SetText(ch.Ciphertext)
	s.cipherTypeLbl.SetText(ch.CipherType)
	s.answerEntry.SetText("")
}

func (s *CryptoScreen) showHint() {
	if s.cur < 0 || s.cur >= len(s.challenges) {
		return
	}

	ch := s.challenges[s.cur]
	dialog.ShowInformation("Подсказка", ch.Hint, s.w)
}

func (s *CryptoScreen) checkAnswer() {
	if len(s.challenges) == 0 {
		return
	}

	ch := s.challenges[s.cur]
	userAnswer := strings.TrimSpace(strings.ToUpper(s.answerEntry.Text))
	correctAnswer := strings.TrimSpace(strings.ToUpper(ch.Plaintext))

	correct := userAnswer == correctAnswer

	if correct {
		s.correct++
		s.combo++
		if s.combo > s.maxCombo {
			s.maxCombo = s.combo
		}
		s.score += 20 + (ch.Difficulty * 10)
	} else {
		s.wrong++
		s.combo = 0
		s.score -= 10
		if s.score < 0 {
			s.score = 0
		}
	}

	s.scoreLbl.SetText(fmt.Sprintf("Очки: %d", s.score))
	s.comboLbl.SetText(fmt.Sprintf("Комбо: %d", s.combo))

	s.showExplanation(ch, correct)

	if s.cur+1 < len(s.challenges) {
		s.cur++
		s.list.Select(s.cur)
	} else {
		s.finish()
	}
}

func (s *CryptoScreen) skip() {
	s.combo = 0
	if s.cur+1 < len(s.challenges) {
		s.cur++
		s.list.Select(s.cur)
	} else {
		s.finish()
	}
}

func (s *CryptoScreen) showExplanation(ch CryptoChallenge, correct bool) {
	status := "Неправильно"
	if correct {
		status = "Правильно"
	}

	txt := fmt.Sprintf(`%s

Правильный ответ: %s

Объяснение:
%s`,
		status, ch.Plaintext, ch.Hint)

	dialog.ShowInformation("Результат", txt, s.w)
}

func (s *CryptoScreen) finish() {
	if s.cancel != nil {
		s.cancel()
	}

	duration := time.Since(s.start).Truncate(time.Second)

	if s.user != nil && s.gameUC != nil {
		ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
		defer cancel()

		_ = s.gameUC.SaveGameResult(ctx, s.user.ID, "crypto", s.score)
	}

	summary := fmt.Sprintf(`МОДУЛЬ: КРИПТОГРАФИЯ - ЗАВЕРШЁН

Правильных: %d
Ошибок: %d
Макс. комбо: %d
Время: %s
Итоговые очки: %d
`,
		s.correct, s.wrong, s.maxCombo, duration, s.score)

	dialog.ShowInformation("Игра окончена", summary, s.w)
	s.router.NavigateToDashboard(s.user)
}
