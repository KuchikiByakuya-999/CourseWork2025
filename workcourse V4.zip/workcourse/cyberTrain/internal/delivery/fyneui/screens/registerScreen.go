package screens

import (
	"context"
	"cyber-skeleton/internal/domain"
	"cyber-skeleton/internal/security"
	"cyber-skeleton/internal/usecase"
	"errors"
	"strings"

	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/container"
	"fyne.io/fyne/v2/dialog"
	"fyne.io/fyne/v2/widget"
)

type registerUC interface {
	Register(ctx context.Context, username, email, password string) (*domain.User, error)
}

type RegisterRouter interface {
	NavigateToDashboard(u *domain.User)
	ShowLoginScreen()
}

type RegisterScreen struct {
	window fyne.Window
	router RegisterRouter
	uc     *usecase.AuthUsecase
}

func NewRegisterScreen(w fyne.Window, r RegisterRouter, uc *usecase.AuthUsecase) *RegisterScreen {
	return &RegisterScreen{window: w, router: r, uc: uc}
}

func (s *RegisterScreen) Build() fyne.CanvasObject {
	username := widget.NewEntry()
	email := widget.NewEntry()
	password := widget.NewPasswordEntry()
	confirm := widget.NewPasswordEntry()
	username.SetPlaceHolder("Придумайте логин")
	email.SetPlaceHolder("Введите email")
	password.SetPlaceHolder("Придумайте пароль")
	confirm.SetPlaceHolder("Подтвердите пароль")

	registerBtn := widget.NewButton("Создать аккаунт", func() {
		usernameText := strings.TrimSpace(username.Text)
		emailText := strings.TrimSpace(email.Text)
		passText := password.Text
		confirmText := confirm.Text

		if usernameText == "" || emailText == "" || passText == "" {
			dialog.ShowError(errors.New("заполните все поля"), s.window)
			return
		}

		usernameText = security.SanitizeInput(usernameText)
		emailText = security.SanitizeInput(emailText)
		passText = security.SanitizeInput(passText)
		confirmText = security.SanitizeInput(confirmText)

		if len(usernameText) > 64 {
			usernameText = usernameText[:64]
		}
		if len(emailText) > 128 {
			emailText = emailText[:128]
		}
		if len(passText) > 128 {
			passText = passText[:128]
		}
		if len(confirmText) > 128 {
			confirmText = confirmText[:128]
		}

		if !security.IsValidUsername(usernameText) {
			dialog.ShowError(errors.New("имя пользователя должно содержать только буквы, цифры и подчёркивания (3-20 символов)"), s.window)
			return
		}

		if !security.IsValidEmail(emailText) {
			dialog.ShowError(errors.New("введите корректный email"), s.window)
			return
		}

		if passText != confirmText {
			dialog.ShowError(errors.New("пароли не совпадают"), s.window)
			return
		}

		validation := security.ValidatePassword(passText)
		if !validation["valid"].(bool) {
			errList := validation["errors"].([]string)
			dialog.ShowError(errors.New(strings.Join(errList, "\n")), s.window)
			return
		}

		u, err := s.uc.Register(context.Background(), usernameText, emailText, passText)
		if err != nil {
			dialog.ShowError(err, s.window)
			return
		}
		s.router.NavigateToDashboard(u)
	})

	backBtn := widget.NewButton("Назад к входу", func() {
		s.router.ShowLoginScreen()
	})

	form := container.NewVBox(
		widget.NewLabelWithStyle("Регистрация", fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
		widget.NewLabel("Логин"),
		username,
		widget.NewLabel("Email"),
		email,
		widget.NewLabel("Пароль"),
		password,
		widget.NewLabel("Подтверждение пароля"),
		confirm,
		registerBtn,
		backBtn,
	)

	return container.NewCenter(form)
}
