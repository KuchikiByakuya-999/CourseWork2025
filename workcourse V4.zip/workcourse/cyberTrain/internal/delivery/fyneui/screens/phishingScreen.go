package screens

import (
	"context"
	"cyber-skeleton/internal/domain"
	"cyber-skeleton/internal/usecase"
	"fmt"
	"time"

	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/container"
	"fyne.io/fyne/v2/dialog"
	"fyne.io/fyne/v2/layout"
	"fyne.io/fyne/v2/widget"
)

type PhishingRouter interface {
	NavigateToDashboard(u *domain.User)
}

type PhishAction int

const (
	ActionReportPhish PhishAction = iota
	ActionDelete
	ActionAllow
	ActionQuarantine
)

type PhishingScreen struct {
	w          fyne.Window
	showTheory bool
	router     PhishingRouter
	uc         *usecase.PhishingUsecase
	user       *domain.User
	mode       domain.PhishingMode
	level      domain.PhishingLevel
	mails      []domain.PhishingMail
	cur        int
	start      time.Time
	cancel     context.CancelFunc
	flagDmn    *widget.Check
	flagUrl    *widget.Check
	flagAtt    *widget.Check
	flagUrg    *widget.Check
	score      int
	correct    int
	wrong      int
	skipped    int
	combo      int
	maxCombo   int
	timerLbl   *widget.Label
	scoreLbl   *widget.Label
	comboLbl   *widget.Label
	list       *widget.List
	fromLbl    *widget.Label
	subjLbl    *widget.Label
	channelLbl *widget.Label
	bodyLbl    *widget.Label
}

func NewPhishingScreen(w fyne.Window, r PhishingRouter, u *domain.User, uc *usecase.PhishingUsecase,
	mode domain.PhishingMode, lvl domain.PhishingLevel) *PhishingScreen {
	return &PhishingScreen{
		w:          w,
		router:     r,
		user:       u,
		uc:         uc,
		mode:       mode,
		level:      lvl,
		showTheory: true,
	}
}

func (s *PhishingScreen) showTheoryDialog() {
	theoryText := `ТЕОРИЯ: ФИШИНГ И СОЦИАЛЬНАЯ ИНЖЕНЕРИЯ

## Что такое фишинг?

Фишинг — вид кибератаки, при котором злоумышленник притворяется доверенным лицом или организацией, чтобы:

• Украсть учётные данные (логин/пароль)
• Получить данные банковских карт
• Установить вредоносное ПО
• Получить доступ к конфиденциальной информации

---

## Типы фишинга

### 1. Email Phishing (массовый)
• Рассылка миллионам пользователей
• Притворяются банком, почтовым сервисом, соцсетью
• Просят "подтвердить данные" по ссылке

### 2. Spear Phishing (целевой)
• Атака на конкретную организацию/человека
• Персонализированные письма с реальными именами
• Высокая степень убедительности

### 3. Whaling (китобойный промысел)
• Целью являются топ-менеджеры, CEO, CFO
• Письма от имени партнёров, акционеров
• Большие финансовые потери

### 4. Smishing (SMS фишинг)
• Фишинговые SMS с поддельными ссылками
• "Ваша посылка ждёт получения", "Заблокирована карта"

### 5. Vishing (голосовой фишинг)
• Звонки якобы от банка/техподдержки
• Запрашивают CVV код, пароли, коды из SMS

---

## Признаки фишинга (Red Flags)

**Подозрительный отправитель**
• support@paypa1.com (вместо paypal)
• noreply@secure-bank.tk (.tk - подозрительная зона)

**Странная ссылка**
• Текст: "www.google.com"
• Реальная ссылка: http://malware.ru/steal

**Давление и срочность**
• "Ваш аккаунт будет заблокирован через 24 часа!"
• "Срочно подтвердите данные!"

**Запрос конфиденциальных данных**
• Пароли, коды из SMS, CVV
• Сканы паспорта, ИНН

**Неожиданные вложения**
• invoice.exe, document.zip

---

## Как защититься?

1. **Проверяйте отправителя** - наведите на email
2. **Не переходите по ссылкам** - вводите адрес вручную
3. **Не открывайте вложения** - проверяйте антивирусом
4. **Используйте 2FA** - двухфакторную аутентификацию
5. **Обучайтесь** - регулярные тренинги

---

**Статистика:** 91% успешных кибератак начинаются с фишинга!`

	richText := widget.NewRichTextFromMarkdown(theoryText)
	richText.Wrapping = fyne.TextWrapWord

	scroll := container.NewScroll(richText)
	scroll.SetMinSize(fyne.NewSize(900, 700))

	dialog.ShowCustom("Теория: Фишинг", "Закрыть", scroll, s.w)
}

func (s *PhishingScreen) buildMenu() fyne.CanvasObject {

	btnTheory := widget.NewButton("Теория: Фишинг и социальная инженерия", func() {
		s.showTheoryDialog()
	})
	btnTheory.Importance = widget.LowImportance

	btnStart := widget.NewButton("Начать игру", func() {
		s.showTheory = false
		s.w.SetContent(s.Build())
	})
	btnStart.Importance = widget.HighImportance

	btnBack := widget.NewButton("Назад", func() {
		s.router.NavigateToDashboard(s.user)
	})

	menu := container.NewVBox(
		widget.NewLabelWithStyle("МОДУЛЬ: ФИШИНГ И СОЦИАЛЬНАЯ ИНЖЕНЕРИЯ",
			fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
		widget.NewLabel(""),
		widget.NewLabel("Научитесь распознавать фишинговые письма и защищаться от социальной инженерии."),
		widget.NewLabel("Вам предстоит проанализировать 15 писем и определить, какие из них - фишинг."),
		widget.NewLabel(""),
		widget.NewSeparator(),
		widget.NewLabel(""),
		btnTheory,
		btnStart,
		widget.NewLabel(""),
		btnBack,
	)

	return container.NewCenter(menu)
}

func (s *PhishingScreen) buildFlags() fyne.CanvasObject {
	s.flagDmn = widget.NewCheck("Странный домен/отправитель", nil)
	s.flagUrl = widget.NewCheck("Подозрительная ссылка", nil)
	s.flagAtt = widget.NewCheck("Неожиданное вложение", nil)
	s.flagUrg = widget.NewCheck("Давление/угрозы", nil)

	return container.NewVBox(
		widget.NewLabelWithStyle("Red Flags (Отметьте подозрительное):", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		s.flagDmn,
		s.flagUrl,
		s.flagAtt,
		s.flagUrg,
	)
}

func (s *PhishingScreen) Build() fyne.CanvasObject {

	if s.showTheory {
		return s.buildMenu()
	}

	s.timerLbl = widget.NewLabel("Время: 00:00")
	s.scoreLbl = widget.NewLabel("Очки: 0")
	s.comboLbl = widget.NewLabel("Комбо: 0")
	s.fromLbl = widget.NewLabel("")
	s.subjLbl = widget.NewLabel("")
	s.channelLbl = widget.NewLabel("")
	s.bodyLbl = widget.NewLabel("")
	s.bodyLbl.Wrapping = fyne.TextWrapWord

	s.list = widget.NewList(
		func() int { return len(s.mails) },
		func() fyne.CanvasObject {
			return container.NewHBox(
				widget.NewLabel("Уров."),
				widget.NewLabel("Канал"),
				widget.NewLabel("Тема"),
			)
		},
		func(id widget.ListItemID, o fyne.CanvasObject) {
			if id < 0 || id >= len(s.mails) {
				return
			}
			m := s.mails[id]
			c := o.(*fyne.Container)
			c.Objects[0].(*widget.Label).SetText(s.levelShort(m.Level))
			c.Objects[1].(*widget.Label).SetText(m.Channel)
			c.Objects[2].(*widget.Label).SetText(m.Subject)
		},
	)

	s.list.OnSelected = func(id widget.ListItemID) {
		s.cur = int(id)
		s.showMail()
	}

	btnReport := widget.NewButton("Фишинг → сообщить в безопасность", func() {
		s.answer(ActionReportPhish)
	})
	btnReport.Importance = widget.DangerImportance

	btnDelete := widget.NewButton("Фишинг → удалить", func() {
		s.answer(ActionDelete)
	})
	btnDelete.Importance = widget.WarningImportance

	btnAllow := widget.NewButton("Безопасно → оставить", func() {
		s.answer(ActionAllow)
	})
	btnAllow.Importance = widget.SuccessImportance

	btnQuarantine := widget.NewButton("Не уверен → в карантин", func() {
		s.answer(ActionQuarantine)
	})

	btnBack := widget.NewButton("Выйти", func() {
		if s.cancel != nil {
			s.cancel()
		}
		s.router.NavigateToDashboard(s.user)
	})

	actions := container.NewVBox(
		widget.NewLabelWithStyle("Ваше решение:", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		btnReport,
		btnDelete,
		btnAllow,
		btnQuarantine,
		layout.NewSpacer(),
		btnBack,
	)

	topBar := container.NewHBox(s.timerLbl, layout.NewSpacer(), s.scoreLbl, widget.NewLabel("|"), s.comboLbl)

	info := container.NewVBox(
		widget.NewLabelWithStyle("От кого:", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		s.fromLbl,
		widget.NewLabelWithStyle("Тема:", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		s.subjLbl,
		widget.NewLabelWithStyle("Канал:", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		s.channelLbl,
		widget.NewSeparator(),
		widget.NewLabelWithStyle("Содержание:", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		s.bodyLbl,
		widget.NewSeparator(),
		s.buildFlags(),
	)

	right := container.NewBorder(
		topBar,
		actions,
		nil,
		nil,
		container.NewVScroll(info),
	)

	split := container.NewHSplit(s.list, right)
	split.SetOffset(0.3)

	s.loadMails()
	return split
}

func (s *PhishingScreen) levelShort(l domain.PhishingLevel) string {
	switch l {
	case domain.PhishingLevelEasy:
		return "?"
	case domain.PhishingLevelMedium:
		return "?"
	case domain.PhishingLevelHard:
		return "?"
	default:
		return "?"
	}
}

func (s *PhishingScreen) loadMails() {
	ctx, cancel := context.WithCancel(context.Background())
	s.cancel = cancel

	generatedMails := s.uc.GeneratePhishingMails(ctx)
	s.mails = make([]domain.PhishingMail, len(generatedMails))

	for i, gm := range generatedMails {
		s.mails[i] = domain.PhishingMail{
			From:        gm["from"].(string),
			Subject:     gm["subject"].(string),
			Body:        gm["body"].(string),
			Channel:     gm["channel"].(string),
			IsPhishing:  gm["is_phishing"].(bool),
			Level:       domain.PhishingLevel(gm["level"].(int)),
			RedFlags:    gm["red_flags"].([]string),
			Explanation: gm["explanation"].(string),
		}
	}

	if len(s.mails) == 0 {
		dialog.ShowInformation("Фишинг", "Не удалось сгенерировать письма", s.w)
		return
	}

	s.cur = 0
	s.list.Refresh()
	s.list.Select(0)
	s.showMail()
	s.start = time.Now()
	go s.timerLoop(ctx)
}

func (s *PhishingScreen) timerLoop(ctx context.Context) {
	ticker := time.NewTicker(time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			el := time.Since(s.start).Truncate(time.Second)
			min := int(el.Minutes())
			sec := int(el.Seconds()) % 60
			txt := fmt.Sprintf("Время: %02d:%02d", min, sec)
			s.timerLbl.SetText(txt)
		}
	}
}

func (s *PhishingScreen) showMail() {
	if len(s.mails) == 0 || s.cur < 0 || s.cur >= len(s.mails) {
		return
	}

	m := s.mails[s.cur]
	s.fromLbl.SetText(m.From)
	s.subjLbl.SetText(m.Subject)
	s.channelLbl.SetText(m.Channel)
	s.bodyLbl.SetText(m.Body)

	if s.flagDmn != nil {
		s.flagDmn.SetChecked(false)
		s.flagUrl.SetChecked(false)
		s.flagAtt.SetChecked(false)
		s.flagUrg.SetChecked(false)
	}
}

func (s *PhishingScreen) answer(act PhishAction) {
	if len(s.mails) == 0 {
		return
	}

	m := s.mails[s.cur]
	isPhish := m.IsPhishing

	var baseRight bool
	switch act {
	case ActionReportPhish, ActionDelete, ActionQuarantine:
		baseRight = isPhish
	case ActionAllow:
		baseRight = !isPhish
	}

	bonus := 0
	penalty := 0

	if isPhish {
		switch act {
		case ActionReportPhish:
			bonus += 20
		case ActionDelete:
			bonus += 10
		case ActionQuarantine:
			bonus += 5
		case ActionAllow:
			penalty += 30
		}
	} else {
		switch act {
		case ActionAllow:
			bonus += 15
		case ActionQuarantine:
			penalty += 5
		case ActionReportPhish, ActionDelete:
			penalty += 15
		}
	}

	flags := 0
	if s.flagDmn != nil && s.flagDmn.Checked {
		flags++
	}
	if s.flagUrl != nil && s.flagUrl.Checked {
		flags++
	}
	if s.flagAtt != nil && s.flagAtt.Checked {
		flags++
	}
	if s.flagUrg != nil && s.flagUrg.Checked {
		flags++
	}
	bonus += flags * 3

	if baseRight {
		s.correct++
		s.combo++
		if s.combo > s.maxCombo {
			s.maxCombo = s.combo
		}
		s.score += s.points(m.Level, true) + bonus
	} else {
		s.wrong++
		s.combo = 0
		s.score -= s.points(m.Level, false) + penalty
		if s.score < 0 {
			s.score = 0
		}
	}

	s.scoreLbl.SetText(fmt.Sprintf("Очки: %d", s.score))
	s.comboLbl.SetText(fmt.Sprintf("Комбо: %d", s.combo))

	s.showExplanation(m, baseRight)

	if s.cur+1 < len(s.mails) {
		s.cur++
		s.list.Select(s.cur)
	} else {
		s.finish()
	}
}

func (s *PhishingScreen) points(l domain.PhishingLevel, correct bool) int {
	base := 0
	switch l {
	case domain.PhishingLevelEasy:
		base = 10
	case domain.PhishingLevelMedium:
		base = 20
	case domain.PhishingLevelHard:
		base = 30
	}

	if correct {
		return base
	}
	return base / 2
}

func (s *PhishingScreen) showExplanation(m domain.PhishingMail, right bool) {
	status := "Ответ неверный"
	if right {
		status = "Ответ верный"
	}

	flags := ""
	for _, f := range m.RedFlags {
		flags += "• " + f + "\n"
	}

	txt := fmt.Sprintf("%s\n\nПояснение:\n%s\n\nПризнаки:\n%s", status, m.Explanation, flags)
	dialog.ShowInformation("Разбор письма", txt, s.w)
}

func (s *PhishingScreen) finish() {
	if s.cancel != nil {
		s.cancel()
	}

	res := &domain.PhishingResult{
		UserID:   s.user.ID,
		Mode:     s.mode,
		Level:    s.level,
		Score:    s.score,
		Correct:  s.correct,
		Wrong:    s.wrong,
		Skipped:  s.skipped,
		MaxCombo: s.maxCombo,
		Duration: time.Since(s.start),
	}

	_ = s.uc.SaveResult(context.Background(), res)

	summary := fmt.Sprintf(`📊 МОДУЛЬ: ФИШИНГ - ЗАВЕРШЁН

Правильных: %d
Ошибок: %d
Пропущено: %d
Макс. комбо: %d
Время: %s
Итоговые очки: %d
`,
		res.Correct, res.Wrong, res.Skipped, res.MaxCombo,
		res.Duration.Truncate(time.Second), res.Score)

	dialog.ShowInformation("Игра окончена", summary, s.w)
	s.router.NavigateToDashboard(s.user)
}
