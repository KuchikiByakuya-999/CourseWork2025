package screens

import (
	"context"
	"cyber-skeleton/internal/domain"
	"cyber-skeleton/internal/usecase"
	"fmt"
	"image/color"
	"time"

	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/canvas"
	"fyne.io/fyne/v2/container"
	"fyne.io/fyne/v2/layout"
	"fyne.io/fyne/v2/widget"
)

type DashboardScreenV2 struct {
	w            fyne.Window
	router       DashboardRouter
	user         *domain.User
	phishUC      *usecase.PhishingUsecase
	passwordUC   *usecase.PasswordUsecase
	networkUC    *usecase.NetworkUsecase
	gameUC       *usecase.GameUsecase
	themeManager *ThemeManager
	refreshChan  chan bool
}

type DashboardRouter interface {
	NavigateToPasswordGame()
	NavigateToPhishingGame()
	NavigateToNetworkGame()
	NavigateToCryptoGame()
	NavigateToMalwareGame()
	NavigateToProfile(u *domain.User)
}

func NewDashboardScreenV2(
	w fyne.Window,
	r DashboardRouter,
	u *domain.User,
	phishUC *usecase.PhishingUsecase,
	passwordUC *usecase.PasswordUsecase,
	networkUC *usecase.NetworkUsecase,
	gameUC *usecase.GameUsecase,
	themeManager *ThemeManager,
) *DashboardScreenV2 {
	return &DashboardScreenV2{
		w:            w,
		router:       r,
		user:         u,
		phishUC:      phishUC,
		passwordUC:   passwordUC,
		networkUC:    networkUC,
		gameUC:       gameUC,
		themeManager: themeManager,
		refreshChan:  make(chan bool, 1),
	}
}

func (d *DashboardScreenV2) Build() fyne.CanvasObject {
	theme := d.themeManager.GetCurrentTheme()

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	go func() {
		if d.phishUC != nil {
			d.phishUC.GeneratePhishingMails(ctx)
		}
		if d.passwordUC != nil {
			d.passwordUC.GeneratePasswordChallenges(ctx)
		}
		if d.networkUC != nil {
			d.networkUC.GenerateNetworkIncidents(ctx)
		}
	}()

	header := container.NewVBox(
		widget.NewLabelWithStyle(
			"CYBER SECURITY TRAINING",
			fyne.TextAlignCenter,
			fyne.TextStyle{Bold: true},
		),
		widget.NewLabelWithStyle(
			fmt.Sprintf("Добро пожаловать, %s!", d.user.Username),
			fyne.TextAlignCenter,
			fyne.TextStyle{},
		),
	)

	profileBtn := widget.NewButton("Профиль", func() {
		d.router.NavigateToProfile(d.user)
	})

	topBar := container.NewBorder(nil, nil, nil, profileBtn)

	moduleCard := func(title, desc string, xp int, maxXP int, onStart func()) fyne.CanvasObject {
		progress := float64(xp) / float64(maxXP)
		if progress > 1.0 {
			progress = 1.0
		}

		progressBar := canvas.NewRectangle(theme.Primary)
		progressBar.SetMinSize(fyne.NewSize(float32(progress*280), 8))

		progressBg := canvas.NewRectangle(color.NRGBA{R: 60, G: 65, B: 75, A: 255})
		progressBg.SetMinSize(fyne.NewSize(280, 8))

		progContainer := container.NewMax(progressBg, progressBar)

		card := container.NewVBox(
			container.NewHBox(
				widget.NewLabelWithStyle(title, fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
				layout.NewSpacer(),
			),
			widget.NewLabel(desc),
			widget.NewLabelWithStyle(
				fmt.Sprintf("XP: %d / %d", xp, maxXP),
				fyne.TextAlignLeading,
				fyne.TextStyle{},
			),
			progContainer,
			widget.NewButton("НАЧАТЬ", onStart),
		)

		border := canvas.NewRectangle(theme.Border)
		border.SetMinSize(fyne.NewSize(320, 180))

		return container.NewStack(border, container.NewPadded(card))
	}

	row1 := container.NewHBox(
		layout.NewSpacer(),
		moduleCard("ФИШИНГ", "Анализ писем и красных флагов", 1540, 2000, func() {
			d.router.NavigateToPhishingGame()
		}),
		moduleCard("ПАРОЛИ", "Анализ сложности паролей", 1540, 2000, func() {
			d.router.NavigateToPasswordGame()
		}),
		moduleCard("СЕТЕВЫЕ ИНЦИДЕНТЫ", "Реагирование на угрозы", 1200, 2000, func() {
			d.router.NavigateToNetworkGame()
		}),
		layout.NewSpacer(),
	)

	row2 := container.NewHBox(
		layout.NewSpacer(),
		moduleCard("КРИПТОГРАФИЯ", "Хеширование и шифрование", 800, 2000, func() {
			d.router.NavigateToCryptoGame()
		}),
		moduleCard("ВРЕДОНОС", "Анализ вредоносного ПО", 600, 2000, func() {
			d.router.NavigateToMalwareGame()
		}),
		layout.NewSpacer(),
	)

	moduleGrid := container.NewVBox(
		layout.NewSpacer(),
		row1,
		row2,
		layout.NewSpacer(),
	)

	content := container.NewBorder(
		container.NewVBox(topBar, widget.NewSeparator(), header, widget.NewSeparator()),
		nil,
		nil,
		nil,
		container.NewCenter(moduleGrid),
	)

	return content
}

func (d *DashboardScreenV2) Refresh() {
	select {
	case d.refreshChan <- true:
	default:
	}
}
