export POSTGRES_HOST=localhost && export POSTGRES_PORT=5432 && export POSTGRES_USER=postgres && export POSTGRES_PASSWORD=postgres && export POSTGRES_DB=cyberdb
go run ./cmd/app
