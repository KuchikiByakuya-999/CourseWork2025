package store

import (
	"fmt"
	"os"

	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

type Store struct {
	DB *gorm.DB
}

func NewStore() (*Store, error) {
	host := os.Getenv("POSTGRES_HOST")
	port := os.Getenv("POSTGRES_PORT")
	user := os.Getenv("POSTGRES_USER")
	dbname := os.Getenv("POSTGRES_DB")
	password := os.Getenv("POSTGRES_PASSWORD")

	if host == "" || port == "" || user == "" || dbname == "" || password == "" {
		return nil, fmt.Errorf("нужно задать POSTGRES_HOST, POSTGRES_PORT, POSTGRES_USER, POSTGRES_DB, POSTGRES_PASSWORD")
	}

	dsn := fmt.Sprintf(
		"host=%s port=%s user=%s dbname=%s password=%s sslmode=disable",
		host, port, user, dbname, password,
	)

	db, err := gorm.Open(postgres.Open(dsn), &gorm.Config{})
	if err != nil {
		return nil, fmt.Errorf("ошибка подключения к БД: %w", err)
	}

	sqlDB, err := db.DB()
	if err != nil {
		return nil, err
	}
	sqlDB.SetMaxIdleConns(10)
	sqlDB.SetMaxOpenConns(20)

	err = db.AutoMigrate(
		&User{},
		&GameResult{},
		&PhishingResult{},
		&PhishingMail{},
		&PhishingRedFlag{},
		&PasswordChallenge{},
		&CryptoChallenge{},
		&CryptoResult{},
		&NetworkIncident{},
		&WeeklyQuest{},
		&WeakSpot{},
	)
	if err != nil {
		return nil, fmt.Errorf("ошибка миграции схемы: %w", err)
	}

	return &Store{DB: db}, nil
}

func (s *Store) Close() error {
	sqlDB, err := s.DB.DB()
	if err != nil {
		return err
	}
	return sqlDB.Close()
}
