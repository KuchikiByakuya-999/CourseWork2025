package store

import "gorm.io/gorm"

type User struct {
	gorm.Model
	Username     string `gorm:"uniqueIndex;size:50"`
	Email        string `gorm:"uniqueIndex;size:100"`
	PasswordHash string `gorm:"size:255"`
}

type GameResult struct {
	gorm.Model
	UserID   uint   `gorm:"index"`
	GameCode string `gorm:"size:50;index"`
	Score    int
	MaxScore int `gorm:"default:0"`
}

type PhishingResult struct {
	gorm.Model
	UserID   uint `gorm:"index"`
	Mode     int
	Level    int
	Score    int
	Correct  int
	Wrong    int
	Skipped  int
	MaxCombo int
	Duration int64
}

type PhishingMail struct {
	gorm.Model
	Level       int    `gorm:"index"`
	Channel     string `gorm:"size:20"`
	Sender      string `gorm:"size:100"`
	Subject     string `gorm:"size:200"`
	Body        string `gorm:"type:text"`
	Url         *string
	HasAttach   bool
	IsPhishing  bool
	Explanation *string           `gorm:"type:text"`
	RedFlags    []PhishingRedFlag `gorm:"foreignKey:MailID;constraint:OnDelete:CASCADE"`
}

type PhishingRedFlag struct {
	gorm.Model
	MailID int64  `gorm:"index"`
	Text   string `gorm:"size:255"`
}

type PasswordChallenge struct {
	gorm.Model
	Level    int
	Prompt   string `gorm:"type:text"`
	Correct  string `gorm:"type:text"`
	Solution string `gorm:"type:text"`
	Hint     string
}

type CryptoChallenge struct {
	gorm.Model
	CipherType string `gorm:"size:50;index"`
	Ciphertext string `gorm:"type:text"`
	Plaintext  string `gorm:"type:text"`
	Hint       string
	Key        string `gorm:"type:text"`
	Difficulty int    `gorm:"index"`
}

type CryptoResult struct {
	gorm.Model
	UserID      uint `gorm:"index"`
	ChallengeID uint
	Correct     bool
	TimeSpent   int64
	Attempts    int
}

type NetworkIncident struct {
	gorm.Model
	Type   string `gorm:"size:100;index"`
	Logs   string `gorm:"type:text"`
	Action string `gorm:"size:50"`
	Level  int    `gorm:"index"`
}

type WeeklyQuest struct {
	gorm.Model
	UserID      uint   `gorm:"index"`
	Code        string `gorm:"size:100"`
	Title       string `gorm:"size:255"`
	Description string
	TargetScore int
	ModuleCode  string `gorm:"size:50"`
	Completed   bool
	ExpiresAt   int64 `gorm:"index"`
}

type WeakSpot struct {
	gorm.Model
	UserID   uint   `gorm:"index"`
	GameCode string `gorm:"size:50;index"`
	Payload  string `gorm:"type:text"`
}
