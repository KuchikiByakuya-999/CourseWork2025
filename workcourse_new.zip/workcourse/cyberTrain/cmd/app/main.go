package main

import (
	"log"
	"os"

	"cyber-skeleton/internal/delivery/fyneui"
	"cyber-skeleton/internal/repository"
	"cyber-skeleton/internal/usecase"
	"cyber-skeleton/store"

	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/app"
	"github.com/joho/godotenv"
)

func main() {
	if err := godotenv.Load(); err != nil {
		log.Println("Не найден .env файл, используем переменные окружения")
	}

	dbStore, err := store.NewStore()
	if err != nil {
		log.Fatalf("Ошибка подключения к БД: %v", err)
	}
	defer dbStore.Close()

	repo := repository.NewGormRepository(dbStore)
	phishRepo := repository.NewGormPhishingRepository(dbStore)
	passwordRepo := repository.NewGormPasswordRepository(dbStore)
	networkRepo := repository.NewGormNetworkRepository(dbStore)

	authUC := usecase.NewAuthUsecase(repo)
	phishUC := usecase.NewPhishingUsecase(phishRepo)
	passwordUC := usecase.NewPasswordUsecase(passwordRepo)
	networkUC := usecase.NewNetworkUsecase(networkRepo)
	cryptoUC := usecase.NewCryptoUsecase()
	gameUC := usecase.NewGameUsecase(repo)
	courseUC := usecase.NewCourseUsecase()

	a := app.NewWithID("com.cyberbasics.app")
	w := a.NewWindow("CyberBasics - Обучение кибербезопасности")

	appName := os.Getenv("APP_NAME")
	if appName == "" {
		appName = "CyberBasics"
	}
	w.SetTitle(appName)

	router := fyneui.NewRouter(
		w,
		authUC,
		phishUC,
		passwordUC,
		networkUC,
		cryptoUC,
		gameUC,
		courseUC,
	)

	router.ShowLoginScreen()

	w.Resize(fyne.NewSize(1366, 768))
	w.CenterOnScreen()
	w.ShowAndRun()
}
