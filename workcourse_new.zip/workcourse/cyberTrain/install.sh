#!/bin/bash
echo "Cyber Skeleton - установка"

mkdir -p cyber_skeleton
cd cyber_skeleton

cat > .env << EOF
POSTGRES_HOST=localhost
POSTGRES_PORT=5432
POSTGRES_USER=postgres
POSTGRES_DB=cyber_skeleton
POSTGRES_PASSWORD=cyber123
APP_NAME=Cyber Skeleton
DEBUG=true
EOF

cat > run.sh << 'EOF'
#!/bin/bash
set -a
if [ -f .env ]; then
  source .env
fi
set +a
./cyber_skeleton
EOF

chmod +x run.sh

echo "Готово. Отредактируйте .env и положите бинарник cyber_skeleton сюда, запуск: ./run.sh"
