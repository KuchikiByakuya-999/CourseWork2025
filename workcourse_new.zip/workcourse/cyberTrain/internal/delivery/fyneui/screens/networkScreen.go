package screens

import (
	"context"
	"cyber-skeleton/internal/domain"
	"cyber-skeleton/internal/usecase"
	"fmt"
	"strings"
	"time"

	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/container"
	"fyne.io/fyne/v2/dialog"
	"fyne.io/fyne/v2/layout"
	"fyne.io/fyne/v2/widget"
)

type NetworkRouter interface {
	NavigateToDashboard(u *domain.User)
}

type NetworkScreenV2 struct {
	w             fyne.Window
	router        NetworkRouter
	uc            *usecase.NetworkUsecase
	user          *domain.User
	gameUC        *usecase.GameUsecase
	themeManager  *ThemeManager
	incidents     []domain.NetworkIncident
	cur           int
	start         time.Time
	cancel        context.CancelFunc
	score         int
	correct       int
	wrong         int
	skipped       int
	combo         int
	maxCombo      int
	timerLbl      *widget.Label
	scoreLbl      *widget.Label
	comboLbl      *widget.Label
	list          *widget.List
	typeLbl       *widget.Label
	logsContainer *fyne.Container
	showTheory    bool
}

func (s *NetworkScreenV2) MinSize() fyne.Size {
	return fyne.Size{Width: 1366, Height: 768}
}

var networkTheoryText = `🌐 ТЕОРИЯ: СЕТЕВЫЕ АТАКИ И ИНЦИДЕНТЫ

## Основные концепции

**Сетевой инцидент** – событие, нарушающее конфиденциальность, целостность или доступность данных.
**Киберугроза** – потенциальная возможность такой атаки.
**Киберинцидент** – угроза, которая уже реализовалась.

---

## 1. DDoS‑АТАКИ (Distributed Denial of Service)

**Цель:** сделать сервис недоступным, перегрузив сеть или сервер.

### Volumetric‑атаки (объёмные)
Забивают канал огромным количеством трафика.
Примеры:
- DNS amplification – усиление через открытые DNS‑серверы (умножение в 50–100 раз).
- NTP reflection – усиление через NTP‑серверы (до 556x).
- UDP flood – поток UDP‑пакетов на случайные порты.

### Protocol‑атаки (на уровне протокола)
Эксплуатируют особенности TCP/IP.
Примеры:
- SYN flood – забивает очередь полуоткрытых TCP‑соединений.
- Smurf – ICMP‑флуд через broadcast‑адрес.

### Application‑атаки (уровень приложений)
Бьют по веб‑приложению и БД.
Примеры:
- HTTP flood – миллионы HTTP‑запросов.
- Slowloris – медленные запросы, которые держат соединение открытым.

**Масштаб:**
- Обычная атака: 1–10 Гбит/с.
- Средняя: 10–100 Гбит/с.
- Крупная: 100 Гбит/с – 1 Тбит/с и больше.

**Защита:**
- WAF (Web Application Firewall).
- Rate limiting (ограничение числа запросов).
- CDN/Anti‑DDoS (Cloudflare, Akamai и др.).

---

## 2. ПОПЫТКИ ВЗЛОМА (Intrusion Attempts)

### SSH brute force
Подбор пароля по SSH.
- Скорость: десятки попыток в секунду.
- Словари: rockyou.txt (14 млн паролей и больше).
- Цели: root, admin, ubuntu и т.п.

Защита:
- Отключить парольный вход, использовать только SSH‑ключи.
- 2FA.
- Fail2ban/CSF (блокировка IP после N неудач).

### SQL Injection
Манипуляция SQL‑запросами через пользовательский ввод.
- Пример: id='1' OR '1'='1' – условие всегда истинно.
- Последствия: чтение, изменение, удаление данных, обход аутентификации.

Защита:
- Параметризованные запросы (Prepared Statements).
- Валидация и экранирование ввода.
- Ограниченные права у пользователя БД.

### RCE (Remote Code Execution)
Удалённое выполнение команд на сервере.
- Часто через загрузку веб‑оболочек, небезопасные eval/exec и т.п.
- Итог: полный контроль над сервером.

Защита:
- Жёсткая проверка и фильтрация входных данных.
- Минимально необходимые права у сервисов.
- Изоляция (chroot, контейнеры, sandbox).

### Path Traversal
Попытка вылезти из разрешённой директории.
- Пример: /download?file=../../../../etc/passwd

Защита:
- Запрет последовательностей ../.
- Белые списки разрешённых файлов.

### XSS (Cross‑Site Scripting)
Подсовывание вредного JavaScript в браузер пользователя.
- Кража cookies, сессий, подмена содержимого страниц.

Защита:
- Экранирование HTML‑вывода.
- Content‑Security‑Policy (CSP).

---

## 3. УТЕЧКИ ДАННЫХ (Data Breaches)

### Открытые сервисы
- Публичные S3‑бакеты.
- MongoDB/Elasticsearch без аутентификации.
- Открытые дампы БД в веб‑директориях.

Защита:
- Закрыть порты снаружи (firewall).
- Включить аутентификацию везде.
- Шифровать чувствительные данные.

### Внутренний нарушитель (Insider Threat)
Сотрудник сознательно или случайно выносит данные.

Защита:
- DLP‑системы (Data Loss Prevention).
- Принцип наименьших привилегий.
- Журналирование и мониторинг доступа.

### Ransomware‑утечки
Современный ransomware не просто шифрует, но и сперва выкачивает данные.
- Потом требует выкуп и за расшифровку, и за «непубликацию».

---

## 4. КОНФИГУРАЦИОННЫЕ ОШИБКИ (Misconfigurations)

Примеры:
- Открытые порты БД и RDP в интернет.
- Старые версии TLS (SSLv3, TLS 1.0) и слабые шифры (RC4, DES).
- Учётки с дефолтными логином/паролем (admin/admin).

---

## 5. ПРОДВИНУТЫЕ АТАКИ (Advanced)

### APT (Advanced Persistent Threat)
Долгосрочное скрытое присутствие в сети.
- Цели: госструктуры, крупный бизнес.

### MITM (Man‑in‑the‑Middle)
Перехват и изменение трафика.
- ARP spoofing, DNS spoofing, SSL stripping.

### DNS Tunneling
Вывод данных через DNS‑запросы (порт 53 разрешён почти везде).

### Zero‑Day Exploit
Эксплуатация уязвимости, о которой ещё нет патча.

---

## ФАЗЫ РЕАГИРОВАНИЯ НА ИНЦИДЕНТ

1. Detection – обнаружение (логи, алерты, IDS/IPS).
2. Containment – локализация (блокировка IP, сегментация сети).
3. Eradication – устранение (патчи, удаление вредоноса).
4. Recovery – восстановление (резервные копии, перезапуск сервисов).
5. Post‑incident – разбор и улучшение процессов.

---

## ДЕЙСТВИЯ В ЭТОЙ ИГРЕ

**BLOCK** – заблокировать источник атаки (IP, домен, порт).
**PATCH** – исправить конфигурацию или установить патч.
**ISOLATE** – изолировать хост/сегмент от сети.
**IGNORE** – признать событие ложным срабатыванием (false positive).`

func NewNetworkScreenV2(
	w fyne.Window,
	r NetworkRouter,
	u *domain.User,
	uc *usecase.NetworkUsecase,
	gameUC *usecase.GameUsecase,
	themeManager *ThemeManager,
) *NetworkScreenV2 {
	return &NetworkScreenV2{
		w:            w,
		router:       r,
		user:         u,
		uc:           uc,
		gameUC:       gameUC,
		themeManager: themeManager,
		showTheory:   true,
	}
}

func (s *NetworkScreenV2) showTheoryDialog() {
	richText := widget.NewRichTextFromMarkdown(networkTheoryText)
	richText.Wrapping = fyne.TextWrapWord
	scroll := container.NewVScroll(richText)
	scroll.SetMinSize(fyne.NewSize(1000, 750))
	dialog.ShowCustom("Теория: Сетевые атаки и инциденты", "Закрыть", scroll, s.w)
}

func (s *NetworkScreenV2) buildMenu() fyne.CanvasObject {
	btnTheory := widget.NewButton("Теория: Сетевые атаки и инциденты", func() {
		s.showTheoryDialog()
	})
	btnTheory.Importance = widget.LowImportance

	btnStart := widget.NewButton("Начать игру", func() {
		s.showTheory = false
		s.w.SetContent(s.Build())
	})
	btnStart.Importance = widget.HighImportance

	btnBack := widget.NewButton("Назад", func() {
		s.router.NavigateToDashboard(s.user)
	})

	menu := container.NewVBox(
		widget.NewLabelWithStyle("МОДУЛЬ: СЕТЕВЫЕ ИНЦИДЕНТЫ",
			fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
		widget.NewLabel(""),
		widget.NewLabel("Научитесь правильно реагировать на сетевые атаки и инциденты."),
		widget.NewLabel("Анализируйте логи и выбирайте действие: BLOCK, PATCH, ISOLATE или IGNORE."),
		widget.NewLabel(""),
		widget.NewSeparator(),
		widget.NewLabel(""),
		btnTheory,
		btnStart,
		widget.NewLabel(""),
		btnBack,
	)

	return container.NewCenter(menu)
}

func (s *NetworkScreenV2) Build() fyne.CanvasObject {
	if s.showTheory {
		return s.buildMenu()
	}
	return s.buildGameScreen()
}

func (s *NetworkScreenV2) buildGameScreen() fyne.CanvasObject {
	s.timerLbl = widget.NewLabel("00:00")
	s.timerLbl.TextStyle = fyne.TextStyle{Bold: true}
	s.timerLbl.Alignment = fyne.TextAlignCenter

	s.scoreLbl = widget.NewLabel("0")
	s.scoreLbl.TextStyle = fyne.TextStyle{Bold: true}

	s.comboLbl = widget.NewLabel("0")
	s.comboLbl.TextStyle = fyne.TextStyle{Bold: true}

	s.typeLbl = widget.NewLabel("")
	s.typeLbl.TextStyle = fyne.TextStyle{Bold: true}
	s.typeLbl.Wrapping = fyne.TextWrapWord

	if s.list == nil {
		s.list = widget.NewList(
			func() int { return len(s.incidents) },
			func() fyne.CanvasObject {
				return container.NewHBox(
					widget.NewLabel(""),
					widget.NewLabel(""),
				)
			},
			func(id widget.ListItemID, o fyne.CanvasObject) {
				if id < 0 || id >= widget.ListItemID(len(s.incidents)) {
					return
				}
				inc := s.incidents[id]
				c := o.(*fyne.Container)
				title := s.incidentTitle(inc)
				c.Objects[1].(*widget.Label).SetText(title)
			},
		)

		s.list.OnSelected = func(id widget.ListItemID) {
			s.cur = int(id)
			s.showIncident()
		}
	}

	s.logsContainer = container.NewVBox()

	btnBlock := widget.NewButton("BLOCK (Блокировать IP/источник)", func() { s.answer("block") })
	btnBlock.Importance = widget.HighImportance

	btnPatch := widget.NewButton("PATCH (Установить патч/исправить конфиг)", func() { s.answer("patch") })
	btnPatch.Importance = widget.HighImportance

	btnIsolate := widget.NewButton("ISOLATE (Изолировать систему)", func() { s.answer("isolate") })
	btnIsolate.Importance = widget.HighImportance

	btnIgnore := widget.NewButton("IGNORE (Игнорировать)", func() { s.answer("ignore") })

	btnBack := widget.NewButton("Назад в меню", func() {
		if s.cancel != nil {
			s.cancel()
		}
		s.router.NavigateToDashboard(s.user)
	})

	actions := container.NewVBox(
		widget.NewLabelWithStyle("Ваше решение:", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		btnBlock,
		btnPatch,
		btnIsolate,
		btnIgnore,
		layout.NewSpacer(),
		btnBack,
	)

	topBar := container.NewHBox(
		widget.NewLabel("Время:"),
		s.timerLbl,
		layout.NewSpacer(),
		widget.NewLabel("Очки:"),
		s.scoreLbl,
		widget.NewLabel("|"),
		widget.NewLabel("Комбо:"),
		s.comboLbl,
	)

	info := container.NewVBox(
		widget.NewLabelWithStyle("Тип инцидента:", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		s.typeLbl,
		widget.NewSeparator(),
		widget.NewLabelWithStyle("Логи инцидента:", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		s.logsContainer,
	)

	infoScroll := container.NewVScroll(info)

	right := container.NewBorder(
		topBar,
		actions,
		nil,
		nil,
		infoScroll,
	)

	split := container.NewHSplit(s.list, right)
	split.SetOffset(0.30)

	ctx := context.Background()
	incidents, err := s.uc.GenerateNetworkIncidents(ctx)
	if err != nil || len(incidents) == 0 {
		dialog.ShowError(fmt.Errorf("не удалось загрузить инциденты"), s.w)
		return split
	}

	s.incidents = incidents
	s.cur = 0
	s.list.Refresh()
	s.list.Select(0)

	s.start = time.Now()
	ctx2, cancel := context.WithCancel(context.Background())
	s.cancel = cancel
	go s.timerLoop(ctx2)

	return split
}

func (s *NetworkScreenV2) incidentTitle(inc domain.NetworkIncident) string {
	typeMap := map[string]string{
		"ddos_volumetric":               "DDoS: объёмная атака",
		"ddos_application":              "DDoS: уровень приложения",
		"ddos_syn_flood":                "DDoS: SYN‑флуд",
		"ddos_ntp_amplification":        "DDoS: NTP‑усиление",
		"intrusion_ssh_bruteforce":      "Взлом: SSH brute force",
		"intrusion_sqli":                "Взлом: SQL injection",
		"intrusion_rce":                 "Взлом: удалённое выполнение кода",
		"intrusion_path_traversal":      "Взлом: path traversal",
		"intrusion_xss":                 "Взлом: XSS",
		"intrusion_web_shell":           "Взлом: web‑shell",
		"leak_s3_bucket":                "Утечка: публичный S3‑bucket",
		"leak_database_dump":            "Утечка: дамп базы данных",
		"misconfig_firewall_open":       "Ошибка конфигурации: открытый firewall",
		"misconfig_default_credentials": "Ошибка конфигурации: дефолтные пароли",
		"malware_cryptominer":           "Вредонос: криптомайнер",
		"false_positive_scanner":        "False positive: внутренний сканер",
	}

	if title, ok := typeMap[inc.Type]; ok {
		return title
	}
	return "Неизвестный инцидент"
}

func (s *NetworkScreenV2) showIncident() {
	if len(s.incidents) == 0 || s.cur < 0 || s.cur >= len(s.incidents) {
		return
	}

	inc := s.incidents[s.cur]
	s.typeLbl.SetText(s.incidentTitle(inc))

	s.logsContainer.Objects = nil
	for _, log := range inc.Logs {
		lbl := widget.NewLabel(log)
		lbl.Wrapping = fyne.TextWrapWord
		if strings.Contains(log, "[CRITICAL]") || strings.Contains(log, "[ALERT]") {
			lbl.TextStyle = fyne.TextStyle{Bold: true}
		}
		s.logsContainer.Add(lbl)
	}
	s.logsContainer.Refresh()
}

func (s *NetworkScreenV2) answer(action string) {
	if len(s.incidents) == 0 {
		return
	}

	inc := s.incidents[s.cur]
	correct := inc.Action == action

	if correct {
		s.correct++
		s.combo++
		if s.combo > s.maxCombo {
			s.maxCombo = s.combo
		}
		s.score += 50 + (s.combo * 5)
	} else {
		s.wrong++
		s.combo = 0
		s.score -= 20
		if s.score < 0 {
			s.score = 0
		}
	}

	s.scoreLbl.SetText(fmt.Sprintf("%d", s.score))
	s.comboLbl.SetText(fmt.Sprintf("%d", s.combo))

	if s.gameUC != nil && s.user != nil {
		ctx, cancel := context.WithTimeout(context.Background(), 500*time.Millisecond)
		defer cancel()
		_ = s.gameUC.SaveGameResult(ctx, int64(s.user.ID), "network", s.score)
	}

	s.showExplanation(inc, action, correct)

	if s.cur+1 < len(s.incidents) {
		s.cur++
		s.list.Select(s.cur)
	} else {
		s.finish()
	}
}

func (s *NetworkScreenV2) showExplanation(inc domain.NetworkIncident, userAction string, correct bool) {
	status := "Неверное решение"
	if correct {
		status = "Правильное решение"
	}

	actionNames := map[string]string{
		"block":   "BLOCK (блокировка)",
		"patch":   "PATCH (патч/конфиг)",
		"isolate": "ISOLATE (изоляция)",
		"ignore":  "IGNORE (игнорирование)",
	}

	txt := fmt.Sprintf(`%s

Ваш ответ: %s

Правильный ответ: %s

Пояснение:

%s`,
		status,
		actionNames[userAction],
		actionNames[inc.Action],
		s.getIncidentExplanation(inc))

	dialog.ShowInformation("Разбор инцидента", txt, s.w)
}

func (s *NetworkScreenV2) getIncidentExplanation(inc domain.NetworkIncident) string {
	explanations := map[string]string{
		"block":   "Нужно заблокировать источник атаки (IP‑адрес, подсеть или домен) на firewall/WAF.",
		"patch":   "Следует исправить конфигурацию или установить патч безопасности, чтобы закрыть уязвимость.",
		"isolate": "Хост нужно изолировать от сети, чтобы не дать атакующему развить успех и предотвратить распространение.",
		"ignore":  "Это ложное срабатывание (false positive), реальной угрозы нет, достаточно мониторинга.",
	}
	return explanations[inc.Action]
}

func (s *NetworkScreenV2) timerLoop(ctx context.Context) {
	ticker := time.NewTicker(time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			el := time.Since(s.start).Truncate(time.Second)
			min := int(el.Minutes())
			sec := int(el.Seconds()) % 60
			s.timerLbl.SetText(fmt.Sprintf("%02d:%02d", min, sec))
		}
	}
}

func (s *NetworkScreenV2) finish() {
	if s.cancel != nil {
		s.cancel()
	}

	duration := time.Since(s.start).Truncate(time.Second)

	summary := fmt.Sprintf(`МОДУЛЬ: СЕТЕВЫЕ ИНЦИДЕНТЫ - ЗАВЕРШЁН

Правильных решений: %d
Ошибок: %d
Пропущено: %d
Макс. комбо: %d
Время: %s
Итоговые очки: %d

Помните: быстрая и правильная реакция на инциденты критически важна.`,
		s.correct, s.wrong, s.skipped, s.maxCombo, duration, s.score)

	if s.gameUC != nil && s.user != nil {
		ctx := context.Background()
		_ = s.gameUC.UpdateQuestsAfterGame(ctx, int64(s.user.ID), "network", s.score, s.correct)
		if s.wrong >= 3 {
			payload := fmt.Sprintf("Ошибки при выборе действий по сетевым инцидентам (%d ошибок)", s.wrong)
			_ = s.gameUC.AddWeakSpot(ctx, int64(s.user.ID), "network", payload)
		}
	}

	dialog.ShowInformation("Игра окончена", summary, s.w)
	s.router.NavigateToDashboard(s.user)
}
