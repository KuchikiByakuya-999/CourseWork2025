package screens

import (
	"context"
	"cyber-skeleton/internal/domain"
	"cyber-skeleton/internal/repository"
	"cyber-skeleton/internal/usecase"
	"fmt"
	"time"

	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/container"
	"fyne.io/fyne/v2/dialog"
	"fyne.io/fyne/v2/layout"
	"fyne.io/fyne/v2/widget"
)

type PasswordRouter interface {
	NavigateToDashboard(u *domain.User)
}

type PasswordScreenV2 struct {
	w          fyne.Window
	router     PasswordRouter
	uc         *usecase.PasswordUsecase
	user       *domain.User
	gameUC     *usecase.GameUsecase
	showTheory bool

	challenges []domain.PasswordChallenge
	cur        int

	start    time.Time
	cancel   context.CancelFunc
	score    int
	correct  int
	wrong    int
	skipped  int
	combo    int
	maxCombo int

	timerLbl    *widget.Label
	scoreLbl    *widget.Label
	comboLbl    *widget.Label
	list        *widget.List
	passwordLbl *widget.Label
	categoryLbl *widget.Label
	strengthLbl *widget.Label
}

func (s *PasswordScreenV2) MinSize() fyne.Size {
	return fyne.Size{Width: 1366, Height: 768}
}

var passwordTheoryText = `ТЕОРИЯ: ПАРОЛИ И АУТЕНТИФИКАЦИЯ

Основные концепции:
• Пароль – строка символов для подтверждения личности.
• Слабый пароль: короткий, предсказуемый.
• Сильный пароль: длинный, случайный, содержит разные типы символов.

Типы взлома паролей:
1. BRUTE FORCE (Перебор) – атакующий пробует все комбинации.
2. DICTIONARY ATTACK (Словарная атака) – использует распространённые пароли.
3. RAINBOW TABLES (Радужные таблицы) – предвычисленные хэши.
4. PHISHING (фишинг) – социальная инженерия для кражи пароля.
5. CREDENTIAL STUFFING (переброс учётных данных) – пароли из других утечек.

Принципы сильного пароля:
• Минимум 12–16 символов.
• Прописные и строчные буквы (A–Z, a–z).
• Цифры (0–9).
• Спецсимволы (!@#$%^&* и т.п.).
• Уникальный пароль для каждого сервиса.

Время перебора (при 10^9 попыток/сек):
• 6 символов: ≈ 1 секунда.
• 8 символов: ≈ 1 час.
• 10 символов: ≈ 2 месяца.
• 12+ символов с разными типами – годы и больше.

Менеджеры паролей:
• KeePass, 1Password, Bitwarden – генерируют и хранят сложные пароли.
• Один мастер‑пароль вместо десятков слабых.

Двухфакторная аутентификация (2FA):
• Добавляет второй слой защиты (TOTP, SMS, аппаратные ключи).

Практика:
• Не использовать личные данные и словарные слова.
• Проверять утечки (Have I Been Pwned).
• Включать 2FA везде, где возможно.`

func NewPasswordScreenV2(
	w fyne.Window,
	r PasswordRouter,
	u *domain.User,
	pwUC *usecase.PasswordUsecase,
	gameUC *usecase.GameUsecase,
) *PasswordScreenV2 {
	return &PasswordScreenV2{
		w:          w,
		router:     r,
		user:       u,
		uc:         pwUC,
		gameUC:     gameUC,
		showTheory: true,
	}
}

func (s *PasswordScreenV2) showTheoryDialog() {
	richText := widget.NewRichTextFromMarkdown(passwordTheoryText)
	richText.Wrapping = fyne.TextWrapWord

	scroll := container.NewVScroll(richText)
	scroll.SetMinSize(fyne.NewSize(1000, 750))

	dialog.ShowCustom("Теория: Пароли и аутентификация", "Закрыть", scroll, s.w)
}

func (s *PasswordScreenV2) buildMenu() fyne.CanvasObject {
	btnTheory := widget.NewButton("Теория: Пароли и аутентификация", func() {
		s.showTheoryDialog()
	})
	btnTheory.Importance = widget.LowImportance

	btnStart := widget.NewButton("Начать игру", func() {
		s.showTheory = false
		s.w.SetContent(s.Build())
	})
	btnStart.Importance = widget.HighImportance

	btnBack := widget.NewButton("Назад", func() {
		s.router.NavigateToDashboard(s.user)
	})

	menu := container.NewVBox(
		widget.NewLabelWithStyle("МОДУЛЬ: ПАРОЛИ И АУТЕНТИФИКАЦИЯ",
			fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
		widget.NewLabel(""),
		widget.NewLabel("Научитесь отличать слабые пароли от сильных."),
		widget.NewLabel("Вам предстоит оценить 15 паролей и определить их надёжность."),
		widget.NewLabel(""),
		widget.NewSeparator(),
		widget.NewLabel(""),
		btnTheory,
		btnStart,
		widget.NewLabel(""),
		btnBack,
	)

	return container.NewCenter(menu)
}

func (s *PasswordScreenV2) Build() fyne.CanvasObject {

	if s.showTheory {
		return s.buildMenu()
	}

	if s.timerLbl == nil {
		s.timerLbl = widget.NewLabel("Время: 00:00")
		s.scoreLbl = widget.NewLabel("Очки: 0")
		s.comboLbl = widget.NewLabel("Комбо: 0")
		s.passwordLbl = widget.NewLabel("")
		s.passwordLbl.TextStyle = fyne.TextStyle{Bold: true, Monospace: true}
		s.categoryLbl = widget.NewLabel("")
		s.strengthLbl = widget.NewLabel("")

		s.list = widget.NewList(
			func() int { return len(s.challenges) },
			func() fyne.CanvasObject {
				return widget.NewLabel("")
			},
			func(id widget.ListItemID, o fyne.CanvasObject) {
				if id < 0 || id >= len(s.challenges) {
					return
				}
				ch := s.challenges[id]
				o.(*widget.Label).SetText(
					fmt.Sprintf("Пароль #%d: %s", id+1, ch.Password),
				)
			},
		)

		s.list.OnSelected = func(id widget.ListItemID) {
			s.cur = int(id)
			s.showPassword()
		}
	}

	btnWeak := widget.NewButton("СЛАБЫЙ пароль", func() { s.answer(true) })
	btnWeak.Importance = widget.DangerImportance

	btnStrong := widget.NewButton("СИЛЬНЫЙ пароль", func() { s.answer(false) })
	btnStrong.Importance = widget.SuccessImportance

	btnHint := widget.NewButton(" Показать подсказку", func() { s.showHint() })

	btnBack := widget.NewButton("Выйти", func() {
		if s.cancel != nil {
			s.cancel()
		}
		s.router.NavigateToDashboard(s.user)
	})

	actions := container.NewVBox(
		widget.NewLabelWithStyle("Ваше решение:", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		btnWeak,
		btnStrong,
		widget.NewLabel(""),
		btnHint,
		layout.NewSpacer(),
		btnBack,
	)

	topBar := container.NewHBox(
		s.timerLbl,
		layout.NewSpacer(),
		s.scoreLbl,
		widget.NewLabel("|"),
		s.comboLbl,
	)

	info := container.NewVBox(
		widget.NewLabelWithStyle("Пароль:", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		s.passwordLbl,
		widget.NewLabel(""),
		widget.NewLabelWithStyle("Категория:", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		s.categoryLbl,
		widget.NewLabel(""),
		widget.NewLabelWithStyle("Сложность:", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		s.strengthLbl,
	)

	right := container.NewBorder(
		topBar,
		actions,
		nil,
		nil,
		container.NewVScroll(info),
	)

	split := container.NewHSplit(s.list, right)
	split.SetOffset(0.35)

	s.loadChallenges()
	return split
}

func (s *PasswordScreenV2) loadChallenges() {
	ctx, cancel := context.WithCancel(context.Background())
	s.cancel = cancel

	generatedChallenges := s.uc.GeneratePasswordChallenges(ctx)

	s.challenges = make([]domain.PasswordChallenge, len(generatedChallenges))
	for i, gc := range generatedChallenges {
		s.challenges[i] = s.convertChallenge(gc)
	}

	if len(s.challenges) == 0 {
		dialog.ShowInformation("Пароли", "Не удалось сгенерировать пароли", s.w)
		return
	}

	s.cur = 0
	s.list.Refresh()
	s.list.Select(0)
	s.showPassword()

	s.start = time.Now()
	go s.timerLoop(ctx)
}

func (s *PasswordScreenV2) convertChallenge(rc repository.PasswordChallenge) domain.PasswordChallenge {
	return domain.PasswordChallenge{
		Password: rc.Password,
		Hint:     rc.Hint,
		Strength: rc.Strength,
		IsWeak:   rc.IsWeak,
		Category: rc.Category,
	}
}

func (s *PasswordScreenV2) timerLoop(ctx context.Context) {
	ticker := time.NewTicker(time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			el := time.Since(s.start).Truncate(time.Second)
			min := int(el.Minutes())
			sec := int(el.Seconds()) % 60
			txt := fmt.Sprintf("Время: %02d:%02d", min, sec)

			fyne.Do(func() {
				s.timerLbl.SetText(txt)
			})
		}
	}
}

func (s *PasswordScreenV2) showPassword() {
	if len(s.challenges) == 0 || s.cur < 0 || s.cur >= len(s.challenges) {
		return
	}

	ch := s.challenges[s.cur]
	s.passwordLbl.SetText(ch.Password)
	s.categoryLbl.SetText(ch.Category)
}

func (s *PasswordScreenV2) showHint() {
	if len(s.challenges) == 0 || s.cur < 0 || s.cur >= len(s.challenges) {
		return
	}

	ch := s.challenges[s.cur]
	dialog.ShowInformation(" Подсказка", ch.Hint, s.w)
}

func (s *PasswordScreenV2) answer(isWeak bool) {
	if len(s.challenges) == 0 {
		return
	}

	ch := s.challenges[s.cur]
	correct := ch.IsWeak == isWeak

	if correct {
		s.correct++
		s.combo++
		if s.combo > s.maxCombo {
			s.maxCombo = s.combo
		}
		s.score += s.points(ch.Strength, true)
	} else {
		s.wrong++
		s.combo = 0
		s.score -= s.points(ch.Strength, false)
		if s.score < 0 {
			s.score = 0
		}
	}

	s.scoreLbl.SetText(fmt.Sprintf("Очки: %d", s.score))
	s.comboLbl.SetText(fmt.Sprintf("Комбо: %d", s.combo))

	s.showExplanation(ch, correct)

	if s.cur+1 < len(s.challenges) {
		s.cur++
		s.list.Select(s.cur)
	} else {
		s.finish()
	}
}

func (s *PasswordScreenV2) points(strength int, correct bool) int {
	base := strength * 10
	if correct {
		return base
	}
	return base / 2
}

func (s *PasswordScreenV2) showExplanation(ch domain.PasswordChallenge, correct bool) {
	status := "Ответ неверный"
	if correct {
		status = "Ответ верный"
	}

	verdict := "СЛАБЫЙ"
	if !ch.IsWeak {
		verdict = "СИЛЬНЫЙ"
	}

	txt := fmt.Sprintf(`%s

Правильный ответ: %s

 Объяснение:
%s`,
		status, verdict, ch.Hint)

	dialog.ShowInformation("Разбор пароля", txt, s.w)
}

func (s *PasswordScreenV2) finish() {
	if s.cancel != nil {
		s.cancel()
	}

	duration := time.Since(s.start).Truncate(time.Second)

	if s.user != nil && s.gameUC != nil {
		ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
		defer cancel()

		_ = s.gameUC.SaveGameResult(ctx, s.user.ID, "password", s.score)
	}

	summary := fmt.Sprintf(`МОДУЛЬ: ПАРОЛИ - ЗАВЕРШЁН

Правильных: %d
Ошибок: %d
Макс. комбо: %d
Время: %s
Итоговые очки: %d

Помните: используйте длинные и уникальные пароли для каждого сервиса!
 Рекомендуем: менеджер паролей + 2FA везде!`,
		s.correct, s.wrong, s.maxCombo, duration, s.score)

	dialog.ShowInformation("Игра окончена", summary, s.w)
	s.router.NavigateToDashboard(s.user)
}
