package screens

import (
	"context"
	"fmt"
	"time"

	"cyber-skeleton/internal/domain"
	"cyber-skeleton/internal/usecase"

	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/canvas"
	"fyne.io/fyne/v2/container"
	"fyne.io/fyne/v2/layout"
	"fyne.io/fyne/v2/widget"
)

type DashboardScreenV2 struct {
	w            fyne.Window
	router       DashboardRouter
	user         domain.User
	phishUC      *usecase.PhishingUsecase
	passwordUC   *usecase.PasswordUsecase
	networkUC    *usecase.NetworkUsecase
	gameUC       *usecase.GameUsecase
	themeManager ThemeManager
	refreshChan  chan bool
}

type DashboardRouter interface {
	NavigateToPasswordGame()
	NavigateToPhishingGame()
	NavigateToNetworkGame()
	NavigateToCryptoGame()
	NavigateToMalwareGame()
	NavigateToProfile(u *domain.User)
}

func NewDashboardScreenV2(
	w fyne.Window,
	r DashboardRouter,
	u domain.User,
	phishUC *usecase.PhishingUsecase,
	passwordUC *usecase.PasswordUsecase,
	networkUC *usecase.NetworkUsecase,
	gameUC *usecase.GameUsecase,
	themeManager ThemeManager,
) *DashboardScreenV2 {
	return &DashboardScreenV2{
		w:            w,
		router:       r,
		user:         u,
		phishUC:      phishUC,
		passwordUC:   passwordUC,
		networkUC:    networkUC,
		gameUC:       gameUC,
		themeManager: themeManager,
		refreshChan:  make(chan bool, 1),
	}
}

func (d *DashboardScreenV2) Build() fyne.CanvasObject {
	theme := d.themeManager.GetCurrentTheme()

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	go func() {
		defer cancel()
		if d.phishUC != nil {
			d.phishUC.GeneratePhishingMails(ctx)
		}
		if d.passwordUC != nil {
			d.passwordUC.GeneratePasswordChallenges(ctx)
		}
		if d.networkUC != nil {
			d.networkUC.GenerateNetworkIncidents(ctx)
		}
	}()

	mainPage := d.buildMainPage()
	trainingPage := d.buildTrainingPage()
	progressPage := d.buildProgressPage()
	leaderboardPage := d.buildLeaderboardPage()
	profileStub := widget.NewLabel("Открывается отдельный экран профиля")

	stacked := container.NewStack(
		mainPage,
		trainingPage,
		progressPage,
		leaderboardPage,
		profileStub,
	)

	stacked.Objects[1].Hide()
	stacked.Objects[2].Hide()
	stacked.Objects[3].Hide()
	stacked.Objects[4].Hide()

	side := d.buildSideMenu(stacked)
	bg := canvas.NewRectangle(theme.Background)

	content := container.NewBorder(
		nil,
		nil,
		side,
		nil,
		stacked,
	)

	return container.NewMax(bg, content)
}

func (d *DashboardScreenV2) buildMainPage() fyne.CanvasObject {
	theme := d.themeManager.GetCurrentTheme()

	bigTitle := canvas.NewText("CYBERBASICS", theme.Primary)
	bigTitle.TextSize = 52
	bigTitle.Alignment = fyne.TextAlignCenter

	subtitle := widget.NewLabelWithStyle(
		"Интерактивное обучение кибербезопасности.",
		fyne.TextAlignCenter,
		fyne.TextStyle{},
	)

	welcome := widget.NewLabelWithStyle(
		fmt.Sprintf("Добро пожаловать, %s", d.user.Username),
		fyne.TextAlignCenter,
		fyne.TextStyle{},
	)

	statsBox := d.buildQuickStats()
	questsBox := d.buildWeeklyQuests()
	activityBox := d.buildRecentActivity()
	rankBox := d.buildRankCard()
	weakBox := d.buildWeakSpots()

	leftColumn := container.NewVBox(
		statsBox,
		rankBox,
		questsBox,
	)

	rightColumn := container.NewVBox(
		activityBox,
		weakBox,
	)

	columns := container.NewHBox(
		leftColumn,
		rightColumn,
	)

	center := container.NewVBox(
		layout.NewSpacer(),
		welcome,
		bigTitle,
		subtitle,
		widget.NewSeparator(),
		columns,
		layout.NewSpacer(),
	)

	scroll := container.NewVScroll(center)
	return scroll
}

func (d *DashboardScreenV2) buildQuickStats() fyne.CanvasObject {
	theme := d.themeManager.GetCurrentTheme()
	ctx := context.Background()

	stats, err := d.gameUC.GetDetailedStats(ctx, d.user.ID)
	if err != nil {
		return widget.NewLabel("Не удалось загрузить статистику")
	}

	cardBg := canvas.NewRectangle(theme.Surface)
	cardBg.StrokeColor = theme.Border
	cardBg.StrokeWidth = 1
	cardBg.CornerRadius = 8

	content := container.NewVBox(
		widget.NewLabelWithStyle("Быстрые показатели", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		widget.NewSeparator(),
		widget.NewLabel(fmt.Sprintf("Общий опыт: %d XP", stats.TotalXP)),
		widget.NewLabel(fmt.Sprintf("Сыграно игр: %d", stats.GamesPlayed)),
		widget.NewLabel(fmt.Sprintf("Уровень: %d (%s)", stats.Level, stats.Rank)),
	)

	card := container.NewMax(cardBg, container.NewPadded(content))
	card.Resize(fyne.NewSize(350, 150))
	return card
}

func (d *DashboardScreenV2) buildRankCard() fyne.CanvasObject {
	theme := d.themeManager.GetCurrentTheme()
	ctx := context.Background()

	rank, err := d.gameUC.GetUserGlobalRank(ctx, d.user.ID)
	if err != nil {
		rank = 0
	}

	cardBg := canvas.NewRectangle(theme.Surface)
	cardBg.StrokeColor = theme.Border
	cardBg.StrokeWidth = 1
	cardBg.CornerRadius = 8

	rankText := fmt.Sprintf("Ты на %d месте в рейтинге", rank)
	if rank == 0 {
		rankText = "Сыграй игру, чтобы попасть в рейтинг"
	}

	content := container.NewVBox(
		widget.NewLabelWithStyle("Твоя позиция", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		widget.NewSeparator(),
		widget.NewLabel(rankText),
	)

	card := container.NewMax(cardBg, container.NewPadded(content))
	card.Resize(fyne.NewSize(350, 100))
	return card
}

func (d *DashboardScreenV2) buildWeeklyQuests() fyne.CanvasObject {
	theme := d.themeManager.GetCurrentTheme()
	ctx := context.Background()

	quests, err := d.gameUC.GetOrCreateWeeklyQuests(ctx, d.user.ID)
	if err != nil || len(quests) == 0 {
		return widget.NewLabel("")
	}

	rows := []fyne.CanvasObject{
		widget.NewLabelWithStyle("Задания недели", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		widget.NewSeparator(),
	}

	for _, q := range quests {
		status := "В процессе"
		if q.Completed {
			status = "Выполнено"
		}
		row := widget.NewLabel(fmt.Sprintf("%s\n%s\n%s", q.Title, q.Description, status))
		row.Wrapping = fyne.TextWrapWord
		rows = append(rows, row)
		rows = append(rows, widget.NewSeparator())
	}

	cardBg := canvas.NewRectangle(theme.Surface)
	cardBg.StrokeColor = theme.Border
	cardBg.StrokeWidth = 1
	cardBg.CornerRadius = 8

	box := container.NewVBox(rows...)
	card := container.NewMax(cardBg, container.NewPadded(box))
	card.Resize(fyne.NewSize(350, 250))
	return card
}

func (d *DashboardScreenV2) buildRecentActivity() fyne.CanvasObject {
	theme := d.themeManager.GetCurrentTheme()
	ctx := context.Background()

	activities, err := d.gameUC.GetRecentActivity(ctx, d.user.ID)
	if err != nil || len(activities) == 0 {
		return widget.NewLabel("")
	}

	rows := []fyne.CanvasObject{
		widget.NewLabelWithStyle("Последняя активность", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		widget.NewSeparator(),
	}

	for _, act := range activities {
		elapsed := time.Since(act.LastPlayed)
		timeStr := formatDuration(elapsed)

		trendIcon := "стабильно"
		if act.RecentTrend == "up" {
			trendIcon = "растёт"
		} else if act.RecentTrend == "down" {
			trendIcon = "падает"
		}

		row := widget.NewLabel(fmt.Sprintf("%s\nСыграл: %s назад\nСредний балл: %.0f (%s)",
			act.ModuleName,
			timeStr,
			act.AvgScore,
			trendIcon,
		))
		row.Wrapping = fyne.TextWrapWord
		rows = append(rows, row)
		rows = append(rows, widget.NewSeparator())
	}

	cardBg := canvas.NewRectangle(theme.Surface)
	cardBg.StrokeColor = theme.Border
	cardBg.StrokeWidth = 1
	cardBg.CornerRadius = 8

	box := container.NewVBox(rows...)
	card := container.NewMax(cardBg, container.NewPadded(box))
	card.Resize(fyne.NewSize(350, 300))
	return card
}

func (d *DashboardScreenV2) buildWeakSpots() fyne.CanvasObject {
	theme := d.themeManager.GetCurrentTheme()
	ctx := context.Background()

	stats, err := d.gameUC.GetDetailedStats(ctx, d.user.ID)
	if err != nil || len(stats.WeakSpots) == 0 {
		return widget.NewLabel("")
	}

	rows := []fyne.CanvasObject{
		widget.NewLabelWithStyle("Твои слабые места", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		widget.NewSeparator(),
	}

	moduleNames := map[string]string{
		"phishing":  "Фишинг",
		"passwords": "Пароли",
		"network":   "Сетевые инциденты",
		"crypto":    "Криптография",
		"malware":   "Malware",
	}

	for code, spots := range stats.WeakSpots {
		if len(spots) == 0 {
			continue
		}

		moduleName := moduleNames[code]
		rows = append(rows, widget.NewLabelWithStyle(moduleName, fyne.TextAlignLeading, fyne.TextStyle{Italic: true}))

		for _, spot := range spots {
			label := widget.NewLabel(spot)
			label.Wrapping = fyne.TextWrapWord
			rows = append(rows, label)
		}
		rows = append(rows, widget.NewSeparator())
	}

	cardBg := canvas.NewRectangle(theme.Surface)
	cardBg.StrokeColor = theme.Border
	cardBg.StrokeWidth = 1
	cardBg.CornerRadius = 8

	box := container.NewVBox(rows...)
	card := container.NewMax(cardBg, container.NewPadded(box))
	card.Resize(fyne.NewSize(350, 250))
	return card
}

func (d *DashboardScreenV2) buildTrainingPage() fyne.CanvasObject {
	theme := d.themeManager.GetCurrentTheme()
	title := widget.NewLabelWithStyle(
		"Обучение",
		fyne.TextAlignLeading,
		fyne.TextStyle{Bold: true},
	)

	cards := []fyne.CanvasObject{
		d.lessonCard("Фишинг", "Распознавание фишинговых писем и ссылок", "Начать", theme, func() {
			d.router.NavigateToPhishingGame()
		}),
		d.lessonCard("Пароли", "Сильные пароли и аутентификация", "Начать", theme, func() {
			d.router.NavigateToPasswordGame()
		}),
		d.lessonCard("Сети", "Инциденты и защита сети", "Начать", theme, func() {
			d.router.NavigateToNetworkGame()
		}),
		d.lessonCard("Криптография", "Шифрование и защита данных", "Начать", theme, func() {
			d.router.NavigateToCryptoGame()
		}),
		d.lessonCard("Malware", "Анализ вредоносного ПО", "Начать", theme, func() {
			d.router.NavigateToMalwareGame()
		}),
	}

	grid := container.NewGridWithColumns(3, cards...)

	return container.NewPadded(
		container.NewVBox(
			title,
			grid,
		),
	)
}

func (d *DashboardScreenV2) buildProgressPage() fyne.CanvasObject {
	theme := d.themeManager.GetCurrentTheme()
	title := widget.NewLabelWithStyle(
		"Прогресс",
		fyne.TextAlignLeading,
		fyne.TextStyle{Bold: true},
	)

	ctx := context.Background()
	stats, err := d.gameUC.GetUserStats(ctx, d.user.ID)
	if err != nil {
		return container.NewPadded(container.NewVBox(
			title,
			widget.NewLabel("Не удалось загрузить прогресс."),
		))
	}

	modulesRaw, ok := stats["modules"].(map[string]map[string]interface{})
	if !ok {
		return container.NewPadded(container.NewVBox(
			title,
			widget.NewLabel("Данные прогресса недоступны."),
		))
	}

	order := []string{"phishing", "passwords", "network", "crypto", "malware", "socialeng"}
	rows := []fyne.CanvasObject{title}

	for _, code := range order {
		mod, exists := modulesRaw[code]
		if !exists {
			continue
		}

		name, _ := mod["name"].(string)
		progStr, _ := mod["progress"].(string)

		var progVal int
		fmt.Sscanf(progStr, "%d%%", &progVal)

		rows = append(rows, d.progressRow(name, progVal))
	}

	bg := canvas.NewRectangle(theme.Surface)
	box := container.NewVBox(rows...)

	return container.NewMax(
		bg,
		container.NewPadded(box),
	)
}

func (d *DashboardScreenV2) buildLeaderboardPage() fyne.CanvasObject {
	theme := d.themeManager.GetCurrentTheme()
	ctx := context.Background()

	title := widget.NewLabelWithStyle(
		"Рейтинг",
		fyne.TextAlignLeading,
		fyne.TextStyle{Bold: true},
	)

	leaderboard, err := d.gameUC.GetGlobalLeaderboard(ctx, 10)
	if err != nil || len(leaderboard) == 0 {
		return container.NewPadded(container.NewVBox(
			title,
			widget.NewLabel("Рейтинг пока пуст. Сыграй первым!"),
		))
	}

	rows := []fyne.CanvasObject{title, widget.NewSeparator()}

	for _, entry := range leaderboard {
		prefix := fmt.Sprintf("%d.", entry.Rank)
		highlight := entry.UserID == d.user.ID

		var row *widget.Label
		if highlight {
			row = widget.NewLabelWithStyle(
				fmt.Sprintf("%s %s — %d XP (ты)", prefix, entry.Username, entry.TotalXP),
				fyne.TextAlignLeading,
				fyne.TextStyle{Bold: true},
			)
		} else {
			row = widget.NewLabel(fmt.Sprintf("%s %s — %d XP", prefix, entry.Username, entry.TotalXP))
		}

		rows = append(rows, row)
	}

	cardBg := canvas.NewRectangle(theme.Surface)
	cardBg.StrokeColor = theme.Border
	cardBg.StrokeWidth = 1
	cardBg.CornerRadius = 8

	box := container.NewVBox(rows...)

	return container.NewMax(
		cardBg,
		container.NewPadded(box),
	)
}

func (d *DashboardScreenV2) progressRow(name string, value int) fyne.CanvasObject {
	lbl := widget.NewLabel(name)
	bar := widget.NewProgressBar()
	bar.Min = 0
	bar.Max = 100
	bar.SetValue(float64(value))
	percent := widget.NewLabel(fmt.Sprintf("%d%%", value))

	return container.NewBorder(
		nil,
		nil,
		lbl,
		percent,
		bar,
	)
}

func (d *DashboardScreenV2) buildSideMenu(stacked *fyne.Container) fyne.CanvasObject {
	theme := d.themeManager.GetCurrentTheme()

	btnMain := widget.NewButton("Главная", func() {
		d.showPage(stacked, 0)
	})
	btnTraining := widget.NewButton("Обучение", func() {
		d.showPage(stacked, 1)
	})
	btnProgress := widget.NewButton("Прогресс", func() {
		d.showPage(stacked, 2)
	})
	btnLeaderboard := widget.NewButton("Рейтинг", func() {
		d.showPage(stacked, 3)
	})
	btnProfile := widget.NewButton("Профиль", func() {
		d.router.NavigateToProfile(&d.user)
	})

	for _, b := range []*widget.Button{btnMain, btnTraining, btnProgress, btnLeaderboard, btnProfile} {
		b.Alignment = widget.ButtonAlignLeading
		b.Importance = widget.MediumImportance
	}

	box := container.NewVBox(
		btnMain,
		btnTraining,
		btnProgress,
		btnLeaderboard,
		widget.NewSeparator(),
		btnProfile,
	)

	sideBg := canvas.NewRectangle(theme.Surface)

	side := container.NewMax(
		sideBg,
		container.NewPadded(box),
	)

	side.Resize(fyne.NewSize(190, 400))
	return side
}

func (d *DashboardScreenV2) showPage(stacked *fyne.Container, index int) {
	for i := range stacked.Objects {
		if i == index {
			stacked.Objects[i].Show()
		} else {
			stacked.Objects[i].Hide()
		}
	}
	stacked.Refresh()
}

func (d *DashboardScreenV2) lessonCard(title, desc, action string, theme ThemePalette, onTap func()) fyne.CanvasObject {
	bg := canvas.NewRectangle(theme.Surface)
	bg.StrokeColor = theme.Border
	bg.StrokeWidth = 1
	bg.CornerRadius = 8

	titleLbl := widget.NewLabelWithStyle(title, fyne.TextAlignLeading, fyne.TextStyle{Bold: true})
	descLbl := widget.NewLabel(desc)
	descLbl.Wrapping = fyne.TextWrapWord

	actionBtn := widget.NewButton(action, onTap)
	actionBtn.Importance = widget.HighImportance

	box := container.NewVBox(
		titleLbl,
		widget.NewSeparator(),
		descLbl,
		layout.NewSpacer(),
		actionBtn,
	)

	card := container.NewMax(
		bg,
		container.NewPadded(box),
	)

	card.Resize(fyne.NewSize(230, 170))
	return card
}

func (d *DashboardScreenV2) Refresh() {
	select {
	case d.refreshChan <- true:
	default:
	}
}

func formatDuration(d time.Duration) string {
	if d < time.Minute {
		return "только что"
	}
	if d < time.Hour {
		return fmt.Sprintf("%d мин", int(d.Minutes()))
	}
	if d < 24*time.Hour {
		return fmt.Sprintf("%d ч", int(d.Hours()))
	}
	return fmt.Sprintf("%d дн", int(d.Hours()/24))
}
