package screens

import (
	"context"
	"cyber-skeleton/internal/domain"
	"cyber-skeleton/internal/security"
	"cyber-skeleton/internal/usecase"
	"errors"
	"strings"

	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/canvas"
	"fyne.io/fyne/v2/container"
	"fyne.io/fyne/v2/dialog"
	"fyne.io/fyne/v2/layout"
	"fyne.io/fyne/v2/widget"
)

type LoginRouter interface {
	NavigateToDashboard(u *domain.User)
	ShowRegisterScreen()
}

type LoginScreen struct {
	window       fyne.Window
	router       LoginRouter
	uc           *usecase.AuthUsecase
	themeManager *ThemeManager
}

func NewLoginScreen(w fyne.Window, r LoginRouter, uc *usecase.AuthUsecase, tm *ThemeManager) *LoginScreen {
	return &LoginScreen{window: w, router: r, uc: uc, themeManager: tm}
}

func (s *LoginScreen) Build() fyne.CanvasObject {
	theme := s.themeManager.GetCurrentTheme()

	loginEntry := widget.NewEntry()
	loginEntry.SetPlaceHolder("Логин или email")

	passwordEntry := widget.NewPasswordEntry()
	passwordEntry.SetPlaceHolder("Пароль")

	loginBtn := widget.NewButton("Войти", func() {
		login := strings.TrimSpace(loginEntry.Text)
		pass := passwordEntry.Text

		if login == "" || pass == "" {
			dialog.ShowError(errors.New("заполните все поля"), s.window)
			return
		}

		login = security.SanitizeInput(login)
		pass = security.SanitizeInput(pass)

		if len(login) > 64 {
			login = login[:64]
		}
		if len(pass) > 128 {
			pass = pass[:128]
		}

		u, err := s.uc.Login(context.Background(), login, pass)
		if err != nil {
			dialog.ShowError(err, s.window)
			return
		}

		s.router.NavigateToDashboard(u)
	})
	loginBtn.Importance = widget.HighImportance

	registerLink := widget.NewButton("Создать аккаунт", func() {
		s.router.ShowRegisterScreen()
	})
	registerLink.Importance = widget.LowImportance

	title := widget.NewLabelWithStyle("CYBERBASICS", fyne.TextAlignCenter, fyne.TextStyle{Bold: true})
	subtitle := widget.NewLabelWithStyle("Вход", fyne.TextAlignCenter, fyne.TextStyle{})

	form := container.NewVBox(
		title,
		subtitle,
		widget.NewSeparator(),
		widget.NewLabel("Логин или email"),
		loginEntry,
		widget.NewLabel("Пароль"),
		passwordEntry,
		loginBtn,
		registerLink,
	)

	cardBg := canvas.NewRectangle(theme.Surface)
	cardBg.StrokeColor = theme.Border
	cardBg.StrokeWidth = 1
	cardBg.CornerRadius = 8

	card := container.NewMax(
		cardBg,
		container.NewPadded(form),
	)
	card.Resize(fyne.NewSize(1366, 768))

	bg := canvas.NewRectangle(theme.Background)

	return container.NewMax(
		bg,
		container.NewBorder(
			nil, nil, nil, nil,
			container.NewCenter(
				container.NewVBox(
					layout.NewSpacer(),
					card,
					layout.NewSpacer(),
				),
			),
		),
	)
}
