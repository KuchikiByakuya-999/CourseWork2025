package fyneui

import (
	"cyber-skeleton/internal/delivery/fyneui/screens"
	"cyber-skeleton/internal/domain"
	"cyber-skeleton/internal/usecase"

	"fyne.io/fyne/v2"
)

type Router struct {
	window       fyne.Window
	authUC       *usecase.AuthUsecase
	phishUC      *usecase.PhishingUsecase
	passwordUC   *usecase.PasswordUsecase
	networkUC    *usecase.NetworkUsecase
	cryptoUC     *usecase.CryptoUsecase
	gameUC       *usecase.GameUsecase
	courseUC     *usecase.CourseUsecase
	themeManager *screens.ThemeManager
	currentUser  *domain.User
}

func NewRouter(
	w fyne.Window,
	authUC *usecase.AuthUsecase,
	phishUC *usecase.PhishingUsecase,
	passwordUC *usecase.PasswordUsecase,
	networkUC *usecase.NetworkUsecase,
	cryptoUC *usecase.CryptoUsecase,
	gameUC *usecase.GameUsecase,
	courseUC *usecase.CourseUsecase,
) *Router {
	return &Router{
		window:       w,
		authUC:       authUC,
		phishUC:      phishUC,
		passwordUC:   passwordUC,
		networkUC:    networkUC,
		cryptoUC:     cryptoUC,
		gameUC:       gameUC,
		courseUC:     courseUC,
		themeManager: screens.NewThemeManager(),
	}
}

func (r *Router) ShowLoginScreen() {
	screen := screens.NewLoginScreen(r.window, r, r.authUC, r.themeManager)
	r.window.SetContent(screen.Build())
}

func (r *Router) ShowRegisterScreen() {
	screen := screens.NewRegisterScreen(r.window, r, r.authUC, r.themeManager)
	r.window.SetContent(screen.Build())
}

func (r *Router) NavigateToAuth() {
	r.ShowLoginScreen()
}

func (r *Router) NavigateToDashboard(u *domain.User) {
	r.currentUser = u
	screen := screens.NewDashboardScreenV2(
		r.window,
		r,
		*u,
		r.phishUC,
		r.passwordUC,
		r.networkUC,
		r.gameUC,
		*r.themeManager,
	)
	r.window.SetContent(screen.Build())
}

func (r *Router) NavigateToPasswordGame() {
	if r.currentUser == nil {
		r.ShowLoginScreen()
		return
	}
	screen := screens.NewPasswordScreenV2(r.window, r, r.currentUser, r.passwordUC, r.gameUC)
	r.window.SetContent(screen.Build())
}

func (r *Router) NavigateToPhishingGame() {
	if r.currentUser == nil {
		r.ShowLoginScreen()
		return
	}

	screen := screens.NewPhishingScreen(
		r.window,
		r,
		r.currentUser,
		r.phishUC,
		domain.PhishingModeClassic,
		domain.PhishingLevelEasy,
		r.gameUC,
	)

	r.window.SetContent(screen.Build())
}

func (r *Router) NavigateToNetworkGame() {
	if r.currentUser == nil {
		r.ShowLoginScreen()
		return
	}
	screen := screens.NewNetworkScreenV2(r.window, r, r.currentUser, r.networkUC, r.gameUC, r.themeManager)
	r.window.SetContent(screen.Build())
}

func (r *Router) NavigateToCryptoGame() {
	if r.currentUser == nil {
		r.ShowLoginScreen()
		return
	}
	screen := screens.NewCryptoScreen(r.window, r, r.currentUser, r.gameUC)
	r.window.SetContent(screen.Build())
}

func (r *Router) NavigateToMalwareGame() {
	if r.currentUser == nil {
		r.ShowLoginScreen()
		return
	}
	screen := screens.NewMalwareScreen(r.window, r, r.currentUser, r.gameUC, r.themeManager)
	r.window.SetContent(screen.Build())
}

func (r *Router) NavigateToProfile(u *domain.User) {
	if u == nil {
		r.ShowLoginScreen()
		return
	}
	screen := screens.NewProfileScreenV2(r.window, r, u, r.gameUC)
	r.window.SetContent(screen.Build())
}
