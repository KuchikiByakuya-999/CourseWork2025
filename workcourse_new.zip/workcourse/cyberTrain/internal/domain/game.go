package domain

import "time"

type GameResult struct {
	ID        int64
	UserID    int64
	GameCode  string
	Score     int
	MaxScore  int
	CreatedAt time.Time
}

type GameType string

const (
	GamePhishing GameType = "phishing"
	GamePassword GameType = "password"
	GameNetwork  GameType = "network"
)

type PasswordChallenge struct {
	ID       int64
	Password string
	Hint     string
	Strength int
	IsWeak   bool
	Category string
}

type NetworkIncident struct {
	ID     int64
	Type   string
	Logs   []string
	Action string
}

type CryptoChallenge struct {
	ID         int64
	CipherType string
	Ciphertext string
	Plaintext  string
	Hint       string
	Key        string
	Difficulty int
}

type CryptoResult struct {
	UserID      int64
	ChallengeID int64
	Correct     bool
	TimeSpent   int64
	Attempts    int
}

type MalwareChallenge struct {
	ID          int64
	MalwareType string
	Behavior    string
	IOCs        []string
	Symptoms    []string
	Mitigation  []string
	Difficulty  int
}

type MalwareAnalysisResult struct {
	UserID       int64
	ChallengeID  int64
	MalwareTypes []string
	ActionsFound []string
	Correct      int
	Wrong        int
}
