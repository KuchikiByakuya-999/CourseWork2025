package domain

import "time"

type PhishingLevel int

const (
	PhishingLevelEasy   PhishingLevel = 0
	PhishingLevelMedium PhishingLevel = 1
	PhishingLevelHard   PhishingLevel = 2
)

type PhishingMode int

const (
	PhishingModeClassic  PhishingMode = 0
	PhishingModeSurvival PhishingMode = 1
)

type PhishingMail struct {
	ID          int64
	Level       PhishingLevel
	Channel     string
	From        string
	Subject     string
	Body        string
	Url         string
	HasAttach   bool
	IsPhishing  bool
	Explanation string
	RedFlags    []string
}

type PhishingResult struct {
	UserID   int64
	Mode     PhishingMode
	Level    PhishingLevel
	Score    int
	Correct  int
	Wrong    int
	Skipped  int
	MaxCombo int
	Duration time.Duration
}
