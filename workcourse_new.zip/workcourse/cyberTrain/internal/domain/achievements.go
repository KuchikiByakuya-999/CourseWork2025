package domain

import "time"

type Achievement struct {
	Code        string
	Title       string
	Description string
	Unlocked    bool
}

type WeeklyQuest struct {
	ID          int64
	UserID      int64
	Code        string
	Title       string
	Description string
	TargetScore int
	ModuleCode  string
	Completed   bool
	ExpiresAt   time.Time
}

type UserRank struct {
	UserID   int64
	Username string
	TotalXP  int
	Rank     int
}

type ModuleActivity struct {
	ModuleCode  string
	ModuleName  string
	LastPlayed  time.Time
	AvgScore    float64
	RecentTrend string
}
