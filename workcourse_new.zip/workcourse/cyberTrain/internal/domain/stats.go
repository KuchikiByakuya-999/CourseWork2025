package domain

import "time"

type ModuleStat struct {
	GameCode   string
	Attempts   int
	TotalScore int
	BestScore  int
	LastScore  int
	LastPlayed time.Time
}

type UserStatistics struct {
	TotalXP     int
	GamesPlayed int
	Level       int
	Rank        string
	GlobalRank  int
	ModuleStats map[string]ModuleStat
	RecentGames []GameResult
	Activities  []ModuleActivity
	WeakSpots   map[string][]string
}
