package security

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"regexp"
	"strings"
	"unicode"
)

func IsSafeSQLString(input string) bool {
	dangerousPatterns := []string{
		"DROP",
		"DELETE",
		"INSERT",
		"UPDATE",
		"ALTER",
		"EXEC",
		"EXECUTE",
		"UNION",
		"SELECT",
		"--",
		"/*",
		"*/",
		";",
		"'",
		"\"",
		"\\",
	}

	upper := strings.ToUpper(input)
	for _, pattern := range dangerousPatterns {
		if strings.Contains(upper, pattern) {
			return false
		}
	}
	return true
}

func SanitizeInput(input string) string {
	dangerous := []string{"'", "\"", ";", "--", "/*", "*/", "\\"}
	result := input
	for _, char := range dangerous {
		result = strings.ReplaceAll(result, char, "")
	}
	return strings.TrimSpace(result)
}

func ValidatePassword(password string) map[string]interface{} {
	result := map[string]interface{}{
		"valid":  true,
		"score":  0,
		"errors": []string{},
	}

	errors := []string{}
	score := 0

	if len(password) < 8 {
		errors = append(errors, "Пароль должен быть минимум 8 символов")
		result["valid"] = false
	} else if len(password) >= 8 && len(password) < 12 {
		score += 1
	} else if len(password) >= 12 {
		score += 2
	}

	hasUpper := false
	for _, ch := range password {
		if unicode.IsUpper(ch) {
			hasUpper = true
			break
		}
	}
	if !hasUpper {
		errors = append(errors, "Пароль должен содержать заглавные буквы")
		result["valid"] = false
	} else {
		score += 1
	}

	hasLower := false
	for _, ch := range password {
		if unicode.IsLower(ch) {
			hasLower = true
			break
		}
	}
	if !hasLower {
		errors = append(errors, "Пароль должен содержать строчные буквы")
		result["valid"] = false
	} else {
		score += 1
	}

	hasDigit := false
	for _, ch := range password {
		if unicode.IsDigit(ch) {
			hasDigit = true
			break
		}
	}
	if !hasDigit {
		errors = append(errors, "Пароль должен содержать цифры")
		result["valid"] = false
	} else {
		score += 1
	}

	hasSpecial := false
	specialChars := "!@#$%^&*()_+-=[]{}|;:,.<>?"
	for _, ch := range password {
		if strings.ContainsRune(specialChars, ch) {
			hasSpecial = true
			break
		}
	}
	if hasSpecial {
		score += 2
	}

	forbiddenSequences := []string{
		"123456", "password", "qwerty", "123123", "111111",
		"000000", "aaaa", "admin", "letmein", "welcome",
	}
	for _, seq := range forbiddenSequences {
		if strings.Contains(strings.ToLower(password), seq) {
			errors = append(errors, "Пароль содержит распространённую последовательность")
			result["valid"] = false
			score = 0
			break
		}
	}

	result["score"] = score
	result["errors"] = errors

	return result
}

func IsValidEmail(email string) bool {
	emailRegex := regexp.MustCompile(`^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$`)
	return emailRegex.MatchString(email)
}

func IsValidUsername(username string) bool {
	if len(username) < 3 || len(username) > 20 {
		return false
	}

	usernameRegex := regexp.MustCompile(`^[a-zA-Z0-9_]+$`)
	return usernameRegex.MatchString(username)
}

func HashPassword(password, salt string) string {
	combined := password + salt
	hash := sha256.Sum256([]byte(combined))
	return hex.EncodeToString(hash[:])
}

func EscapeHTML(input string) string {
	replacer := strings.NewReplacer(
		"<", "&lt;",
		">", "&gt;",
		"\"", "&quot;",
		"'", "&#39;",
		"&", "&amp;",
	)
	return replacer.Replace(input)
}

func ValidateInput(input string, fieldType string) (bool, string) {
	if strings.TrimSpace(input) == "" {
		return false, fmt.Sprintf("%s не может быть пустым", fieldType)
	}

	if !IsSafeSQLString(input) {
		return false, "Обнаружены опасные символы"
	}

	if len(input) > 1000 {
		return false, "Входная строка слишком длинная"
	}

	return true, ""
}

func GenerateSalt() string {
	return hex.EncodeToString([]byte("salt_" + fmt.Sprintf("%d", len(fmt.Sprintf("%v", struct{}{}))) + "_random"))
}

func IsPhishingEmail(subject, from, body string) (bool, []string) {
	redFlags := []string{}

	suspiciousKeywords := []string{
		"confirm", "verify", "urgent", "update", "click", "immediately",
		"account", "suspended", "expired", "confirm identity", "secure",
	}

	for _, keyword := range suspiciousKeywords {
		if strings.Contains(strings.ToLower(subject), keyword) {
			redFlags = append(redFlags, fmt.Sprintf("Подозрительное слово в теме: %s", keyword))
		}
	}

	linkRegex := regexp.MustCompile(`(http|https)://[^\s]+`)
	links := linkRegex.FindAllString(body, -1)
	if len(links) > 0 {
		redFlags = append(redFlags, fmt.Sprintf("Найдено %d ссылок в теле письма", len(links)))
	}

	if strings.Contains(strings.ToLower(body), "password") ||
		strings.Contains(strings.ToLower(body), "пароль") {
		redFlags = append(redFlags, "Просьба ввести пароль")
	}

	isPhishing := len(redFlags) >= 2
	return isPhishing, redFlags
}

type RateLimiter struct {
	attempts map[string]int
	maxTries int
}

func NewRateLimiter(maxTries int) *RateLimiter {
	return &RateLimiter{
		attempts: make(map[string]int),
		maxTries: maxTries,
	}
}

func (rl *RateLimiter) IsAllowed(identifier string) bool {
	if count, exists := rl.attempts[identifier]; exists {
		if count >= rl.maxTries {
			return false
		}
		rl.attempts[identifier]++
	} else {
		rl.attempts[identifier] = 1
	}
	return true
}

func (rl *RateLimiter) Reset(identifier string) {
	delete(rl.attempts, identifier)
}
