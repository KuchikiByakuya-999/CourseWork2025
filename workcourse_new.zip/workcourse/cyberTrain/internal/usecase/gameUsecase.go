package usecase

import (
	"context"
	"cyber-skeleton/internal/domain"
	"cyber-skeleton/internal/repository"
	"fmt"
	"time"
)

type PhishingUsecase struct {
	repo      repository.PhishingRepository
	generator *repository.PhishingMailGenerator
}

func NewPhishingUsecase(repo repository.PhishingRepository) *PhishingUsecase {
	return &PhishingUsecase{
		repo:      repo,
		generator: repository.NewPhishingMailGenerator(),
	}
}

func (uc *PhishingUsecase) GeneratePhishingMails(ctx context.Context) []map[string]interface{} {
	if uc.generator == nil {
		uc.generator = repository.NewPhishingMailGenerator()
	}
	return uc.generator.GenerateMany(15, 2)
}

func (uc *PhishingUsecase) GetMails(ctx context.Context, lvl domain.PhishingLevel) ([]domain.PhishingMail, error) {
	return uc.repo.GetMails(ctx, lvl)
}

func (uc *PhishingUsecase) SaveResult(ctx context.Context, result *domain.PhishingResult) error {
	return uc.repo.SaveResult(ctx, result)
}

type PasswordUsecase struct {
	repo      repository.PasswordRepository
	generator *repository.PasswordChallengeGenerator
}

func NewPasswordUsecase(repo repository.PasswordRepository) *PasswordUsecase {
	return &PasswordUsecase{
		repo:      repo,
		generator: repository.NewPasswordChallengeGenerator(),
	}
}

func (uc *PasswordUsecase) GeneratePasswordChallenges(ctx context.Context) []repository.PasswordChallenge {
	if uc.generator == nil {
		uc.generator = repository.NewPasswordChallengeGenerator()
	}
	return uc.generator.GenerateMany(15)
}

func (uc *PasswordUsecase) GetRandomChallenges(ctx context.Context, count int) ([]domain.PasswordChallenge, error) {
	return uc.repo.GetRandomChallenges(ctx, count)
}

type NetworkUsecase struct {
	repo repository.NetworkRepository
}

func NewNetworkUsecase(repo repository.NetworkRepository) *NetworkUsecase {
	return &NetworkUsecase{repo: repo}
}
func (uc *NetworkUsecase) GenerateNetworkIncidents(ctx context.Context) ([]domain.NetworkIncident, error) {
	generator := repository.NewNetworkIncidentGenerator()
	incidents := generator.GenerateMany(10)
	return incidents, nil
}

func (uc *NetworkUsecase) GetRandomIncidents(ctx context.Context, count int) ([]domain.NetworkIncident, error) {
	return uc.repo.GetRandomIncidents(ctx, count)
}

type CryptoUsecase struct {
	generator *repository.CryptoGenerator
}

func NewCryptoUsecase() *CryptoUsecase {
	return &CryptoUsecase{
		generator: repository.NewCryptoGenerator(),
	}
}

func (uc *CryptoUsecase) GenerateCryptoChallenges(ctx context.Context, count int, difficulty int) []domain.CryptoChallenge {
	if uc.generator == nil {
		uc.generator = repository.NewCryptoGenerator()
	}
	return uc.generator.GenerateMany(count, difficulty)
}

type GameUsecase struct {
	repo repository.Repository
}

func NewGameUsecase(repo repository.Repository) *GameUsecase {
	return &GameUsecase{repo: repo}
}

func (uc *GameUsecase) SaveGameResult(ctx context.Context, userID int64, gameType string, score int) error {
	result := &domain.GameResult{
		UserID:   userID,
		GameCode: gameType,
		Score:    score,
	}
	return uc.repo.SaveGameResult(ctx, result)
}

func (uc *GameUsecase) GetUserStats(ctx context.Context, userID int64) (map[string]interface{}, error) {
	moduleStats, err := uc.repo.GetModuleStats(ctx, userID)
	if err != nil {
		moduleStats = make(map[string]domain.ModuleStat)
	}

	totalXP := 0
	for _, stat := range moduleStats {
		totalXP += stat.TotalScore
	}

	results, err := uc.repo.GetLastResults(ctx, userID, 100)
	if err != nil {
		results = []domain.GameResult{}
	}

	modules := map[string]map[string]interface{}{
		"phishing":  makeModuleInfo("Фишинг", moduleStats["phishing"]),
		"passwords": makeModuleInfo("Пароли", moduleStats["passwords"]),
		"network":   makeModuleInfo("Сети", moduleStats["network"]),
		"crypto":    makeModuleInfo("Криптография", moduleStats["crypto"]),
		"malware":   makeModuleInfo("Вредонос", moduleStats["malware"]),
	}

	return map[string]interface{}{
		"totalScore":  totalXP,
		"gamesPlayed": len(results),
		"modules":     modules,
	}, nil
}

func makeModuleInfo(name string, stat domain.ModuleStat) map[string]interface{} {
	maxScore := 2000
	progress := 0
	if maxScore > 0 {
		progress = (stat.TotalScore * 100) / maxScore
	}
	if progress > 100 {
		progress = 100
	}

	return map[string]interface{}{
		"name":     name,
		"score":    stat.TotalScore,
		"maxScore": maxScore,
		"progress": fmt.Sprintf("%d%%", progress),
	}
}

func (uc *GameUsecase) GetUserLevel(ctx context.Context, userID int64) (int, string, error) {
	stats, err := uc.repo.GetModuleStats(ctx, userID)
	if err != nil {
		return 0, "", err
	}

	total := 0
	for _, st := range stats {
		total += st.TotalScore
	}

	lvl := total / 500
	if total > 0 && lvl == 0 {
		lvl = 1
	}

	rank := "Новичок"
	switch {
	case lvl >= 10:
		rank = "Blue Team Lead"
	case lvl >= 7:
		rank = "Senior SOC Analyst"
	case lvl >= 4:
		rank = "SOC Analyst"
	case lvl >= 2:
		rank = "Junior SOC Analyst"
	}

	return lvl, rank, nil
}

func (uc *GameUsecase) GetOrCreateWeeklyQuests(ctx context.Context, userID int64) ([]domain.WeeklyQuest, error) {
	quests, err := uc.repo.GetActiveWeeklyQuests(ctx, userID)
	if err != nil {
		return nil, err
	}
	now := time.Now()

	var active []domain.WeeklyQuest
	for _, q := range quests {
		if q.ExpiresAt.After(now) {
			active = append(active, q)
		}
	}
	if len(active) > 0 {
		return active, nil
	}

	expires := now.AddDate(0, 0, 7)

	templates := []domain.WeeklyQuest{
		{
			Code:        "week-phishing-500",
			Title:       "Антифишер недели",
			Description: "Набери 500 очков в модуле фишинга за эту неделю.",
			TargetScore: 500,
			ModuleCode:  "phishing",
			ExpiresAt:   expires,
		},
		{
			Code:        "week-password-300",
			Title:       "Парольный тренировочный лагерь",
			Description: "Заработай 300 очков в модуле паролей.",
			TargetScore: 300,
			ModuleCode:  "passwords",
			ExpiresAt:   expires,
		},
		{
			Code:        "week-network-3",
			Title:       "Дежурный по SOC",
			Description: "Пройди не менее 3 сетевых инцидентов без ошибок.",
			TargetScore: 3,
			ModuleCode:  "network",
			ExpiresAt:   expires,
		},
	}

	var res []domain.WeeklyQuest
	for _, tpl := range templates {
		q := tpl
		q.UserID = userID
		if err := uc.repo.SaveWeeklyQuest(ctx, &q); err != nil {
			return nil, err
		}
		res = append(res, q)
	}

	return res, nil
}

func (uc *GameUsecase) UpdateQuestsAfterGame(ctx context.Context, userID int64, gameCode string, score int, correct int) error {
	quests, err := uc.repo.GetActiveWeeklyQuests(ctx, userID)
	if err != nil {
		return err
	}
	now := time.Now()

	for _, q := range quests {
		if q.Completed || q.ExpiresAt.Before(now) {
			continue
		}

		if q.ModuleCode == gameCode {
			switch q.Code {
			case "week-phishing-500", "week-password-300":
				if score >= q.TargetScore {
					q.Completed = true
					if err := uc.repo.SaveWeeklyQuest(ctx, &q); err != nil {
						return err
					}
				}
			case "week-network-3":
				if correct >= q.TargetScore {
					q.Completed = true
					if err := uc.repo.SaveWeeklyQuest(ctx, &q); err != nil {
						return err
					}
				}
			}
		}
	}

	return nil
}

func (uc *GameUsecase) AddWeakSpot(ctx context.Context, userID int64, gameCode string, payload string) error {
	return uc.repo.SaveWeakSpot(ctx, userID, gameCode, payload)
}

func (uc *GameUsecase) GetWeakSpots(ctx context.Context, userID int64, gameCode string, limit int) ([]string, error) {
	return uc.repo.GetWeakSpots(ctx, userID, gameCode, limit)
}

func (uc *GameUsecase) GetGlobalLeaderboard(ctx context.Context, limit int) ([]domain.UserRank, error) {
	return uc.repo.GetGlobalLeaderboard(ctx, limit)
}

func (uc *GameUsecase) GetUserGlobalRank(ctx context.Context, userID int64) (int, error) {
	return uc.repo.GetUserGlobalRank(ctx, userID)
}

func (uc *GameUsecase) GetModuleLeaderboard(ctx context.Context, moduleCode string, limit int) ([]domain.UserRank, error) {
	return uc.repo.GetModuleLeaderboard(ctx, moduleCode, limit)
}

func (uc *GameUsecase) GetRecentActivity(ctx context.Context, userID int64) ([]domain.ModuleActivity, error) {
	return uc.repo.GetRecentActivity(ctx, userID)
}

func (uc *GameUsecase) GetDetailedStats(ctx context.Context, userID int64) (*domain.UserStatistics, error) {
	moduleStats, err := uc.repo.GetModuleStats(ctx, userID)
	if err != nil {
		return nil, err
	}

	totalXP := 0
	for _, stat := range moduleStats {
		totalXP += stat.TotalScore
	}

	results, _ := uc.repo.GetLastResults(ctx, userID, 10)
	activities, _ := uc.repo.GetRecentActivity(ctx, userID)
	globalRank, _ := uc.repo.GetUserGlobalRank(ctx, userID)
	level, rank, _ := uc.GetUserLevel(ctx, userID)

	weakSpots := make(map[string][]string)
	for _, code := range []string{"phishing", "passwords", "network", "crypto", "malware"} {
		spots, _ := uc.GetWeakSpots(ctx, userID, code, 3)
		if len(spots) > 0 {
			weakSpots[code] = spots
		}
	}

	return &domain.UserStatistics{
		TotalXP:     totalXP,
		GamesPlayed: len(results),
		Level:       level,
		Rank:        rank,
		GlobalRank:  globalRank,
		ModuleStats: moduleStats,
		RecentGames: results,
		Activities:  activities,
		WeakSpots:   weakSpots,
	}, nil
}
