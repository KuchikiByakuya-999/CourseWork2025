package usecase

import (
	"context"
	"cyber-skeleton/internal/domain"
	"cyber-skeleton/internal/repository"
	"errors"
	"math/rand"
	"sync"
	"time"

	"golang.org/x/crypto/bcrypt"
)

type AuthUsecase struct {
	repo          repository.Repository
	maxFailWindow time.Duration
	maxFailCount  int
}

func NewAuthUsecase(r repository.Repository) *AuthUsecase {
	return &AuthUsecase{
		repo:          r,
		maxFailWindow: 5 * time.Minute,
		maxFailCount:  10,
	}
}

var (
	failMu    sync.Mutex
	failStats = map[string][]time.Time{}
)

func (u *AuthUsecase) Login(ctx context.Context, loginOrEmail, password string) (*domain.User, error) {
	start := time.Now()
	defer func() {
		time.Sleep(time.Until(start.Add(500*time.Millisecond + time.Duration(rand.Intn(500))*time.Millisecond)))
	}()

	if u.tooManyFails(loginOrEmail) {
		return nil, errors.New("слишком много неудачных попыток, попробуйте позже")
	}

	user, err := u.repo.GetUserByLoginOrEmail(ctx, loginOrEmail)
	if err != nil {
		u.addFail(loginOrEmail)
		return nil, errors.New("неверные логин или пароль")
	}

	if !checkPassword(password, user.PasswordHash) {
		u.addFail(loginOrEmail)
		return nil, errors.New("неверные логин или пароль")
	}

	u.resetFails(loginOrEmail)
	return user, nil
}

func (u *AuthUsecase) tooManyFails(login string) bool {
	failMu.Lock()
	defer failMu.Unlock()
	list := failStats[login]
	now := time.Now()
	var fresh []time.Time
	for _, t := range list {
		if now.Sub(t) <= u.maxFailWindow {
			fresh = append(fresh, t)
		}
	}
	failStats[login] = fresh
	return len(fresh) >= u.maxFailCount
}

func checkPassword(plain, hashed string) bool {
	if hashed == "" {
		return false
	}
	err := bcrypt.CompareHashAndPassword([]byte(hashed), []byte(plain))
	return err == nil
}

func (u *AuthUsecase) addFail(login string) {
	failMu.Lock()
	defer failMu.Unlock()
	failStats[login] = append(failStats[login], time.Now())
}

func (u *AuthUsecase) resetFails(login string) {
	failMu.Lock()
	defer failMu.Unlock()
	delete(failStats, login)
}

func (u *AuthUsecase) Register(ctx context.Context, username, email, password string) (*domain.User, error) {
	ctx, cancel := context.WithTimeout(ctx, 5*time.Second)
	defer cancel()

	hash, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return nil, err
	}

	return u.repo.CreateUser(ctx, username, email, string(hash))
}
