package config

import "os"

type Config struct {
	AppName string
	Debug   bool
}

func LoadConfig() *Config {
	return &Config{
		AppName: getEnv("APP_NAME", "Cyber Skeleton"),
		Debug:   getEnv("DEBUG", "true") == "true",
	}
}

func getEnv(key, defaultValue string) string {
	if value := os.Getenv(key); value != "" {
		return value
	}
	return defaultValue
}
