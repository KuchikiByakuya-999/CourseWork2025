package repository

import (
	"context"
	"time"

	"cyber-skeleton/internal/domain"
	"cyber-skeleton/store"

	"gorm.io/gorm"
)

type GormRepository struct {
	db *gorm.DB
}

func NewGormRepository(s *store.Store) Repository {
	return &GormRepository{db: s.DB}
}

func (r *GormRepository) Close() error {
	return nil
}

func (r *GormRepository) CreateUser(ctx context.Context, username, email, passwordHash string) (*domain.User, error) {
	user := &store.User{
		Username:     username,
		Email:        email,
		PasswordHash: passwordHash,
	}

	if err := r.db.WithContext(ctx).Create(user).Error; err != nil {
		return nil, err
	}

	return &domain.User{
		ID:       int64(user.ID),
		Username: user.Username,
		Email:    user.Email,
	}, nil
}

func (r *GormRepository) GetUserByUsername(ctx context.Context, username string) (*domain.User, error) {
	var model store.User
	if err := r.db.WithContext(ctx).
		Where("username = ?", username).
		First(&model).Error; err != nil {
		return nil, err
	}

	return &domain.User{
		ID:           int64(model.ID),
		Username:     model.Username,
		Email:        model.Email,
		PasswordHash: model.PasswordHash,
	}, nil
}

func (r *GormRepository) GetUserByLoginOrEmail(ctx context.Context, loginOrEmail string) (*domain.User, error) {
	var model store.User
	if err := r.db.WithContext(ctx).
		Where("username = ? OR email = ?", loginOrEmail, loginOrEmail).
		First(&model).Error; err != nil {
		return nil, err
	}

	return &domain.User{
		ID:           int64(model.ID),
		Username:     model.Username,
		Email:        model.Email,
		PasswordHash: model.PasswordHash,
	}, nil
}

func (r *GormRepository) SaveGameResult(ctx context.Context, res *domain.GameResult) error {
	return r.db.WithContext(ctx).Create(&store.GameResult{
		UserID:   uint(res.UserID),
		GameCode: res.GameCode,
		Score:    res.Score,
		MaxScore: res.MaxScore,
	}).Error
}

func (r *GormRepository) GetLastResults(ctx context.Context, userID int64, limit int) ([]domain.GameResult, error) {
	var rows []store.GameResult
	if err := r.db.WithContext(ctx).
		Where("user_id = ?", userID).
		Order("created_at DESC").
		Limit(limit).
		Find(&rows).Error; err != nil {
		return nil, err
	}

	res := make([]domain.GameResult, len(rows))
	for i, m := range rows {
		res[i] = domain.GameResult{
			ID:        int64(m.ID),
			UserID:    int64(m.UserID),
			GameCode:  m.GameCode,
			Score:     m.Score,
			MaxScore:  m.MaxScore,
			CreatedAt: m.CreatedAt,
		}
	}

	return res, nil
}

func (r *GormRepository) GetXP(ctx context.Context, userID int64) (int, error) {
	var xp int64
	if err := r.db.WithContext(ctx).
		Model(&store.GameResult{}).
		Where("user_id = ?", userID).
		Select("COALESCE(SUM(score),0)").
		Scan(&xp).Error; err != nil {
		return 0, err
	}

	return int(xp), nil
}

func (r *GormRepository) GetModuleStats(ctx context.Context, userID int64) (map[string]domain.ModuleStat, error) {
	type row struct {
		GameCode  string
		Score     int
		CreatedAt time.Time
	}

	var rows []row
	if err := r.db.WithContext(ctx).
		Model(&store.GameResult{}).
		Where("user_id = ?", userID).
		Select("game_code, score, created_at").
		Order("created_at").
		Scan(&rows).Error; err != nil {
		return nil, err
	}

	stats := make(map[string]domain.ModuleStat)
	for _, m := range rows {
		st := stats[m.GameCode]
		st.GameCode = m.GameCode
		st.Attempts++
		st.TotalScore += m.Score
		if m.Score > st.BestScore {
			st.BestScore = m.Score
		}
		st.LastScore = m.Score
		st.LastPlayed = m.CreatedAt
		stats[m.GameCode] = st
	}

	return stats, nil
}

func (r *GormRepository) GetActiveWeeklyQuests(ctx context.Context, userID int64) ([]domain.WeeklyQuest, error) {
	var rows []store.WeeklyQuest
	if err := r.db.WithContext(ctx).
		Where("user_id = ?", userID).
		Order("expires_at ASC").
		Find(&rows).Error; err != nil {
		return nil, err
	}

	res := make([]domain.WeeklyQuest, len(rows))
	for i, q := range rows {
		res[i] = domain.WeeklyQuest{
			ID:          int64(q.ID),
			UserID:      int64(q.UserID),
			Code:        q.Code,
			Title:       q.Title,
			Description: q.Description,
			TargetScore: q.TargetScore,
			ModuleCode:  q.ModuleCode,
			Completed:   q.Completed,
			ExpiresAt:   time.Unix(q.ExpiresAt, 0),
		}
	}

	return res, nil
}

func (r *GormRepository) SaveWeeklyQuest(ctx context.Context, q *domain.WeeklyQuest) error {
	var model store.WeeklyQuest
	if q.ID != 0 {
		if err := r.db.WithContext(ctx).First(&model, q.ID).Error; err != nil {
			return err
		}
	}

	model.UserID = uint(q.UserID)
	model.Code = q.Code
	model.Title = q.Title
	model.Description = q.Description
	model.TargetScore = q.TargetScore
	model.ModuleCode = q.ModuleCode
	model.Completed = q.Completed
	model.ExpiresAt = q.ExpiresAt.Unix()

	if q.ID == 0 {
		return r.db.WithContext(ctx).Create(&model).Error
	}

	return r.db.WithContext(ctx).Save(&model).Error
}

func (r *GormRepository) SaveWeakSpot(ctx context.Context, userID int64, gameCode string, payload string) error {
	ws := &store.WeakSpot{
		UserID:   uint(userID),
		GameCode: gameCode,
		Payload:  payload,
	}
	return r.db.WithContext(ctx).Create(ws).Error
}

func (r *GormRepository) GetWeakSpots(ctx context.Context, userID int64, gameCode string, limit int) ([]string, error) {
	var rows []store.WeakSpot
	q := r.db.WithContext(ctx).
		Where("user_id = ? AND game_code = ?", userID, gameCode).
		Order("created_at DESC")
	if limit > 0 {
		q = q.Limit(limit)
	}
	if err := q.Find(&rows).Error; err != nil {
		return nil, err
	}

	res := make([]string, len(rows))
	for i, m := range rows {
		res[i] = m.Payload
	}
	return res, nil
}

type GormPhishingRepository struct {
	db *gorm.DB
}

func NewGormPhishingRepository(s *store.Store) PhishingRepository {
	return &GormPhishingRepository{db: s.DB}
}

func (r *GormPhishingRepository) GetMails(ctx context.Context, lvl domain.PhishingLevel) ([]domain.PhishingMail, error) {
	var rows []store.PhishingMail
	if err := r.db.WithContext(ctx).
		Preload("RedFlags").
		Where("level = ?", int(lvl)).
		Order("id").
		Find(&rows).Error; err != nil {
		return nil, err
	}

	res := make([]domain.PhishingMail, len(rows))
	for i, m := range rows {
		pm := domain.PhishingMail{
			ID:         int64(m.ID),
			Level:      domain.PhishingLevel(m.Level),
			Channel:    m.Channel,
			From:       m.Sender,
			Subject:    m.Subject,
			Body:       m.Body,
			HasAttach:  m.HasAttach,
			IsPhishing: m.IsPhishing,
		}
		if m.Url != nil {
			pm.Url = *m.Url
		}
		if m.Explanation != nil {
			pm.Explanation = *m.Explanation
		}
		for _, f := range m.RedFlags {
			pm.RedFlags = append(pm.RedFlags, f.Text)
		}
		res[i] = pm
	}

	return res, nil
}

func (r *GormPhishingRepository) SaveResult(ctx context.Context, res *domain.PhishingResult) error {
	return r.db.WithContext(ctx).Create(&store.PhishingResult{
		UserID:   uint(res.UserID),
		Mode:     int(res.Mode),
		Level:    int(res.Level),
		Score:    res.Score,
		Correct:  res.Correct,
		Wrong:    res.Wrong,
		Skipped:  res.Skipped,
		MaxCombo: res.MaxCombo,
		Duration: int64(res.Duration.Seconds()),
	}).Error
}

type GormPasswordRepository struct {
	db *gorm.DB
}

func NewGormPasswordRepository(s *store.Store) PasswordRepository {
	return &GormPasswordRepository{db: s.DB}
}

func (r *GormPasswordRepository) GetRandomChallenges(ctx context.Context, count int) ([]domain.PasswordChallenge, error) {
	var rows []store.PasswordChallenge
	if err := r.db.WithContext(ctx).
		Order("RANDOM()").
		Limit(count).
		Find(&rows).Error; err != nil {
		return nil, err
	}

	res := make([]domain.PasswordChallenge, len(rows))
	for i, m := range rows {
		res[i] = domain.PasswordChallenge{
			ID:       int64(m.ID),
			Password: m.Prompt,
			Hint:     m.Hint,
			Strength: m.Level,
			IsWeak:   false,
			Category: "",
		}
	}

	return res, nil
}

type GormNetworkRepository struct {
	db *gorm.DB
}

func NewGormNetworkRepository(s *store.Store) NetworkRepository {
	return &GormNetworkRepository{db: s.DB}
}

func (r *GormNetworkRepository) GetRandomIncidents(ctx context.Context, count int) ([]domain.NetworkIncident, error) {
	var rows []store.NetworkIncident
	if err := r.db.WithContext(ctx).
		Order("RANDOM()").
		Limit(count).
		Find(&rows).Error; err != nil {
		return nil, err
	}

	res := make([]domain.NetworkIncident, len(rows))
	for i, m := range rows {
		res[i] = domain.NetworkIncident{
			ID:     int64(m.ID),
			Type:   m.Type,
			Logs:   []string{m.Logs},
			Action: m.Action,
		}
	}

	return res, nil
}

func (r *GormRepository) GetGlobalLeaderboard(ctx context.Context, limit int) ([]domain.UserRank, error) {
	type result struct {
		UserID   uint
		Username string
		TotalXP  int
	}

	var results []result
	err := r.db.WithContext(ctx).
		Table("users").
		Select("users.id as user_id, users.username, COALESCE(SUM(game_results.score), 0) as total_xp").
		Joins("LEFT JOIN game_results ON game_results.user_id = users.id").
		Group("users.id, users.username").
		Order("total_xp DESC").
		Limit(limit).
		Scan(&results).Error

	if err != nil {
		return nil, err
	}

	ranks := make([]domain.UserRank, len(results))
	for i, r := range results {
		ranks[i] = domain.UserRank{
			UserID:   int64(r.UserID),
			Username: r.Username,
			TotalXP:  r.TotalXP,
			Rank:     i + 1,
		}
	}

	return ranks, nil
}

func (r *GormRepository) GetUserGlobalRank(ctx context.Context, userID int64) (int, error) {
	type result struct {
		Rank int
	}

	var res result
	err := r.db.WithContext(ctx).Raw(`
        WITH ranked_users AS (
            SELECT 
                users.id,
                RANK() OVER (ORDER BY COALESCE(SUM(game_results.score), 0) DESC) as rank
            FROM users
            LEFT JOIN game_results ON game_results.user_id = users.id
            GROUP BY users.id
        )
        SELECT rank FROM ranked_users WHERE id = ?
    `, userID).Scan(&res).Error

	if err != nil {
		return 0, err
	}

	return res.Rank, nil
}

func (r *GormRepository) GetModuleLeaderboard(ctx context.Context, moduleCode string, limit int) ([]domain.UserRank, error) {
	type result struct {
		UserID   uint
		Username string
		TotalXP  int
	}

	var results []result
	err := r.db.WithContext(ctx).
		Table("users").
		Select("users.id as user_id, users.username, COALESCE(SUM(game_results.score), 0) as total_xp").
		Joins("LEFT JOIN game_results ON game_results.user_id = users.id AND game_results.game_code = ?", moduleCode).
		Group("users.id, users.username").
		Order("total_xp DESC").
		Limit(limit).
		Scan(&results).Error

	if err != nil {
		return nil, err
	}

	ranks := make([]domain.UserRank, len(results))
	for i, r := range results {
		ranks[i] = domain.UserRank{
			UserID:   int64(r.UserID),
			Username: r.Username,
			TotalXP:  r.TotalXP,
			Rank:     i + 1,
		}
	}

	return ranks, nil
}

func (r *GormRepository) GetRecentActivity(ctx context.Context, userID int64) ([]domain.ModuleActivity, error) {
	type result struct {
		GameCode   string
		LastPlayed time.Time
		AvgScore   float64
	}

	var results []result
	err := r.db.WithContext(ctx).
		Table("game_results").
		Select("game_code, MAX(created_at) as last_played, AVG(score) as avg_score").
		Where("user_id = ?", userID).
		Group("game_code").
		Order("last_played DESC").
		Scan(&results).Error

	if err != nil {
		return nil, err
	}

	moduleNames := map[string]string{
		"phishing":  "Фишинг",
		"passwords": "Пароли",
		"network":   "Сети",
		"crypto":    "Криптография",
		"malware":   "Вредонос",
	}

	activities := make([]domain.ModuleActivity, len(results))
	for i, r := range results {
		trend := "stable"
		if r.AvgScore > 200 {
			trend = "up"
		} else if r.AvgScore < 100 {
			trend = "down"
		}

		activities[i] = domain.ModuleActivity{
			ModuleCode:  r.GameCode,
			ModuleName:  moduleNames[r.GameCode],
			LastPlayed:  r.LastPlayed,
			AvgScore:    r.AvgScore,
			RecentTrend: trend,
		}
	}

	return activities, nil
}

func (r *GormRepository) GetAverageScores(ctx context.Context, userID int64, moduleCode string, limit int) (float64, error) {
	var avg float64
	err := r.db.WithContext(ctx).
		Table("game_results").
		Select("AVG(score)").
		Where("user_id = ? AND game_code = ?", userID, moduleCode).
		Order("created_at DESC").
		Limit(limit).
		Scan(&avg).Error

	return avg, err
}
