package repository

import (
	"context"
	"cyber-skeleton/internal/domain"
)

type Repository interface {
	CreateUser(ctx context.Context, username, email, passwordHash string) (*domain.User, error)
	GetUserByUsername(ctx context.Context, username string) (*domain.User, error)
	GetUserByLoginOrEmail(ctx context.Context, loginOrEmail string) (*domain.User, error)

	SaveGameResult(ctx context.Context, res *domain.GameResult) error
	GetLastResults(ctx context.Context, userID int64, limit int) ([]domain.GameResult, error)
	GetXP(ctx context.Context, userID int64) (int, error)
	GetModuleStats(ctx context.Context, userID int64) (map[string]domain.ModuleStat, error)

	GetActiveWeeklyQuests(ctx context.Context, userID int64) ([]domain.WeeklyQuest, error)
	SaveWeeklyQuest(ctx context.Context, q *domain.WeeklyQuest) error

	SaveWeakSpot(ctx context.Context, userID int64, gameCode string, payload string) error
	GetWeakSpots(ctx context.Context, userID int64, gameCode string, limit int) ([]string, error)

	GetGlobalLeaderboard(ctx context.Context, limit int) ([]domain.UserRank, error)
	GetUserGlobalRank(ctx context.Context, userID int64) (int, error)
	GetModuleLeaderboard(ctx context.Context, moduleCode string, limit int) ([]domain.UserRank, error)

	GetRecentActivity(ctx context.Context, userID int64) ([]domain.ModuleActivity, error)
	GetAverageScores(ctx context.Context, userID int64, moduleCode string, limit int) (float64, error)

	Close() error
}

type PhishingRepository interface {
	GetMails(ctx context.Context, lvl domain.PhishingLevel) ([]domain.PhishingMail, error)
	SaveResult(ctx context.Context, res *domain.PhishingResult) error
}

type PasswordRepository interface {
	GetRandomChallenges(ctx context.Context, count int) ([]domain.PasswordChallenge, error)
}

type NetworkRepository interface {
	GetRandomIncidents(ctx context.Context, count int) ([]domain.NetworkIncident, error)
}
