package repository

import (
	"cyber-skeleton/internal/domain"
	mathrand "math/rand"
	"strings"
	"time"
)

type CryptoGenerator struct {
	rand *mathrand.Rand
}

func NewCryptoGenerator() *CryptoGenerator {
	return &CryptoGenerator{
		rand: mathrand.New(mathrand.NewSource(time.Now().UnixNano())),
	}
}

func (g *CryptoGenerator) GenerateMany(count int, difficulty int) []domain.CryptoChallenge {
	challenges := []domain.CryptoChallenge{}

	types := []string{}

	messages := []string{
		"ATTACK AT DAWN",
		"THE EAGLE HAS LANDED",
		"SECRET MESSAGE",
		"MISSION ACCOMPLISHED",
		"ENCRYPTION IS FUN",
		"CYBER SECURITY ROCKS",
		"KEEP YOUR DATA SAFE",
		"PASSWORD IS HUNTER2",
		"BEWARE THE PHISHING",
		"TWO FACTOR AUTH SAVES LIVES",
	}

	for i := 0; i < count; i++ {
		cipherType := types[g.rand.Intn(len(types))]
		message := messages[g.rand.Intn(len(messages))]

		var challenge domain.CryptoChallenge

		switch cipherType {
		case "caesar":
			challenge = g.generateCaesar(message, difficulty)
		case "vigenere":
			challenge = g.generateVigenere(message, difficulty)
		case "substitution":
			challenge = g.generateSubstitution(message, difficulty)
		}

		challenge.ID = int64(i + 1)
		challenge.Difficulty = difficulty
		challenges = append(challenges, challenge)
	}

	return challenges
}

func (g *CryptoGenerator) generateCaesar(plaintext string, difficulty int) domain.CryptoChallenge {
	shift := g.rand.Intn(25) + 1
	ciphertext := caesarEncrypt(plaintext, shift)

	hint := "Каждая буква сдвинута на одинаковое количество позиций в алфавите"
	if difficulty <= 1 {
		hint += ". Попробуйте сдвиги от 1 до 25"
	}

	return domain.CryptoChallenge{
		CipherType: "caesar",
		Ciphertext: ciphertext,
		Plaintext:  plaintext,
		Hint:       hint,
		Key:        string(rune('0' + shift)),
		Difficulty: difficulty,
	}
}

func caesarEncrypt(text string, shift int) string {
	result := ""
	for _, char := range text {
		if char >= 'A' && char <= 'Z' {
			result += string((char-'A'+rune(shift))%26 + 'A')
		} else if char >= 'a' && char <= 'z' {
			result += string((char-'a'+rune(shift))%26 + 'a')
		} else {
			result += string(char)
		}
	}
	return result
}

func (g *CryptoGenerator) generateVigenere(plaintext string, difficulty int) domain.CryptoChallenge {
	keys := []string{"KEY", "SECRET", "CIPHER", "CRYPTO", "LOCK"}
	key := keys[g.rand.Intn(len(keys))]

	ciphertext := vigenereEncrypt(plaintext, key)

	hint := "Это шифр Виженера - используется повторяющийся ключ"
	if difficulty <= 2 {
		hint += ". Ключ длиной " + string(rune('0'+len(key))) + " букв"
	}

	return domain.CryptoChallenge{
		CipherType: "vigenere",
		Ciphertext: ciphertext,
		Plaintext:  plaintext,
		Hint:       hint,
		Key:        key,
		Difficulty: difficulty,
	}
}

func vigenereEncrypt(text, key string) string {
	result := ""
	keyIndex := 0
	key = strings.ToUpper(key)

	for _, char := range text {
		if char >= 'A' && char <= 'Z' {
			shift := int(key[keyIndex%len(key)] - 'A')
			result += string((char-'A'+rune(shift))%26 + 'A')
			keyIndex++
		} else if char >= 'a' && char <= 'z' {
			shift := int(key[keyIndex%len(key)] - 'A')
			result += string((char-'a'+rune(shift))%26 + 'a')
			keyIndex++
		} else {
			result += string(char)
		}
	}
	return result
}

func (g *CryptoGenerator) generateSubstitution(plaintext string, difficulty int) domain.CryptoChallenge {
	alphabet := "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
	shuffled := shuffleString(alphabet, g.rand)

	mapping := make(map[rune]rune)
	for i, char := range alphabet {
		mapping[char] = rune(shuffled[i])
	}

	ciphertext := ""
	for _, char := range plaintext {
		if char >= 'A' && char <= 'Z' {
			ciphertext += string(mapping[char])
		} else if char >= 'a' && char <= 'z' {
			ciphertext += string(mapping[rune(char-32)] + 32)
		} else {
			ciphertext += string(char)
		}
	}

	return domain.CryptoChallenge{
		CipherType: "substitution",
		Ciphertext: ciphertext,
		Plaintext:  plaintext,
		Key:        shuffled,
		Difficulty: difficulty,
	}
}

func shuffleString(s string, r *mathrand.Rand) string {
	runes := []rune(s)
	r.Shuffle(len(runes), func(i, j int) {
		runes[i], runes[j] = runes[j], runes[i]
	})
	return string(runes)
}
