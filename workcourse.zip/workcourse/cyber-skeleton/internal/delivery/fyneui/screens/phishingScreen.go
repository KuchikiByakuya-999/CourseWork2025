package screens

import (
	"context"
	"cyber-skeleton/internal/domain"
	"cyber-skeleton/internal/usecase"
	"fmt"
	"time"

	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/canvas"
	"fyne.io/fyne/v2/container"
	"fyne.io/fyne/v2/dialog"
	"fyne.io/fyne/v2/layout"
	"fyne.io/fyne/v2/widget"
)

type PhishingRouter interface {
	NavigateToDashboard(u *domain.User)
}

type PhishAction int

const (
	ActionReportPhish PhishAction = iota
	ActionDelete
	ActionAllow
	ActionQuarantine
)

type PhishingScreen struct {
	w          fyne.Window
	showTheory bool
	router     PhishingRouter
	uc         *usecase.PhishingUsecase
	user       *domain.User

	mode   domain.PhishingMode
	level  domain.PhishingLevel
	mails  []domain.PhishingMail
	cur    int
	start  time.Time
	cancel context.CancelFunc

	flagDmn *widget.Check
	flagUrl *widget.Check
	flagAtt *widget.Check
	flagUrg *widget.Check

	score      int
	correct    int
	wrong      int
	skipped    int
	combo      int
	maxCombo   int
	timerLbl   *widget.Label
	scoreLbl   *widget.Label
	comboLbl   *widget.Label
	list       *widget.List
	fromLbl    *widget.Label
	subjLbl    *widget.Label
	channelLbl *widget.Label
	bodyLbl    *widget.Label
}

func NewPhishingScreen(w fyne.Window, r PhishingRouter, u *domain.User, uc *usecase.PhishingUsecase,
	mode domain.PhishingMode, lvl domain.PhishingLevel) *PhishingScreen {

	return &PhishingScreen{
		w:      w,
		router: r,
		user:   u,
		uc:     uc,
		mode:   mode,
		level:  lvl,
	}
}

func (s *PhishingScreen) buildTheory() fyne.CanvasObject {
	s.w.Resize(fyne.NewSize(1200, 700))
	title := widget.NewLabelWithStyle("Фишинг: теория и примеры",
		fyne.TextAlignCenter, fyne.TextStyle{Bold: true})

	imgSimple := canvas.NewImageFromFile("assets/phish_simple.png")
	imgSimple.FillMode = canvas.ImageFillContain
	imgSimple.SetMinSize(fyne.NewSize(400, 200))

	imgBusiness := canvas.NewImageFromFile("assets/phish_bec.png")
	imgBusiness.FillMode = canvas.ImageFillContain
	imgBusiness.SetMinSize(fyne.NewSize(400, 200))

	intro := widget.NewLabel(
		"Фишинг — это вид социальной инженерии, при котором злоумышленник маскируется под надёжный сервис " +
			"или человека и пытается получить ваши данные или заставить выполнить опасное действие.",
	)

	goals := widget.NewLabel(
		"Цели фишинга: кража учётных записей, данных банковских карт, установка вредоносного ПО и хищение денег " +
			"через поддельные платёжные операции.",
	)

	signsTitle := widget.NewLabelWithStyle("Основные признаки фишинга", fyne.TextAlignLeading, fyne.TextStyle{Bold: true})
	signs := widget.NewLabel(
		"• Подозрительный отправитель или домен.\n" +
			"• Несовпадение текста ссылки и реального адреса.\n" +
			"• Давление по времени и угрозы блокировки.\n" +
			"• Запрос логинов, паролей, кодов из SMS или данных карты.\n" +
			"• Неожиданные вложения и ошибки в тексте.",
	)

	examplesTitle := widget.NewLabelWithStyle("Примеры писем", fyne.TextAlignLeading, fyne.TextStyle{Bold: true})
	examplesText := widget.NewLabel(
		"Слева — простое фишинговое письмо о блокировке аккаунта с поддельной ссылкой. " +
			"Справа — таргетированная атака от имени руководителя с просьбой о срочном платеже.",
	)

	btnStart := widget.NewButton("Перейти к практике", func() {
		s.showTheory = false
		s.w.SetContent(s.Build())
	})

	content := container.NewVBox(
		title,
		widget.NewSeparator(),
		intro,
		goals,
		widget.NewSeparator(),
		signsTitle,
		signs,
		widget.NewSeparator(),
		examplesTitle,
		container.NewGridWithColumns(2, imgSimple, imgBusiness),
		examplesText,
		widget.NewSeparator(),
		container.NewHBox(layout.NewSpacer(), btnStart, layout.NewSpacer()),
	)

	return container.NewVScroll(container.NewPadded(content))
}

func (s *PhishingScreen) buildFlags() fyne.CanvasObject {
	s.flagDmn = widget.NewCheck("Странный домен/отправитель", nil)
	s.flagUrl = widget.NewCheck("Подозрительная ссылка", nil)
	s.flagAtt = widget.NewCheck("Неожиданное вложение", nil)
	s.flagUrg = widget.NewCheck("Давление/угрозы/слишком хорошо, чтобы быть правдой", nil)

	return container.NewVBox(
		widget.NewLabelWithStyle("Отметьте, что вас насторожило:", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		s.flagDmn,
		s.flagUrl,
		s.flagAtt,
		s.flagUrg,
	)
}

func (s *PhishingScreen) Build() fyne.CanvasObject {
	s.w.Resize(fyne.NewSize(1200, 700))
	s.timerLbl = widget.NewLabel("Время: 00:00")
	s.scoreLbl = widget.NewLabel("Очки: 0")
	s.comboLbl = widget.NewLabel("Комбо: 0")

	s.fromLbl = widget.NewLabel("")
	s.subjLbl = widget.NewLabel("")
	s.channelLbl = widget.NewLabel("")
	s.bodyLbl = widget.NewLabel("")
	s.bodyLbl.Wrapping = fyne.TextWrapWord

	if s.showTheory {
		return s.buildTheory()
	}

	s.list = widget.NewList(
		func() int { return len(s.mails) },
		func() fyne.CanvasObject {
			return container.NewHBox(
				widget.NewLabel("Уров."),
				widget.NewLabel("Канал"),
				widget.NewLabel("Тема"),
			)
		},
		func(id widget.ListItemID, o fyne.CanvasObject) {
			if id < 0 || id >= len(s.mails) {
				return
			}
			m := s.mails[id]
			c := o.(*fyne.Container)
			c.Objects[0].(*widget.Label).SetText(s.levelShort(m.Level))
			c.Objects[1].(*widget.Label).SetText(m.Channel)
			c.Objects[2].(*widget.Label).SetText(m.Subject)
		},
	)
	s.list.OnSelected = func(id widget.ListItemID) {
		s.cur = int(id)
		s.showMail()
	}

	btnReport := widget.NewButton("Фишинг → в безопасность", func() {
		s.answer(ActionReportPhish)
	})
	btnDelete := widget.NewButton("Фишинг → удалить", func() {
		s.answer(ActionDelete)
	})
	btnAllow := widget.NewButton("Безопасно → оставить", func() {
		s.answer(ActionAllow)
	})
	btnQuarantine := widget.NewButton("Не уверен → в карантин", func() {
		s.answer(ActionQuarantine)
	})

	btnBack := widget.NewButton("← В меню", func() {
		if s.cancel != nil {
			s.cancel()
		}
		s.router.NavigateToDashboard(s.user)
	})

	actions := container.NewVBox(
		container.NewHBox(btnReport, btnDelete),
		container.NewHBox(btnAllow, btnQuarantine, layout.NewSpacer(), btnBack),
	)

	topBar := container.NewHBox(s.timerLbl, layout.NewSpacer(), s.scoreLbl, widget.NewLabel("|"), s.comboLbl)

	info := container.NewVBox(
		widget.NewLabelWithStyle("От:", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		s.fromLbl,
		widget.NewLabelWithStyle("Тема:", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		s.subjLbl,
		widget.NewLabelWithStyle("Канал:", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		s.channelLbl,
		widget.NewSeparator(),
		s.bodyLbl,
		widget.NewSeparator(),
		s.buildFlags(),
	)

	right := container.NewBorder(
		topBar,
		actions,
		nil,
		nil,
		container.NewVScroll(info),
	)

	split := container.NewHSplit(s.list, right)
	split.SetOffset(0.3)

	s.loadMails()

	return split
}

func (s *PhishingScreen) ShowTheory() {
	s.showTheory = true
}

func (s *PhishingScreen) levelShort(l domain.PhishingLevel) string {
	switch l {
	case domain.PhishingLevelEasy:
		return "E"
	case domain.PhishingLevelMedium:
		return "M"
	case domain.PhishingLevelHard:
		return "H"
	default:
		return "?"
	}
}

func (s *PhishingScreen) loadMails() {
	ctx, cancel := context.WithCancel(context.Background())
	s.cancel = cancel

	// ИСПРАВЛЕНО: Генерируем письма напрямую
	generatedMails := s.uc.GeneratePhishingMails(ctx)

	s.mails = make([]domain.PhishingMail, len(generatedMails))
	for i, gm := range generatedMails {
		s.mails[i] = domain.PhishingMail{
			From:        gm["from"].(string),
			Subject:     gm["subject"].(string),
			Body:        gm["body"].(string),
			Channel:     gm["channel"].(string),
			IsPhishing:  gm["is_phishing"].(bool),
			Level:       domain.PhishingLevel(gm["level"].(int)),
			RedFlags:    gm["red_flags"].([]string),
			Explanation: gm["explanation"].(string),
		}
	}

	if len(s.mails) == 0 {
		dialog.ShowInformation("Фишинг", "Не удалось сгенерировать письма", s.w)
		return
	}

	s.cur = 0
	s.list.Refresh()
	s.list.Select(0)
	s.showMail()
	s.start = time.Now()
	go s.timerLoop(ctx)
}

func (s *PhishingScreen) timerLoop(ctx context.Context) {
	ticker := time.NewTicker(time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			el := time.Since(s.start).Truncate(time.Second)
			min := int(el.Minutes())
			sec := int(el.Seconds()) % 60
			txt := fmt.Sprintf("Время: %02d:%02d", min, sec)
			fyne.Do(func() { s.timerLbl.SetText(txt) })
		}
	}
}

func (s *PhishingScreen) showMail() {
	if len(s.mails) == 0 || s.cur < 0 || s.cur >= len(s.mails) {
		return
	}
	m := s.mails[s.cur]
	s.fromLbl.SetText(m.From)
	s.subjLbl.SetText(m.Subject)
	s.channelLbl.SetText(m.Channel)
	s.bodyLbl.SetText(m.Body)

	if s.flagDmn != nil {
		s.flagDmn.SetChecked(false)
		s.flagUrl.SetChecked(false)
		s.flagAtt.SetChecked(false)
		s.flagUrg.SetChecked(false)
	}
}

func (s *PhishingScreen) answer(act PhishAction) {
	if len(s.mails) == 0 {
		return
	}
	m := s.mails[s.cur]

	isPhish := m.IsPhishing
	var baseRight bool

	switch act {
	case ActionReportPhish, ActionDelete, ActionQuarantine:
		baseRight = isPhish
	case ActionAllow:
		baseRight = !isPhish
	}

	bonus := 0
	penalty := 0

	if isPhish {
		switch act {
		case ActionReportPhish:
			bonus += 20 // идеальная реакция
		case ActionDelete:
			bonus += 10 // лучше, чем ничего
		case ActionQuarantine:
			bonus += 5 // осторожно, но без информирования
		case ActionAllow:
			penalty += 30 // пропустил атаку
		}
	} else {
		switch act {
		case ActionAllow:
			bonus += 15 // верно и без лишнего шума
		case ActionQuarantine:
			penalty += 5 // можно, но создаёт лишнюю работу
		case ActionReportPhish, ActionDelete:
			penalty += 15 // мешаешь бизнесу
		}
	}

	// флажки: чем больше корректных, тем выше бонус
	flags := 0
	if s.flagDmn.Checked {
		flags++
	}
	if s.flagUrl.Checked {
		flags++
	}
	if s.flagAtt.Checked {
		flags++
	}
	if s.flagUrg.Checked {
		flags++
	}
	bonus += flags * 3

	if baseRight {
		s.correct++
		s.combo++
		if s.combo > s.maxCombo {
			s.maxCombo = s.combo
		}
		s.score += s.points(m.Level, true) + bonus
	} else {
		s.wrong++
		s.combo = 0
		s.score -= s.points(m.Level, false) + penalty
		if s.score < 0 {
			s.score = 0
		}
	}

	s.scoreLbl.SetText(fmt.Sprintf("Очки: %d", s.score))
	s.comboLbl.SetText(fmt.Sprintf("Комбо: %d", s.combo))

	s.showExplanation(m, baseRight)

	if s.cur+1 < len(s.mails) {
		s.cur++
		s.list.Select(s.cur)
	} else {
		s.finish()
	}
}

func (s *PhishingScreen) points(l domain.PhishingLevel, correct bool) int {
	base := 0
	switch l {
	case domain.PhishingLevelEasy:
		base = 10
	case domain.PhishingLevelMedium:
		base = 20
	case domain.PhishingLevelHard:
		base = 30
	}
	if correct {
		return base
	}
	return base / 2
}

func (s *PhishingScreen) showExplanation(m domain.PhishingMail, right bool) {
	status := "Ответ неверный"
	if right {
		status = "Ответ верный"
	}
	flags := ""
	for _, f := range m.RedFlags {
		flags += "• " + f + "\n"
	}
	txt := fmt.Sprintf("%s.\n\nПояснение:\n%s\n\nПризнаки:\n%s", status, m.Explanation, flags)
	dialog.ShowInformation("Разбор письма", txt, s.w)
}

func (s *PhishingScreen) finish() {
	if s.cancel != nil {
		s.cancel()
	}

	res := &domain.PhishingResult{
		UserID:   s.user.ID,
		Mode:     s.mode,
		Level:    s.level,
		Score:    s.score,
		Correct:  s.correct,
		Wrong:    s.wrong,
		Skipped:  s.skipped,
		MaxCombo: s.maxCombo,
		Duration: time.Since(s.start),
	}
	_ = s.uc.SaveResult(context.Background(), res)

	summary := fmt.Sprintf("Очки: %d\nПравильных: %d\nОшибок: %d\nМакс. комбо: %d\nВремя: %s",
		res.Score, res.Correct, res.Wrong, res.MaxCombo, res.Duration.Truncate(time.Second))
	dialog.ShowInformation("Игра окончена", summary, s.w)
}
