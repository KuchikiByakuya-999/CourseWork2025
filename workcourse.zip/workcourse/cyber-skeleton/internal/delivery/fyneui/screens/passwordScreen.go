package screens

import (
	"context"
	"cyber-skeleton/internal/domain"
	"cyber-skeleton/internal/usecase"
	"fmt"
	"time"

	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/container"
	"fyne.io/fyne/v2/dialog"
	"fyne.io/fyne/v2/layout"
	"fyne.io/fyne/v2/widget"
)

type PasswordRouter interface {
	NavigateToDashboard(*domain.User)
}

type PasswordScreenV2 struct {
	w      fyne.Window
	router PasswordRouter
	uc     *usecase.PasswordUsecase
	user   *domain.User
	gameUC *usecase.GameUsecase

	// UI компоненты
	challenges  []domain.PasswordChallenge
	cur         int
	start       time.Time
	cancel      context.CancelFunc
	score       int
	correct     int
	wrong       int
	skipped     int
	combo       int
	maxCombo    int
	timerLbl    widget.Label
	scoreLbl    widget.Label
	comboLbl    widget.Label
	list        *widget.List
	passwordLbl widget.Label
	hintLbl     widget.Label
	strengthLbl widget.Label
	categoryLbl widget.Label
}

func NewPasswordScreenV2(
	w fyne.Window,
	r PasswordRouter,
	u *domain.User,
	pwUC *usecase.PasswordUsecase,
	gameUC *usecase.GameUsecase,
) *PasswordScreenV2 {
	return &PasswordScreenV2{
		w:      w,
		router: r,
		user:   u,
		uc:     pwUC,
		gameUC: gameUC,
	}
}

func (s *PasswordScreenV2) Build() fyne.CanvasObject {
	s.w.Resize(fyne.NewSize(1200, 700))

	// Кнопка "Теория" открывает отдельное окно
	btnTheory := widget.NewButton("📖 Теория", func() {
		s.showTheoryDialog()
	})

	btnStart := widget.NewButton("▶️ Начать игру", func() {
		s.buildGameScreen()
	})

	btnBack := widget.NewButton("🔙 Назад", func() {
		s.router.NavigateToDashboard(s.user)
	})

	menu := container.NewVBox(
		widget.NewLabelWithStyle("🔐 МОДУЛЬ: ПАРОЛИ", fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
		widget.NewLabel("Научитесь отличать слабые пароли от сильных"),
		widget.NewSeparator(),
		btnTheory,
		btnStart,
		btnBack,
	)

	return container.NewCenter(menu)
}

func (s *PasswordScreenV2) showTheoryDialog() {
	theoryText := `🔐 ТЕОРИЯ: ПАРОЛИ И АУТЕНТИФИКАЦИЯ

**Основные концепции:**
• Пароль - строка символов для подтверждения личности
• Слабый пароль: короткий, предсказуемый, легко перебирается
• Сильный пароль: длина 12+, разные типы символов, спецсимволы

**Типы взлома паролей:**

**1. BRUTE FORCE (Перебор)**
• Атакующий пробует все комбинации
• Время: зависит от длины пароля
• Защита: длина + сложность

**2. DICTIONARY ATTACK (Словарная атака)**
• Использует распространённые пароли
• Список: /usr/share/wordlists/rockyou.txt
• Защита: уникальные пароли

**3. RAINBOW TABLES (Радужные таблицы)**
• Предвычисленные хеши
• Защита: SALT + HASH

**4. PHISHING (Фишинг)**
• Социальная инженерия для кражи пароля
• Защита: 2FA, внимательность

**5. CREDENTIAL STUFFING (Переброс учётных данных)**
• Использует пароли из других утечек
• Защита: уникальные пароли для каждого сервиса

**Принципы сильного пароля:**
✅ Минимум 12-16 символов
✅ Прописные и строчные буквы (A-Z, a-z)
✅ Цифры (0-9)
✅ Спецсимволы (!@#$%^&*)
✅ Без личной информации
✅ Не повторяющиеся слова
✅ Не последовательные символы

**Время перебора (на 10^9 попыток/сек):**
• 6 символов: 1 секунда
• 8 символов: 1 час
• 10 символов: 2 месяца
• 12 символов: 200 лет
• 14+ символов: практически невозможно

**Менеджеры паролей:**
KeePass, 1Password, Bitwarden - генерируют и хранят сложные пароли

**Двухфакторная аутентификация (2FA):**
Добавляет второй слой защиты (TOTP, SMS, Биометрия)`

	richText := widget.NewRichTextFromMarkdown(theoryText)
	scroll := container.NewScroll(richText)
	scroll.SetMinSize(fyne.NewSize(800, 600))

	dialog.ShowCustom("📖 Теория: Пароли", "Закрыть", scroll, s.w)
}

func (s *PasswordScreenV2) buildGameScreen() {
	// Инициализируем компоненты
	s.timerLbl = *widget.NewLabel("00:00")
	s.timerLbl.TextStyle = fyne.TextStyle{Bold: true}
	s.timerLbl.Alignment = fyne.TextAlignCenter
	s.scoreLbl = *widget.NewLabel("0")
	s.scoreLbl.TextStyle = fyne.TextStyle{Bold: true}
	s.comboLbl = *widget.NewLabel("0")
	s.comboLbl.TextStyle = fyne.TextStyle{Bold: true}
	s.passwordLbl = *widget.NewLabel("")
	s.passwordLbl.TextStyle = fyne.TextStyle{Bold: true}
	s.passwordLbl.Wrapping = fyne.TextWrapWord
	s.hintLbl = *widget.NewLabel("")
	s.hintLbl.Wrapping = fyne.TextWrapWord
	s.strengthLbl = *widget.NewLabel("")
	s.categoryLbl = *widget.NewLabel("")

	// Список задач
	if s.list == nil {
		s.list = widget.NewList(
			func() int { return len(s.challenges) },
			func() fyne.CanvasObject {
				return container.NewHBox(
					widget.NewLabel("🔓"),
					widget.NewLabel(""),
				)
			},
			func(id widget.ListItemID, o fyne.CanvasObject) {
				if id < 0 || id >= widget.ListItemID(len(s.challenges)) {
					return
				}
				ch := s.challenges[id]
				c := o.(*fyne.Container)
				strength := ""
				for i := 0; i < ch.Strength; i++ {
					strength += "█"
				}
				for i := ch.Strength; i < 5; i++ {
					strength += "░"
				}
				c.Objects[1].(*widget.Label).SetText(
					fmt.Sprintf("Пароль #%d [%s]", id+1, strength),
				)
			},
		)
		s.list.OnSelected = func(id widget.ListItemID) {
			s.cur = int(id)
			s.showChallenge()
		}
	}

	// Кнопки действия
	btnWeak := widget.NewButton("❌ Слабый пароль", func() { s.answer(true) })
	btnWeak.Importance = widget.HighImportance
	btnStrong := widget.NewButton("✅ Сильный пароль", func() { s.answer(false) })
	btnStrong.Importance = widget.HighImportance
	btnSkip := widget.NewButton("⏭️ Пропустить", func() { s.skip() })
	btnBack := widget.NewButton("🔙 Назад в меню", func() {
		if s.cancel != nil {
			s.cancel()
		}
		s.w.SetContent(s.Build())
	})

	// Верхняя панель
	topBar := container.NewHBox(
		&s.timerLbl,
		layout.NewSpacer(),
		widget.NewLabel("⏱️ Время:"),
		widget.NewLabel("💰 Очки:"),
		&s.scoreLbl,
		widget.NewLabel("🔥 Комбо:"),
		&s.comboLbl,
	)

	// Информационная панель
	info := container.NewVBox(
		widget.NewLabelWithStyle("🔒 АНАЛИЗ ПАРОЛЯ", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		widget.NewSeparator(),
		widget.NewLabel("Пароль:"),
		&s.passwordLbl,
		widget.NewLabel("📋 Подсказка:"),
		&s.hintLbl,
		widget.NewLabel("📊 Сложность:"),
		&s.strengthLbl,
		widget.NewLabel("🏷️ Категория:"),
		&s.categoryLbl,
	)

	// Правая часть с действиями
	actions := container.NewVBox(
		widget.NewLabelWithStyle("Выберите правильный ответ:", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		btnWeak,
		btnStrong,
		btnSkip,
		layout.NewSpacer(),
		btnBack,
	)

	// Основной макет
	mainContent := container.NewHSplit(
		container.NewVBox(
			widget.NewLabelWithStyle("📝 ЗАДАНИЯ", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
			s.list,
		),
		container.NewBorder(
			topBar,
			actions,
			nil,
			nil,
			container.NewVScroll(info),
		),
	)

	mainContent.SetOffset(0.3)

	// Загружаем задачи
	s.loadChallenges()
	s.w.SetContent(mainContent)
}

func (s *PasswordScreenV2) loadChallenges() {
	ctx, cancel := context.WithCancel(context.Background())
	s.cancel = cancel

	// ИСПРАВЛЕНО: Используем генератор напрямую
	generatedChallenges := s.uc.GeneratePasswordChallenges(ctx)

	// Конвертируем
	s.challenges = make([]domain.PasswordChallenge, len(generatedChallenges))
	for i, gc := range generatedChallenges {
		s.challenges[i] = domain.PasswordChallenge{
			Password: gc.Password,
			IsWeak:   gc.IsWeak,
			Strength: gc.Strength,
			Category: gc.Category,
			Hint:     gc.Hint,
		}
	}

	s.list.Refresh()
	if len(s.challenges) == 0 {
		dialog.ShowInformation("Ошибка", "Не удалось сгенерировать задачи", s.w)
		return
	}

	s.cur = 0
	s.list.Select(0)
	s.showChallenge()
	s.start = time.Now()
	go s.timerLoop(ctx)
}

func (s *PasswordScreenV2) showChallenge() {
	if len(s.challenges) == 0 || s.cur < 0 || s.cur >= len(s.challenges) {
		return
	}
	ch := s.challenges[s.cur]
	s.passwordLbl.SetText(ch.Password)
	s.hintLbl.SetText(ch.Hint)
	strength := ""
	for i := 0; i < ch.Strength; i++ {
		strength += "🟩"
	}
	for i := ch.Strength; i < 5; i++ {
		strength += "⬜"
	}
	s.strengthLbl.SetText(fmt.Sprintf("%s (%d/5)", strength, ch.Strength))
	s.categoryLbl.SetText(fmt.Sprintf("🏷️ %s", ch.Category))
}

func (s *PasswordScreenV2) answer(markWeak bool) {
	if len(s.challenges) == 0 {
		return
	}
	ch := s.challenges[s.cur]
	right := (markWeak && ch.IsWeak) || (!markWeak && !ch.IsWeak)
	if right {
		s.correct++
		s.combo++
		if s.combo > s.maxCombo {
			s.maxCombo = s.combo
		}
		s.score += s.points(ch, true)
	} else {
		s.wrong++
		s.combo = 0
		s.score -= s.points(ch, false)
	}
	if s.score < 0 {
		s.score = 0
	}
	s.scoreLbl.SetText(fmt.Sprintf("%d", s.score))
	s.comboLbl.SetText(fmt.Sprintf("%d", s.combo))
	s.showExplanation(ch, right)
	if s.cur+1 < len(s.challenges) {
		s.cur++
		s.list.Select(widget.ListItemID(s.cur))
		s.showChallenge()
	} else {
		s.finish()
	}
}

func (s *PasswordScreenV2) skip() {
	if len(s.challenges) == 0 {
		return
	}
	s.skipped++
	s.combo = 0
	if s.cur+1 < len(s.challenges) {
		s.cur++
		s.list.Select(widget.ListItemID(s.cur))
		s.showChallenge()
	} else {
		s.finish()
	}
}

func (s *PasswordScreenV2) points(ch domain.PasswordChallenge, correct bool) int {
	base := 10 + ch.Strength*5
	if correct {
		return base
	}
	return base / 2
}

func (s *PasswordScreenV2) showExplanation(ch domain.PasswordChallenge, right bool) {
	status := "✅ ВЕРНО!"
	if !right {
		status = "❌ НЕВЕРНО!"
	}
	reason := ""
	if ch.IsWeak {
		reason = `⚠️ СЛАБЫЙ ПАРОЛЬ:
• Короткая длина
• Предсказуемые символы
• Есть в словаре распространённых паролей
• Легко перебирается (bruteforce)
• Может быть взломан за секунды/минуты`
	} else {
		reason = `🛡️ СИЛЬНЫЙ ПАРОЛЬ:
• Длина 12+ символов
• Разнообразие символов (буквы, цифры, спецсимволы)
• Не содержит личную информацию
• Не очевидные комбинации
• Время перебора: сотни лет`
	}
	txt := fmt.Sprintf(`%s

📝 ПАРОЛЬ: %s

📊 СЛОЖНОСТЬ: %d/5

%s

💡 СОВЕТ:
Используйте менеджер паролей для генерации
сложных паролей. Минимум 12 символов!`, status, ch.Password, ch.Strength, reason)
	dialog.ShowInformation("Разбор ответа", txt, s.w)
}

func (s *PasswordScreenV2) finish() {
	if s.cancel != nil {
		s.cancel()
	}
	dur := time.Since(s.start).Truncate(time.Second)
	maxScore := len(s.challenges) * 25
	if s.user != nil && s.gameUC != nil {
		ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
		defer cancel()
		_ = s.gameUC.SaveGameResult(ctx, s.user.ID, "password", s.score)
	}
	summary := fmt.Sprintf(`📊 МОДУЛЬ 2: ПАРОЛИ - ЗАВЕРШЁН

✅ Правильных: %d
❌ Ошибок: %d
⏭️ Пропущено: %d
🔥 Максимальный комбо: %d
⏱️ Время: %v

💰 ИТОГОВЫЕ ОЧКИ: %d / %d

🎯 РЕКОМЕНДАЦИИ:
• Используйте уникальные пароли для каждого сервиса
• Включайте спецсимволы и цифры
• Минимум 12 символов
• Используйте менеджер паролей
• Включайте 2FA где возможно`, s.correct, s.wrong, s.skipped, s.maxCombo, dur, s.score, maxScore)
	dialog.ShowInformation("Модуль завершён", summary, s.w)
	s.w.SetContent(s.Build())
}

func (s *PasswordScreenV2) timerLoop(ctx context.Context) {
	ticker := time.NewTicker(time.Second)
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			el := time.Since(s.start).Truncate(time.Second)
			min := int(el.Minutes())
			sec := int(el.Seconds()) % 60
			txt := fmt.Sprintf("%02d:%02d", min, sec)
			s.timerLbl.SetText(txt)
		}
	}
}
