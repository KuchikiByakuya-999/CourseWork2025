package screens

import (
	"context"
	"cyber-skeleton/internal/domain"
	"cyber-skeleton/internal/usecase"
	"fmt"
	"time"

	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/container"
	"fyne.io/fyne/v2/dialog"
	"fyne.io/fyne/v2/layout"
	"fyne.io/fyne/v2/widget"
)

type NetworkRouter interface {
	NavigateToDashboard(u *domain.User)
}

type NetworkScreenV2 struct {
	w            fyne.Window
	router       NetworkRouter
	uc           *usecase.NetworkUsecase
	user         *domain.User
	gameUC       *usecase.GameUsecase
	themeManager *ThemeManager

	incidents       []domain.NetworkIncident
	cur             int
	start           time.Time
	cancel          context.CancelFunc
	score           int
	correct         int
	wrong           int
	skipped         int
	combo           int
	maxCombo        int
	timerLbl        widget.Label
	scoreLbl        widget.Label
	comboLbl        widget.Label
	list            *widget.List
	typeLbl         widget.Label
	descriptionLbl  widget.Label
	impactLbl       widget.Label
	logsContainer   *fyne.Container
	theoryContainer *fyne.Container
	showTheory      bool
}

func NewNetworkScreenV2(
	w fyne.Window,
	r NetworkRouter,
	u *domain.User,
	uc *usecase.NetworkUsecase,
	gameUC *usecase.GameUsecase,
	themeManager *ThemeManager,
) *NetworkScreenV2 {
	return &NetworkScreenV2{
		w:            w,
		router:       r,
		user:         u,
		uc:           uc,
		gameUC:       gameUC,
		themeManager: themeManager,
		showTheory:   true,
	}
}

func (s *NetworkScreenV2) showTheoryDialog() {
	theoryText := `🌐 ТЕОРИЯ: СЕТЕВЫЕ АТАКИ И ИНЦИДЕНТЫ

**Основные концепции:**
• Сетевой инцидент - событие, нарушающее конфиденциальность/целостность/доступность
• Киберугроза - потенциальная опасность в сети
• Киберинцидент - реализованная атака

**КЛАССИФИКАЦИЯ АТАК:**

**1. DDoS-АТАКИ (Distributed Denial of Service)**
Цель: Прервать работу сервиса
Типы:
• Volumetric: забивают канал (DNS amplification, NTP reflection)
• Protocol: эксплуатируют слабость протокола (SYN flood, Smurf)
• Application: истощают ресурсы приложения (HTTP flood, Slowloris)

Размер: от 1 Gbps (обычные) до 1 Tbps (крупные)
Продолжительность: от минут до недель
Стоимость: от 1-10K$ до 300K$ за атаку

Защита:
• WAF (Web Application Firewall)
• Rate limiting (ограничение запросов)
• CDN с DDoS-защитой
• Чёрный список IP

**2. ПОПЫТКИ ВЗЛОМА (Intrusion Attempts)**

SSH Bruteforce: перебор пароля по SSH
• Скорость: 10-100 попыток/сек
• Защита: ключи SSH, 2FA, изменить порт

SQL Injection: манипуляция SQL-запросами
• Пример: WHERE id = '1' OR '1'='1'
• Последствия: утечка БД, модификация данных
• Защита: Prepared Statements, Input Validation

RCE (Remote Code Execution): выполнение кода
• Последствие: полный контроль над сервером
• Примеры: Command Injection, Python eval(), PHP exec()
• Защита: Input Sanitization, Least Privilege

**3. УТЕЧКИ ДАННЫХ (Data Breaches)**

Открытые сервисы: S3 bucket, Memcache, MongoDB без пароля
• Потеря: миллионы записей в открытом доступе

Insider Threat: сотрудник сливает данные
• Мотив: деньги, месть, шпионаж
• Предупреждение: DLP (Data Loss Prevention)

Ransomware утечка: вредонос копирует перед шифрованием
• Требование: выкуп за не-публикацию данных

**4. КОНФИГУРАЦИОННЫЕ ОШИБКИ (Misconfigurations)**
• Firewall: неверные правила открывают доступ
• Cloud IAM: избыточные права доступа
• Service: уязвимая версия ПО с известной CVE
• API: эндпоинты без аутентификации

**5. ПРОДВИНУТЫЕ АТАКИ (Advanced)**
• DNS Spoofing: подделка DNS-записей
• MITM (Man-in-the-Middle): перехват трафика
• Memcache Exposure: открытый кэш с сессиями

**ФАЗЫ ИНЦИДЕНТА:**

1. DETECTION (Обнаружение)
   - Анализ логов и алертов
   - IDS/IPS срабатывает

2. CONTAINMENT (Локализация)
   - Блокировка источника атаки
   - Изоляция поражённых систем

3. ERADICATION (Уничтожение)
   - Установка патчей
   - Удаление вредоноса/backdoor

4. RECOVERY (Восстановление)
   - Восстановление из резервной копии
   - Перезапуск сервисов

5. POST-INCIDENT (Выводы)
   - Анализ хронологии
   - Улучшение процессов

**ДЕЙСТВИЯ ПРИ ИНЦИДЕНТЕ:**
✅ BLOCK: блокировать IP/source атаки
✅ PATCH: установить критический патч
✅ ISOLATE: отключить от сети поражённый хост
✅ IGNORE: если это false positive`

	richText := widget.NewRichTextFromMarkdown(theoryText)
	scroll := container.NewScroll(richText)
	scroll.SetMinSize(fyne.NewSize(800, 600))

	dialog.ShowCustom("📖 Теория: Сетевые атаки", "Закрыть", scroll, s.w)
}

func (s *NetworkScreenV2) Build() fyne.CanvasObject {
	s.w.Resize(fyne.NewSize(1200, 700))

	btnTheory := widget.NewButton("📖 Теория", func() {
		s.showTheoryDialog()
	})

	btnStart := widget.NewButton("▶️ Начать игру", func() {
		s.buildGameScreen()
	})

	btnBack := widget.NewButton("🔙 Назад", func() {
		s.router.NavigateToDashboard(s.user)
	})

	menu := container.NewVBox(
		widget.NewLabelWithStyle("🌐 МОДУЛЬ: СЕТЕВЫЕ ИНЦИДЕНТЫ", fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
		widget.NewLabel("Научитесь правильно реагировать на сетевые атаки"),
		widget.NewSeparator(),
		btnTheory,
		btnStart,
		btnBack,
	)

	return container.NewCenter(menu)
}

func (s *NetworkScreenV2) buildGameScreen() {
	s.timerLbl = *widget.NewLabel("00:00")
	s.timerLbl.TextStyle = fyne.TextStyle{Bold: true}
	s.timerLbl.Alignment = fyne.TextAlignCenter
	s.scoreLbl = *widget.NewLabel("0")
	s.scoreLbl.TextStyle = fyne.TextStyle{Bold: true}
	s.comboLbl = *widget.NewLabel("0")
	s.comboLbl.TextStyle = fyne.TextStyle{Bold: true}
	s.typeLbl = *widget.NewLabel("")
	s.typeLbl.TextStyle = fyne.TextStyle{Bold: true}
	s.descriptionLbl = *widget.NewLabel("")
	s.descriptionLbl.Wrapping = fyne.TextWrapWord
	s.impactLbl = *widget.NewLabel("")
	s.impactLbl.Wrapping = fyne.TextWrapWord

	// Список инцидентов
	if s.list == nil {
		s.list = widget.NewList(
			func() int { return len(s.incidents) },
			func() fyne.CanvasObject {
				return container.NewHBox(
					widget.NewLabel("⚠️"),
					widget.NewLabel(""),
				)
			},
			func(id widget.ListItemID, o fyne.CanvasObject) {
				if id < 0 || id >= widget.ListItemID(len(s.incidents)) {
					return
				}
				inc := s.incidents[id]
				c := o.(*fyne.Container)
				title := s.incidentTitle(inc)
				c.Objects[1].(*widget.Label).SetText(title)
			},
		)
		s.list.OnSelected = func(id widget.ListItemID) {
			s.cur = int(id)
			s.showIncident()
		}
	}

	// Логи
	s.logsContainer = container.NewVBox()

	// Кнопки действия
	btnBlock := widget.NewButton("🚫 BLOCK (Блокировать IP)", func() { s.answer("block") })
	btnBlock.Importance = widget.HighImportance
	btnPatch := widget.NewButton("🛠️ PATCH (Установить патч)", func() { s.answer("patch") })
	btnPatch.Importance = widget.HighImportance
	btnIsolate := widget.NewButton("🧱 ISOLATE (Изолировать)", func() { s.answer("isolate") })
	btnIsolate.Importance = widget.HighImportance
	btnIgnore := widget.NewButton("⏭️ IGNORE (Игнорировать)", func() { s.answer("ignore") })
	btnBack := widget.NewButton("🔙 Назад в меню", func() {
		if s.cancel != nil {
			s.cancel()
		}
		s.w.SetContent(s.Build())
	})

	// Верхняя панель
	topBar := container.NewHBox(
		&s.timerLbl,
		layout.NewSpacer(),
		widget.NewLabel("⏱️"),
		widget.NewLabel("💰 Очки:"),
		&s.scoreLbl,
		widget.NewLabel("🔥 Комбо:"),
		&s.comboLbl,
	)

	// Информационная панель
	info := container.NewVBox(
		widget.NewLabelWithStyle("🚨 АНАЛИЗ ИНЦИДЕНТА", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		widget.NewSeparator(),
		widget.NewLabel("Тип инцидента:"),
		&s.typeLbl,
		widget.NewLabel("📝 Описание:"),
		&s.descriptionLbl,
		widget.NewLabel("💥 Воздействие:"),
		&s.impactLbl,
		widget.NewSeparator(),
		widget.NewLabelWithStyle("📋 ЛОГИ ИНЦИДЕНТА", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		container.NewScroll(s.logsContainer),
	)

	// Действия
	actions := container.NewVBox(
		widget.NewLabelWithStyle("Выберите правильное действие:", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		btnBlock,
		btnPatch,
		btnIsolate,
		btnIgnore,
		layout.NewSpacer(),
		btnBack,
	)

	// Основной макет
	mainContent := container.NewHSplit(
		container.NewVBox(
			widget.NewLabelWithStyle("📊 ИНЦИДЕНТЫ", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
			s.list,
		),
		container.NewBorder(
			topBar,
			actions,
			nil,
			nil,
			container.NewVScroll(info),
		),
	)

	mainContent.SetOffset(0.3)
	s.loadIncidents()
	s.w.SetContent(mainContent)
}

func (s *NetworkScreenV2) loadIncidents() {
	ctx, cancel := context.WithCancel(context.Background())
	s.cancel = cancel

	incidents, err := s.uc.GenerateNetworkIncidents(ctx)
	if err != nil {
		dialog.ShowError(err, s.w)
		return
	}

	s.incidents = incidents
	s.list.Refresh()
	if len(s.incidents) == 0 {
		dialog.ShowInformation("Ошибка", "Не удалось сгенерировать инциденты", s.w)
		return
	}

	s.cur = 0
	s.list.Select(0)
	s.showIncident()
	s.start = time.Now()
	go s.timerLoop(ctx)
}

func (s *NetworkScreenV2) incidentTitle(inc domain.NetworkIncident) string {
	switch inc.Type {
	case "ddos_volumetric":
		return "🌊 DDoS Volumetric Attack"
	case "ddos_application":
		return "💻 DDoS Application Level"
	case "ddos_botnet":
		return "🤖 Botnet Attack"
	case "intrusion_bruteforce":
		return "🔐 SSH Bruteforce"
	case "intrusion_sqli":
		return "💉 SQL Injection"
	case "intrusion_rce":
		return "🚀 Remote Code Execution"
	case "leak_unencrypted":
		return "📂 Data Leak (S3)"
	case "leak_insider":
		return "👤 Insider Threat"
	case "leak_ransomware":
		return "🔒 Ransomware + Leak"
	case "misconfig_firewall":
		return "🔥 Firewall Misconfiguration"
	case "misconfig_service":
		return "⚙️ Vulnerable Service"
	case "misconfig_api":
		return "🌐 Unauthenticated API"
	case "dns_spoofing":
		return "📡 DNS Spoofing"
	case "mitm_ssl":
		return "↔️ Man-in-the-Middle"
	case "memcache_exposure":
		return "🗂️ Memcache Exposure"
	default:
		return "⚠️ Unknown Incident"
	}
}

func (s *NetworkScreenV2) showIncident() {
	if len(s.incidents) == 0 || s.cur < 0 || s.cur >= len(s.incidents) {
		return
	}

	inc := s.incidents[s.cur]
	s.typeLbl.SetText(s.incidentTitle(inc))
	s.descriptionLbl.SetText(s.incidentTitle(inc))
	s.impactLbl.SetText(inc.Type)

	s.logsContainer.RemoveAll()
	for i, log := range inc.Logs {
		logLabel := widget.NewLabel(fmt.Sprintf("[%d] %s", i+1, log))
		logLabel.Wrapping = fyne.TextWrapWord
		s.logsContainer.Add(logLabel)
	}
}

func (s *NetworkScreenV2) answer(action string) {
	if len(s.incidents) == 0 {
		return
	}

	inc := s.incidents[s.cur]
	right := action == inc.Action

	if right {
		s.correct++
		s.combo++
		if s.combo > s.maxCombo {
			s.maxCombo = s.combo
		}
		s.score += s.points(inc, true)
	} else {
		s.wrong++
		s.combo = 0
		s.score -= s.points(inc, false)
	}

	if s.score < 0 {
		s.score = 0
	}

	s.scoreLbl.SetText(fmt.Sprintf("%d", s.score))
	s.comboLbl.SetText(fmt.Sprintf("%d", s.combo))

	s.showExplanation(inc, right, action)

	if s.cur+1 < len(s.incidents) {
		s.cur++
		s.list.Select(widget.ListItemID(s.cur))
		s.showIncident()
	} else {
		s.finish()
	}
}

func (s *NetworkScreenV2) points(inc domain.NetworkIncident, correct bool) int {
	base := 50
	switch inc.Type {
	case "ddos_botnet", "intrusion_rce", "leak_ransomware":
		base = 100
	case "ddos_application", "intrusion_sqli":
		base = 75
	}

	if correct {
		return base
	}
	return base / 2
}

func (s *NetworkScreenV2) showExplanation(inc domain.NetworkIncident, right bool, chosen string) {
	status := "✅ ПРАВИЛЬНОЕ ДЕЙСТВИЕ!"
	if !right {
		status = "❌ НЕПРАВИЛЬНОЕ ДЕЙСТВИЕ!"
	}

	actions := map[string]string{
		"block":   "🚫 BLOCK - Блокировать источник атаки",
		"patch":   "🛠️ PATCH - Установить критический патч",
		"isolate": "🧱 ISOLATE - Отключить от сети",
		"ignore":  "⏭️ IGNORE - Это не инцидент",
	}

	txt := fmt.Sprintf(`%s

🎯 ТИП: %s

📝 ОПИСАНИЕ: %s

💥 ВОЗДЕЙСТВИЕ:
%s

✅ ПРАВИЛЬНОЕ ДЕЙСТВИЕ: %s

🔴 ВЫ ВЫБРАЛИ: %s

📚 ОБЪЯСНЕНИЕ:
Данный инцидент требует именно этого действия для его разрешения.
Неправильное действие может привести к дополнительным убыткам.`,
		status,
		s.incidentTitle(inc),
		s.incidentTitle(inc),
		inc.Type,
		actions[inc.Action],
		actions[chosen],
	)

	dialog.ShowInformation("Разбор инцидента", txt, s.w)
}

func (s *NetworkScreenV2) finish() {
	if s.cancel != nil {
		s.cancel()
	}

	dur := time.Since(s.start).Truncate(time.Second)

	if s.user != nil && s.gameUC != nil {
		ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
		defer cancel()
		_ = s.gameUC.SaveGameResult(ctx, s.user.ID, "network", s.score)
	}

	summary := fmt.Sprintf(`
📊 МОДУЛЬ 3: СЕТЕВЫЕ ИНЦИДЕНТЫ - ЗАВЕРШЁН

✅ Правильных: %d
❌ Ошибок: %d
⏭️ Пропущено: %d
🔥 Максимальный комбо: %d
⏱️ Время: %v

💰 ИТОГОВЫЕ ОЧКИ: %d

🎯 РЕКОМЕНДАЦИИ:
• Изучайте типы инцидентов
• Понимайте правильное разрешение
• Реагируйте быстро при реальных инцидентах
• Имейте план реагирования на инциденты
• Используйте SIEM для мониторинга
`,
		s.correct, s.wrong, s.skipped, s.maxCombo, dur,
		s.score,
	)

	dialog.ShowInformation("Модуль завершён", summary, s.w)
	s.router.NavigateToDashboard(s.user)
}

func (s *NetworkScreenV2) timerLoop(ctx context.Context) {
	ticker := time.NewTicker(time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			el := time.Since(s.start).Truncate(time.Second)
			min := int(el.Minutes())
			sec := int(el.Seconds()) % 60
			txt := fmt.Sprintf("%02d:%02d", min, sec)
			s.timerLbl.SetText(txt)
		}
	}
}
