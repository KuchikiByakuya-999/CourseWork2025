package screens

import (
	"context"
	"fmt"
	"math/rand"
	"time"

	"cyber-skeleton/internal/domain"
	"cyber-skeleton/internal/usecase"

	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/container"
	"fyne.io/fyne/v2/dialog"
	"fyne.io/fyne/v2/widget"
)

type CryptoRouter interface {
	NavigateToDashboard(u *domain.User)
}

type CryptoScreen struct {
	w          fyne.Window
	router     CryptoRouter
	user       *domain.User
	gameUC     *usecase.GameUsecase
	showTheory bool

	challenges []CryptoChallenge
	current    int
	score      int
	round      int
	maxRounds  int
}

type CryptoChallenge struct {
	Question      string
	Options       []string
	CorrectAnswer string
	Explanation   string
	Category      string
}

func NewCryptoScreen(w fyne.Window, r CryptoRouter, u *domain.User, gameUC *usecase.GameUsecase) *CryptoScreen {
	return &CryptoScreen{
		w:          w,
		router:     r,
		user:       u,
		gameUC:     gameUC,
		maxRounds:  10,
		showTheory: true,
	}
}

func (s *CryptoScreen) Build() fyne.CanvasObject {
	s.w.Resize(fyne.NewSize(1200, 700))

	if s.showTheory {
		return s.buildTheory()
	}

	return s.buildGame()
}

func (s *CryptoScreen) buildTheory() fyne.CanvasObject {
	theoryText := `🔑 КРИПТОГРАФИЯ И ХЕШИРОВАНИЕ

**Основные концепции:**
• Криптография - наука о защите информации
• Шифрование - преобразование данных в нечитаемый вид
• Хеширование - получение "отпечатка" данных фиксированной длины

**1. СИММЕТРИЧНОЕ ШИФРОВАНИЕ**
Один ключ для шифрования и расшифрования
• AES (Advanced Encryption Standard) - стандарт США
• ChaCha20 - современный, быстрый алгоритм
• 3DES - устаревший, не рекомендуется
• Применение: шифрование дисков, VPN, файлов

**2. АСИММЕТРИЧНОЕ ШИФРОВАНИЕ**
Пара ключей: публичный (открытый) + приватный (закрытый)
• RSA - классика, медленный
• ECC (Elliptic Curve) - быстрый, компактный
• Применение: SSL/TLS, цифровые подписи, PGP

**3. ХЕШИРОВАНИЕ**
Необратимое преобразование → всегда одна длина
• MD5 - ВЗЛОМАН (128 бит)
• SHA-1 - ВЗЛОМАН (160 бит)
• SHA-256 - безопасен (256 бит)
• SHA-512 - ещё безопаснее (512 бит)
• BLAKE2/3 - современные, быстрые
• Применение: пароли, проверка целостности

**4. SALT + HASH**
Защита от Rainbow Tables
• SALT = случайная строка + пароль
• Пример: SHA256(salt + "password123")
• Каждый пароль → уникальный хеш

**5. ЦИФРОВЫЕ ПОДПИСИ**
Доказательство авторства
• Hash данных → шифрование приватным ключом
• Проверка публичным ключом
• Применение: документы, софт, блокчейн

**6. СЛАБЫЕ МЕСТА**
❌ MD5 - коллизии за секунды
❌ SHA-1 - атака Google 2017
❌ Короткие ключи RSA (<2048 бит)
❌ Хеши без SALT
❌ Самописные алгоритмы

**7. СОВРЕМЕННЫЕ СТАНДАРТЫ**
✅ AES-256 для симметрии
✅ RSA-4096 или ECC-256 для асимметрии
✅ SHA-256/SHA-512 для хеширования
✅ bcrypt/scrypt/argon2 для паролей
✅ TLS 1.3 для сетевого шифрования`

	richText := widget.NewRichTextFromMarkdown(theoryText)
	scroll := container.NewScroll(richText)

	btnStart := widget.NewButton("▶️ Начать игру", func() {
		s.showTheory = false
		s.w.SetContent(s.Build())
	})

	btnBack := widget.NewButton("🔙 Назад", func() {
		s.router.NavigateToDashboard(s.user)
	})

	content := container.NewBorder(
		widget.NewLabelWithStyle("🔑 КРИПТОГРАФИЯ - ТЕОРИЯ", fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
		container.NewVBox(
			widget.NewSeparator(),
			container.NewHBox(btnStart, btnBack),
		),
		nil,
		nil,
		scroll,
	)

	return container.NewPadded(content)
}

func (s *CryptoScreen) buildGame() fyne.CanvasObject {
	return widget.NewLabel("Загрузка...")
}

func (s *CryptoScreen) startGame() {
	s.score = 0
	s.round = 0
	s.current = 0
	s.challenges = s.generateChallenges()
	s.nextRound()
}

func (s *CryptoScreen) generateChallenges() []CryptoChallenge {
	all := []CryptoChallenge{
		{
			Question:      "Какой алгоритм хеширования считается ВЗЛОМАННЫМ и НЕ должен использоваться?",
			Options:       []string{"SHA-256", "MD5", "bcrypt", "BLAKE2"},
			CorrectAnswer: "MD5",
			Explanation:   "MD5 взломан ещё в 2004 году. Коллизии генерируются за секунды.",
			Category:      "Хеширование",
		},
		{
			Question:      "Что такое SALT в контексте хеширования паролей?",
			Options:       []string{"Длина хеша", "Случайная строка, добавляемая к паролю", "Тип шифрования", "Алгоритм сжатия"},
			CorrectAnswer: "Случайная строка, добавляемая к паролю",
			Explanation:   "SALT предотвращает атаки с помощью Rainbow Tables, делая каждый хеш уникальным.",
			Category:      "Хеширование",
		},
		{
			Question:      "Какой тип шифрования использует ОДНУ пару ключей: публичный + приватный?",
			Options:       []string{"Симметричное", "Асимметричное", "Хеширование", "Квантовое"},
			CorrectAnswer: "Асимметричное",
			Explanation:   "Асимметричное шифрование (RSA, ECC) использует 2 ключа: публичный для шифрования, приватный для расшифровки.",
			Category:      "Шифрование",
		},
		{
			Question:      "Минимальная рекомендуемая длина ключа RSA в 2024 году?",
			Options:       []string{"512 бит", "1024 бит", "2048 бит", "4096 бит"},
			CorrectAnswer: "2048 бит",
			Explanation:   "2048 бит - минимум. 4096 бит - ещё надёжнее, но медленнее.",
			Category:      "Шифрование",
		},
		{
			Question:      "Какой алгоритм используется для шифрования дисков BitLocker и FileVault?",
			Options:       []string{"RSA", "AES", "MD5", "DES"},
			CorrectAnswer: "AES",
			Explanation:   "AES (Advanced Encryption Standard) - стандарт симметричного шифрования для дисков.",
			Category:      "Шифрование",
		},
		{
			Question:      "Можно ли расшифровать SHA-256 хеш обратно в исходный текст?",
			Options:       []string{"Да, с правильным ключом", "Да, с помощью квантового компьютера", "Нет, хеширование необратимо", "Да, через rainbow tables"},
			CorrectAnswer: "Нет, хеширование необратимо",
			Explanation:   "Хеширование - односторонняя функция. Можно только перебрать (brute force) или найти в rainbow tables.",
			Category:      "Хеширование",
		},
		{
			Question:      "Что означает TLS в контексте веб-безопасности?",
			Options:       []string{"Total Login Security", "Transport Layer Security", "Triple Layer Shield", "Trusted Link System"},
			CorrectAnswer: "Transport Layer Security",
			Explanation:   "TLS шифрует соединение между браузером и сервером (HTTPS). Замена устаревшего SSL.",
			Category:      "Протоколы",
		},
		{
			Question:      "Какой алгоритм лучше всего подходит для хеширования паролей?",
			Options:       []string{"MD5", "SHA-256", "bcrypt", "Base64"},
			CorrectAnswer: "bcrypt",
			Explanation:   "bcrypt специально разработан для паролей: медленный, с автоматическим SALT и защитой от GPU-перебора.",
			Category:      "Хеширование паролей",
		},
		{
			Question:      "Что произойдёт, если изменить хотя бы 1 бит в исходных данных перед хешированием?",
			Options:       []string{"Хеш не изменится", "Хеш изменится полностью", "Хеш изменится на 1 бит", "Произойдёт ошибка"},
			CorrectAnswer: "Хеш изменится полностью",
			Explanation:   "Эффект лавины: даже минимальное изменение данных → совершенно другой хеш.",
			Category:      "Хеширование",
		},
		{
			Question:      "Для чего используется цифровая подпись?",
			Options:       []string{"Шифрование файлов", "Подтверждение авторства и целостности", "Сжатие данных", "Ускорение передачи"},
			CorrectAnswer: "Подтверждение авторства и целостности",
			Explanation:   "Цифровая подпись доказывает, что документ создан конкретным человеком и не был изменён.",
			Category:      "Цифровые подписи",
		},
		{
			Question:      "Какой длины хеш выдаёт SHA-256?",
			Options:       []string{"128 бит", "256 бит", "512 бит", "1024 бит"},
			CorrectAnswer: "256 бит",
			Explanation:   "SHA-256 всегда выдаёт хеш длиной 256 бит (32 байта, 64 hex-символа).",
			Category:      "Хеширование",
		},
		{
			Question:      "Что опаснее для безопасности: использовать MD5 или не использовать SALT?",
			Options:       []string{"MD5", "Отсутствие SALT", "Оба одинаково опасны", "Ни то, ни другое не опасно"},
			CorrectAnswer: "Оба одинаково опасны",
			Explanation:   "MD5 легко взломать, а без SALT можно использовать rainbow tables. Оба - критические уязвимости.",
			Category:      "Безопасность",
		},
	}

	rand.Seed(time.Now().UnixNano())
	rand.Shuffle(len(all), func(i, j int) {
		all[i], all[j] = all[j], all[i]
	})

	if len(all) > s.maxRounds {
		return all[:s.maxRounds]
	}
	return all
}

func (s *CryptoScreen) nextRound() {
	if s.current >= len(s.challenges) {
		s.endGame()
		return
	}

	s.round++
	challenge := s.challenges[s.current]

	scoreLabel := widget.NewLabel(fmt.Sprintf("🏆 Очки: %d | Раунд: %d/%d", s.score, s.round, s.maxRounds))
	questionLabel := widget.NewLabelWithStyle(challenge.Question, fyne.TextAlignLeading, fyne.TextStyle{Bold: true})
	questionLabel.Wrapping = fyne.TextWrapWord

	categoryLabel := widget.NewLabel(fmt.Sprintf("📂 Категория: %s", challenge.Category))

	var buttons []fyne.CanvasObject
	for _, opt := range challenge.Options {
		option := opt
		btn := widget.NewButton(option, func() {
			s.checkAnswer(option, challenge)
		})
		buttons = append(buttons, btn)
	}

	content := container.NewVBox(
		scoreLabel,
		widget.NewSeparator(),
		categoryLabel,
		questionLabel,
		widget.NewSeparator(),
	)

	for _, btn := range buttons {
		content.Add(btn)
	}

	s.w.SetContent(container.NewScroll(content))
}

func (s *CryptoScreen) checkAnswer(selected string, challenge CryptoChallenge) {
	correct := selected == challenge.CorrectAnswer

	if correct {
		s.score += 100
		msg := fmt.Sprintf("✅ ПРАВИЛЬНО!\n\n%s\n\n+100 очков!\nТекущий счёт: %d", challenge.Explanation, s.score)
		dialog.ShowInformation("Верно!", msg, s.w)
	} else {
		msg := fmt.Sprintf("❌ НЕВЕРНО!\n\nПравильный ответ:\n%s\n\n%s", challenge.CorrectAnswer, challenge.Explanation)
		dialog.ShowInformation("Ошибка", msg, s.w)
	}

	s.current++
	s.nextRound()
}

func (s *CryptoScreen) endGame() {
	ctx := context.Background()
	s.gameUC.SaveGameResult(ctx, s.user.ID, "crypto", s.score)

	percentage := (s.score * 100) / (s.maxRounds * 100)
	grade := "Новичок"
	if percentage >= 90 {
		grade = "Эксперт 🏆"
	} else if percentage >= 70 {
		grade = "Продвинутый 🎖️"
	} else if percentage >= 50 {
		grade = "Средний уровень 📘"
	}

	result := fmt.Sprintf(`🎮 ИГРА ЗАВЕРШЕНА!

Финальный счёт: %d очков
Правильных ответов: %d/%d
Процент успеха: %d%%

Ваш уровень: %s`, s.score, s.score/100, s.maxRounds, percentage, grade)

	dialog.ShowInformation("Результат", result, s.w)
	s.router.NavigateToDashboard(s.user)
}
