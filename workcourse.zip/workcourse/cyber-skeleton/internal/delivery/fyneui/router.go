package fyneui

import (
	"cyber-skeleton/internal/delivery/fyneui/screens"
	"cyber-skeleton/internal/domain"
	"cyber-skeleton/internal/usecase"

	"fyne.io/fyne/v2"
)

type Router struct {
	window       fyne.Window
	current      *domain.User
	phishingUC   *usecase.PhishingUsecase
	passwordUC   *usecase.PasswordUsecase
	networkUC    *usecase.NetworkUsecase
	gameUC       *usecase.GameUsecase
	authUC       *usecase.AuthUsecase
	themeManager *screens.ThemeManager
}

func NewRouter(
	w fyne.Window,
	authUC *usecase.AuthUsecase,
	phishingUC *usecase.PhishingUsecase,
	passwordUC *usecase.PasswordUsecase,
	networkUC *usecase.NetworkUsecase,
	gameUC *usecase.GameUsecase,
) *Router {
	return &Router{
		window:       w,
		authUC:       authUC,
		phishingUC:   phishingUC,
		passwordUC:   passwordUC,
		networkUC:    networkUC,
		gameUC:       gameUC,
		themeManager: screens.NewThemeManager(),
	}
}

func (r *Router) NavigateToAuth() {
	screen := screens.NewLoginScreen(r.window, r, r.authUC)
	r.window.SetContent(screen.Build())
}

func (r *Router) ShowLoginScreen() {
	r.NavigateToAuth()
}

func (r *Router) ShowRegisterScreen() {
	r.NavigateToRegister()
}

func (r *Router) NavigateToRegister() {
	screen := screens.NewRegisterScreen(r.window, r, r.authUC)
	r.window.SetContent(screen.Build())
}

func (r *Router) NavigateToDashboard(u *domain.User) {
	if u == nil {
		u = r.current
	}
	r.current = u
	screen := screens.NewDashboardScreenV2(r.window, r, u, r.phishingUC, r.passwordUC, r.networkUC, r.gameUC, r.themeManager)
	r.window.SetContent(screen.Build())
}

func (r *Router) NavigateToProfile(u *domain.User) {
	if u == nil {
		u = r.current
	}
	screen := screens.NewProfileScreenV2(r.window, r, u, r.gameUC)
	r.window.SetContent(screen.Build())
}

func (r *Router) NavigateToPhishing(u *domain.User, mode domain.PhishingMode, level domain.PhishingLevel) {
	if u == nil {
		u = r.current
	}
	screen := screens.NewPhishingScreen(r.window, r, u, r.phishingUC, mode, level)
	r.window.SetContent(screen.Build())
}

func (r *Router) NavigateToPhishingGame() {
	r.NavigateToPhishing(r.current, 1, domain.PhishingLevelEasy)
}

func (r *Router) NavigateToPassword(u *domain.User) {
	if u == nil {
		u = r.current
	}
	screen := screens.NewPasswordScreenV2(r.window, r, u, r.passwordUC, r.gameUC)
	r.window.SetContent(screen.Build())
}

func (r *Router) NavigateToPasswordGame() {
	r.NavigateToPassword(r.current)
}

func (r *Router) NavigateToNetwork(u *domain.User) {
	if u == nil {
		u = r.current
	}
	screen := screens.NewNetworkScreenV2(r.window, r, u, r.networkUC, r.gameUC, r.themeManager)
	r.window.SetContent(screen.Build())
}

func (r *Router) NavigateToNetworkGame() {
	r.NavigateToNetwork(r.current)
}

func (r *Router) NavigateToCrypto(u *domain.User) {
	if u == nil {
		u = r.current
	}
	screen := screens.NewCryptoScreen(r.window, r, u, r.gameUC)
	r.window.SetContent(screen.Build())
}

func (r *Router) NavigateToCryptoGame() {
	r.NavigateToCrypto(r.current)
}

func (r *Router) NavigateToMalware(u *domain.User) {
	if u == nil {
		u = r.current
	}
	screen := screens.NewMalwareScreen(r.window, r, u, r.gameUC)
	r.window.SetContent(screen.Build())
}

func (r *Router) NavigateToMalwareGame() {
	r.NavigateToMalware(r.current)
}

// УДАЛЕНО: NavigateToSocialEng и NavigateToSocialEngineeringGame
