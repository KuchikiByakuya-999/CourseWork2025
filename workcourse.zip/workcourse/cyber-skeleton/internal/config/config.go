package config

import "os"

type Config struct {
	DatabaseURL string
	UseMock     bool
}

func Load() (*Config, error) {
	url := os.Getenv("DATABASE_URL")
	if url == "" {
		url = "postgres://postgres:postgres@localhost:5432/cyberdb?sslmode=disable"
	}

	useMock := os.Getenv("USE_MOCK") == "1"
	return &Config{
		DatabaseURL: url,
		UseMock:     useMock,
	}, nil
}
