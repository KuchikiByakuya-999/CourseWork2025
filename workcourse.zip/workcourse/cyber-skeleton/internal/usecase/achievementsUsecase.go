package usecase

import (
	"context"
	"cyber-skeleton/internal/domain"
)

func (g *GameUsecase) Achievements(ctx context.Context, userID int64) ([]domain.Achievement, error) {
	stats, err := g.repo.GetModuleStats(ctx, userID)
	if err != nil {
		return nil, err
	}

	var res []domain.Achievement

	// Антифишер: лучший результат по фишингу > 300
	a1 := domain.Achievement{
		Code:        "anti-phisher",
		Title:       "Антифишер",
		Description: "Отлично распознаёте фишинговые письма.",
	}
	if st, ok := stats["phishing"]; ok && st.BestScore >= 300 {
		a1.Unlocked = true
	}
	res = append(res, a1)

	a2 := domain.Achievement{
		Code:        "password-guru",
		Title:       "Парольный гуру",
		Description: "Создаёте действительно надёжные пароли.",
	}
	if st, ok := stats["passwords"]; ok && st.BestScore >= 250 {
		a2.Unlocked = true
	}
	res = append(res, a2)

	// Сетевой защитник: лучший результат по сети > 250
	a3 := domain.Achievement{
		Code:        "net-defender",
		Title:       "Сетевой защитник",
		Description: "Уверенно реагируете на сетевые инциденты.",
	}
	if st, ok := stats["network"]; ok && st.BestScore >= 250 {
		a3.Unlocked = true
	}
	res = append(res, a3)

	return res, nil
}
