package repository

import (
	"math/rand"
	"time"
)

type PhishingMailGenerator struct {
	rand *rand.Rand
}

func NewPhishingMailGenerator() *PhishingMailGenerator {
	return &PhishingMailGenerator{
		rand: rand.New(rand.NewSource(time.Now().UnixNano())),
	}
}

func (g *PhishingMailGenerator) GenerateMany(count int, minLevel int) []map[string]interface{} {
	templates := g.getTemplates()
	result := []map[string]interface{}{}

	for i := 0; i < count; i++ {
		idx := g.rand.Intn(len(templates))
		template := templates[idx]

		if template["level"].(int) >= minLevel {
			result = append(result, template)
		}
	}

	return result
}

func (g *PhishingMailGenerator) getTemplates() []map[string]interface{} {
	return []map[string]interface{}{
		{
			"from":        "security@sberbank-online.ru",
			"subject":     "СРОЧНО: Подтвердите операцию",
			"body":        "Обнаружена попытка перевода 45,000₽. Если это не вы, перейдите по ссылке: http://sberbank-check.tk/confirm",
			"channel":     "Email",
			"is_phishing": true,
			"level":       1,
			"red_flags":   []string{"Подозрительный домен .tk", "Давление (СРОЧНО)", "Поддельная ссылка"},
			"explanation": "Сбербанк никогда не использует домены .tk и не требует срочных действий по ссылке",
		},
		{
			"from":        "notifications@vk.com",
			"subject":     "Ваш аккаунт будет удалён через 24 часа",
			"body":        "Ваш аккаунт нарушил правила. Восстановите доступ: https://vk-restore.com/login",
			"channel":     "Email",
			"is_phishing": true,
			"level":       1,
			"red_flags":   []string{"Фейковый домен", "Угрозы удаления", "Неожиданное письмо"},
			"explanation": "VK использует домен vk.com, а не vk-restore.com. Это классический фишинг",
		},
		{
			"from":        "no-reply@gosuslugi.ru",
			"subject":     "Информация об обновлении сервиса",
			"body":        "Уважаемый пользователь! В связи с техническими работами мы обновили систему. Действия не требуются.",
			"channel":     "Email",
			"is_phishing": false,
			"level":       1,
			"red_flags":   []string{},
			"explanation": "Легитимное информационное письмо без подозрительных ссылок и запросов данных",
		},
		{
			"from":        "admin@company-portal.ru",
			"subject":     "Обновите пароль",
			"body":        "Ваш пароль от корпоративной почты истекает через 3 дня. Обновите: http://portal-update.com",
			"channel":     "Email",
			"is_phishing": true,
			"level":       2,
			"red_flags":   []string{"Несовпадение домена", "Требование смены пароля", "Внешняя ссылка"},
			"explanation": "Домен отправителя company-portal.ru, а ссылка ведёт на portal-update.com — подделка",
		},
		{
			"from":        "CEO@yourcompany.com",
			"subject":     "URGENT: Wire Transfer Needed",
			"body":        "I need you to process an urgent wire transfer for $50,000 to our new vendor. Details: account 12345...",
			"channel":     "Email",
			"is_phishing": true,
			"level":       3,
			"red_flags":   []string{"Срочность", "Необычный запрос от CEO", "Финансовая операция"},
			"explanation": "BEC-атака (Business Email Compromise). Проверьте адрес CEO и свяжитесь напрямую",
		},
		{
			"from":        "support@yandex.ru",
			"subject":     "Проверка безопасности аккаунта",
			"body":        "Мы заметили подозрительную активность. Пройдите проверку: https://ya.ru/verify?token=abc123",
			"channel":     "Email",
			"is_phishing": false,
			"level":       2,
			"red_flags":   []string{},
			"explanation": "Yandex действительно отправляет такие письма с легитимными ссылками ya.ru",
		},
		{
			"from":        "8-800-555-35-35",
			"subject":     "Ваш заказ №45123 отменён",
			"body":        "Товар недоступен. Возврат средств по ссылке: http://ozon-refund.online/claim",
			"channel":     "SMS",
			"is_phishing": true,
			"level":       2,
			"red_flags":   []string{"Поддельный домен", "Неожиданная отмена", "Запрос перейти по ссылке"},
			"explanation": "Ozon использует домен ozon.ru, а не ozon-refund.online. Фишинг через SMS (smishing)",
		},
		{
			"from":        "delivery@cdek.ru",
			"subject":     "Посылка ожидает получения",
			"body":        "Ваша посылка прибыла в пункт выдачи. Трек-номер: 1234567890. Срок хранения: 5 дней.",
			"channel":     "SMS",
			"is_phishing": false,
			"level":       1,
			"red_flags":   []string{},
			"explanation": "Стандартное уведомление от СДЭК без подозрительных элементов",
		},
		{
			"from":        "HR@company.com",
			"subject":     "Обязательное обучение по кибербезопасности",
			"body":        "Пройдите тест до конца недели: https://training.company.com/cyber-security-quiz",
			"channel":     "Email",
			"is_phishing": false,
			"level":       2,
			"red_flags":   []string{},
			"explanation": "Легитимное письмо от HR с ссылкой на внутренний корпоративный портал",
		},
		{
			"from":        "noreply@apple.com",
			"subject":     "Your Apple ID has been locked",
			"body":        "Unusual activity detected. Unlock: http://apple-id-unlock.net/restore",
			"channel":     "Email",
			"is_phishing": true,
			"level":       2,
			"red_flags":   []string{"Фейковый домен apple-id-unlock.net", "Угроза блокировки", "Требование действия"},
			"explanation": "Apple использует только apple.com. Это фишинг для кражи Apple ID",
		},
	}
}
