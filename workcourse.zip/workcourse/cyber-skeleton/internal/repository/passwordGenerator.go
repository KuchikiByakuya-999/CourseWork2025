package repository

import (
	"fmt"
	"math/rand"
	"time"
)

// PasswordChallengeGenerator создаёт огромный объём задач по паролям
type PasswordChallengeGenerator struct {
	rand *rand.Rand
}

type PasswordChallenge struct {
	Password   string
	Hint       string
	Strength   int // 1-5
	IsWeak     bool
	Category   string // bruteforce, dictionary, pattern, leak
	Difficulty int    // 1-3
}

func NewPasswordChallengeGenerator() *PasswordChallengeGenerator {
	return &PasswordChallengeGenerator{
		rand: rand.New(rand.NewSource(time.Now().UnixNano())),
	}
}

// Слабые пароли (легко перебираются)
var weakPasswords = []struct {
	pass   string
	hint   string
	reason string
}{
	{"123456", "Цифры от 1 до 6", "Очень частый пароль, легко перебирается"},
	{"password", "Слово 'password'", "Самый очевидный пароль в мире"},
	{"qwerty", "Верхний ряд клавиш слева", "Распространённый шаблон"},
	{"abc123", "Алфавит и цифры", "Предсказуемый паттерн"},
	{"admin", "Пользователь 'admin'", "Часто используется как стандартный пароль"},
	{"letmein", "Английское 'дай войти'", "Слишком часто встречается в базах"},
	{"welcome", "Слово 'добро пожаловать'", "Стандартный пароль на многих сервисах"},
	{"monkey", "Животное", "Из списка 100 худших паролей"},
	{"dragon", "Мифическое существо", "Популярное слово в паролях"},
	{"master", "Главный, хозяин", "Часто используется в компаниях"},
	{"pass", "Сокращение password", "Слишком короткий и простой"},
	{"12345", "Цифры 1-5", "Минимум попыток перебора"},
}

// Сильные пароли (сложные)
var strongPasswords = []struct {
	pass   string
	hint   string
	reason string
}{
	{"Tr0piC@lSunset#2024", "Тропическое слово + дата + спецсимволы", "Длина, разнообразие символов, спецсимволы"},
	{"xK9m$Lp&Qw2vB7nF", "Случайные символы из букв, цифр и спецсимволов", "Криптографический паттерн"},
	{"EarthquakePurple42!", "Два слова + число + символ", "Комбинация слов с цифрой и спецсимволом"},
	{"#Azure9BlueMoonlight", "Спецсимвол + цвет + слова", "Начинается со спецсимвола, хорошая смесь"},
	{"Whisper$Echo&Sound123", "Слова + спецсимволы + цифры", "Длина 20+ символов с разнообразием"},
	{"M0untain_Forest&River7", "Слова с подчёркиванием, амперсанд и цифра", "Хорошая комбинация разных элементов"},
	{"TimeShift*Velocity#99", "Два слова + операторы + двузначное число", "Все типы символов представлены"},
	{"B4ckup+Recovery@2025!", "Слово + число вместо букв + спецсимволы + дата", "Длина 19, разнообразие"},
	{"D1gital_Security$Force", "Буква + число + подчёркивание + спецсимвол", "Сложный для перебора"},
	{"Phoenix&Dragons!Rise99", "Два слова + спецсимволы + цифры", "Более 18 символов"},
}

// Категории и сценарии
type PasswordScenario struct {
	category    string
	description string
	difficulty  int
}

var scenarios = []PasswordScenario{
	{"bruteforce", "Пароль можно перебрать простым переебором (скорость: 10^6 комбинаций/сек)", 1},
	{"dictionary", "Пароль есть в словаре или список топ-1000 паролей", 1},
	{"pattern", "Пароль следует предсказуемому шаблону (123456, qwerty, дата рождения)", 2},
	{"leak", "Пароль найден в базе утечки данных - нужно его изменить", 2},
	{"policy", "Пароль не соответствует политике безопасности компании", 2},
	{"recovery", "Пароль скомпрометирован, нужно восстановить доступ с 2FA", 3},
	{"compromise", "Аккаунт был взломан, нужно установить более сильный пароль", 3},
}

// GenerateChallenge создаёт случайное задание
func (g *PasswordChallengeGenerator) GenerateChallenge(difficulty int) PasswordChallenge {
	if difficulty < 1 || difficulty > 3 {
		difficulty = 1 + g.rand.Intn(3)
	}

	// Выбираем сценарий подходящей сложности
	var validScenarios []PasswordScenario
	for _, s := range scenarios {
		if s.difficulty <= difficulty {
			validScenarios = append(validScenarios, s)
		}
	}

	scenario := validScenarios[g.rand.Intn(len(validScenarios))]
	isWeak := g.rand.Intn(100) < 60 // 60% слабые, 40% сильные

	var pwd, hint string
	var strength int

	if isWeak {
		weak := weakPasswords[g.rand.Intn(len(weakPasswords))]
		pwd = weak.pass
		hint = weak.hint
		strength = 1 + g.rand.Intn(2) // 1-2
	} else {
		strong := strongPasswords[g.rand.Intn(len(strongPasswords))]
		pwd = strong.pass
		hint = strong.hint
		strength = 3 + g.rand.Intn(2) // 3-4
	}

	// Если высокая сложность - усиливаем
	if difficulty == 3 && strength < 4 {
		strength = 4 + g.rand.Intn(2) // 4-5
	}

	return PasswordChallenge{
		Password:   pwd,
		Hint:       fmt.Sprintf("%s [Сценарий: %s]", hint, scenario.description),
		Strength:   strength,
		IsWeak:     isWeak,
		Category:   scenario.category,
		Difficulty: difficulty,
	}
}

// GenerateMany создаёт множество задач
func (g *PasswordChallengeGenerator) GenerateMany(count int) []PasswordChallenge {
	result := make([]PasswordChallenge, count)
	for i := 0; i < count; i++ {
		// Варьируем сложность
		diff := (i / (count / 3)) + 1
		if diff > 3 {
			diff = 3
		}
		result[i] = g.GenerateChallenge(diff)
	}
	return result
}

// GetStatistics возвращает статистику для информационного экрана
func (g *PasswordChallengeGenerator) GetStatistics() map[string]interface{} {
	return map[string]interface{}{
		"total_weak_patterns":   len(weakPasswords),
		"total_strong_patterns": len(strongPasswords),
		"categories": map[string]string{
			"bruteforce": "Перебор: очень короткие или очевидные пароли",
			"dictionary": "Словарь: часто встречаемые слова и комбинации",
			"pattern":    "Шаблоны: предсказуемые последовательности",
			"leak":       "Утечки: пароли из скомпрометированных баз данных",
			"policy":     "Политика: пароли не соответствуют требованиям компании",
			"recovery":   "Восстановление: процесс после компрометации",
			"compromise": "Компрометация: атака с использованием фишинга или MITM",
		},
		"tips": []string{
			"Используйте минимум 12 символов",
			"Включайте прописные, строчные буквы, цифры и спецсимволы",
			"Не используйте информацию о себе (ФИО, дата рождения, город)",
			"Не повторяйте старые пароли",
			"Используйте уникальные пароли для каждого сервиса",
			"Используйте менеджер паролей",
			"Двухфакторная аутентификация (2FA) - ваш друг",
			"Проверяйте пароли на haveibeenpwned.com",
		},
	}
}
