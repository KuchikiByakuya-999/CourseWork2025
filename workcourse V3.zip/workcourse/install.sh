#!/bin/bash

APP_NAME="cyberTrain"
INSTALL_DIR="~/workcourse/"
DESKTOP_FILE="/usr/share/applications/cyberTrain.desktop"
ICON_PATH="$INSTALL_DIR/icon.png"

echo "🚀 Установка Cyber Skeleton..."

# Проверка прав sudo
if [ "$EUID" -ne 0 ]; then 
    echo "❌ Запустите с sudo: sudo ./install.sh"
    exit 1
fi

# Создаём директорию
mkdir -p "$INSTALL_DIR"

# Копируем файлы
echo "📦 Копирование файлов..."
cp "$APP_NAME" "$INSTALL_DIR/"
chmod +x "$INSTALL_DIR/$APP_NAME"

# Копируем иконку (если есть)
if [ -f "icon.png" ]; then
    cp icon.png "$INSTALL_DIR/"
fi

# Создаём .desktop файл
echo "📝 Создание ярлыка..."
cat > "$DESKTOP_FILE" << EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=Cyber Skeleton
Comment=Тренажёр по кибербезопасности
Exec=$INSTALL_DIR/$APP_NAME
Icon=$ICON_PATH
Terminal=false
Categories=Education;Game;
EOF

chmod +x "$DESKTOP_FILE"

# Обновляем кэш приложений
update-desktop-database /usr/share/applications/ 2>/dev/null

echo "✅ Установка завершена!"
echo "🎮 Запустите через меню приложений или командой: $INSTALL_DIR/$APP_NAME"
