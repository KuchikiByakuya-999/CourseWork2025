package repository

import (
	"context"
	"cyber-skeleton/internal/domain"
)

type Repository interface {
	Close() error
	CreateUser(ctx context.Context, username, email, passwordHash string) (*domain.User, error)
	GetUserByUsername(ctx context.Context, username string) (*domain.User, error)
	GetUserByLoginOrEmail(ctx context.Context, loginOrEmail string) (*domain.User, error)
	SaveGameResult(ctx context.Context, res *domain.GameResult) error
	GetLastResults(ctx context.Context, userID int64, limit int) ([]domain.GameResult, error)
	GetXP(ctx context.Context, userID int64) (int, error)
	GetModuleStats(ctx context.Context, userID int64) (map[string]domain.ModuleStat, error)
}

type PasswordRepository interface {
	GetRandomChallenges(ctx context.Context, count int) ([]domain.PasswordChallenge, error)
}

type NetworkRepository interface {
	GetRandomIncidents(ctx context.Context, count int) ([]domain.NetworkIncident, error)
}
