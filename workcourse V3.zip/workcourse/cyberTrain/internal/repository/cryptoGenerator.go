package repository

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"cyber-skeleton/internal/domain"
	"encoding/base64"
	"encoding/hex"
	"io"
	mathrand "math/rand"
	"strings"
	"time"
)

type CryptoGenerator struct {
	rand *mathrand.Rand
}

func NewCryptoGenerator() *CryptoGenerator {
	return &CryptoGenerator{
		rand: mathrand.New(mathrand.NewSource(time.Now().UnixNano())),
	}
}

func (g *CryptoGenerator) GenerateMany(count int, difficulty int) []domain.CryptoChallenge {
	challenges := []domain.CryptoChallenge{}

	// Разные типы шифров в зависимости от сложности
	types := []string{}

	if difficulty <= 1 {
		types = []string{"caesar", "base64", "reverse"}
	} else if difficulty == 2 {
		types = []string{"caesar", "vigenere", "xor", "base64", "hex"}
	} else {
		types = []string{"vigenere", "xor", "aes", "substitution"}
	}

	messages := []string{
		"ATTACK AT DAWN",
		"THE EAGLE HAS LANDED",
		"SECRET MESSAGE",
		"MISSION ACCOMPLISHED",
		"ENCRYPTION IS FUN",
		"CYBER SECURITY ROCKS",
		"KEEP YOUR DATA SAFE",
		"PASSWORD IS HUNTER2",
		"BEWARE THE PHISHING",
		"TWO FACTOR AUTH SAVES LIVES",
	}

	for i := 0; i < count; i++ {
		cipherType := types[g.rand.Intn(len(types))]
		message := messages[g.rand.Intn(len(messages))]

		var challenge domain.CryptoChallenge

		switch cipherType {
		case "caesar":
			challenge = g.generateCaesar(message, difficulty)
		case "vigenere":
			challenge = g.generateVigenere(message, difficulty)
		case "xor":
			challenge = g.generateXOR(message, difficulty)
		case "base64":
			challenge = g.generateBase64(message, difficulty)
		case "hex":
			challenge = g.generateHex(message, difficulty)
		case "reverse":
			challenge = g.generateReverse(message, difficulty)
		case "substitution":
			challenge = g.generateSubstitution(message, difficulty)
		case "aes":
			challenge = g.generateAES(message, difficulty)
		}

		challenge.ID = int64(i + 1)
		challenge.Difficulty = difficulty
		challenges = append(challenges, challenge)
	}

	return challenges
}

// Caesar Cipher
func (g *CryptoGenerator) generateCaesar(plaintext string, difficulty int) domain.CryptoChallenge {
	shift := g.rand.Intn(25) + 1
	ciphertext := caesarEncrypt(plaintext, shift)

	hint := "Каждая буква сдвинута на одинаковое количество позиций в алфавите"
	if difficulty <= 1 {
		hint += ". Попробуйте сдвиги от 1 до 25"
	}

	return domain.CryptoChallenge{
		CipherType: "caesar",
		Ciphertext: ciphertext,
		Plaintext:  plaintext,
		Hint:       hint,
		Key:        string(rune('0' + shift)),
		Difficulty: difficulty,
	}
}

func caesarEncrypt(text string, shift int) string {
	result := ""
	for _, char := range text {
		if char >= 'A' && char <= 'Z' {
			result += string((char-'A'+rune(shift))%26 + 'A')
		} else if char >= 'a' && char <= 'z' {
			result += string((char-'a'+rune(shift))%26 + 'a')
		} else {
			result += string(char)
		}
	}
	return result
}

// Vigenere Cipher
func (g *CryptoGenerator) generateVigenere(plaintext string, difficulty int) domain.CryptoChallenge {
	keys := []string{"KEY", "SECRET", "CIPHER", "CRYPTO", "LOCK"}
	key := keys[g.rand.Intn(len(keys))]

	ciphertext := vigenereEncrypt(plaintext, key)

	hint := "Это шифр Виженера - используется повторяющийся ключ"
	if difficulty <= 2 {
		hint += ". Ключ длиной " + string(rune('0'+len(key))) + " букв"
	}

	return domain.CryptoChallenge{
		CipherType: "vigenere",
		Ciphertext: ciphertext,
		Plaintext:  plaintext,
		Hint:       hint,
		Key:        key,
		Difficulty: difficulty,
	}
}

func vigenereEncrypt(text, key string) string {
	result := ""
	keyIndex := 0
	key = strings.ToUpper(key)

	for _, char := range text {
		if char >= 'A' && char <= 'Z' {
			shift := int(key[keyIndex%len(key)] - 'A')
			result += string((char-'A'+rune(shift))%26 + 'A')
			keyIndex++
		} else if char >= 'a' && char <= 'z' {
			shift := int(key[keyIndex%len(key)] - 'A')
			result += string((char-'a'+rune(shift))%26 + 'a')
			keyIndex++
		} else {
			result += string(char)
		}
	}
	return result
}

// XOR Cipher
func (g *CryptoGenerator) generateXOR(plaintext string, difficulty int) domain.CryptoChallenge {
	key := byte(g.rand.Intn(255) + 1)
	ciphertext := xorEncrypt([]byte(plaintext), key)

	hint := "XOR шифрование с однобайтовым ключом. Попробуйте перебрать значения 0-255"

	return domain.CryptoChallenge{
		CipherType: "xor",
		Ciphertext: hex.EncodeToString(ciphertext),
		Plaintext:  plaintext,
		Hint:       hint,
		Key:        string(key),
		Difficulty: difficulty,
	}
}

func xorEncrypt(data []byte, key byte) []byte {
	result := make([]byte, len(data))
	for i := range data {
		result[i] = data[i] ^ key
	}
	return result
}

// Base64
func (g *CryptoGenerator) generateBase64(plaintext string, difficulty int) domain.CryptoChallenge {
	encoded := base64.StdEncoding.EncodeToString([]byte(plaintext))

	hint := "Это Base64 кодирование - не шифрование, а способ представления данных"

	return domain.CryptoChallenge{
		CipherType: "base64",
		Ciphertext: encoded,
		Plaintext:  plaintext,
		Hint:       hint,
		Key:        "",
		Difficulty: difficulty,
	}
}

// Hex
func (g *CryptoGenerator) generateHex(plaintext string, difficulty int) domain.CryptoChallenge {
	encoded := hex.EncodeToString([]byte(plaintext))

	hint := "Шестнадцатеричная кодировка. Каждые 2 символа = 1 байт"

	return domain.CryptoChallenge{
		CipherType: "hex",
		Ciphertext: encoded,
		Plaintext:  plaintext,
		Hint:       hint,
		Key:        "",
		Difficulty: difficulty,
	}
}

// Reverse
func (g *CryptoGenerator) generateReverse(plaintext string, difficulty int) domain.CryptoChallenge {
	runes := []rune(plaintext)
	for i, j := 0, len(runes)-1; i < j; i, j = i+1, j-1 {
		runes[i], runes[j] = runes[j], runes[i]
	}

	hint := "Самый простой шифр - просто читайте задом наперёд!"

	return domain.CryptoChallenge{
		CipherType: "reverse",
		Ciphertext: string(runes),
		Plaintext:  plaintext,
		Hint:       hint,
		Key:        "",
		Difficulty: difficulty,
	}
}

// Substitution Cipher
func (g *CryptoGenerator) generateSubstitution(plaintext string, difficulty int) domain.CryptoChallenge {
	alphabet := "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
	shuffled := shuffleString(alphabet, g.rand)

	mapping := make(map[rune]rune)
	for i, char := range alphabet {
		mapping[char] = rune(shuffled[i])
	}

	ciphertext := ""
	for _, char := range plaintext {
		if char >= 'A' && char <= 'Z' {
			ciphertext += string(mapping[char])
		} else if char >= 'a' && char <= 'z' {
			ciphertext += string(mapping[rune(char-32)] + 32)
		} else {
			ciphertext += string(char)
		}
	}

	hint := "Моноалфавитная подстановка. Частотный анализ поможет!"

	return domain.CryptoChallenge{
		CipherType: "substitution",
		Ciphertext: ciphertext,
		Plaintext:  plaintext,
		Hint:       hint,
		Key:        shuffled,
		Difficulty: difficulty,
	}
}

// AES Encryption (simplified)
func (g *CryptoGenerator) generateAES(plaintext string, difficulty int) domain.CryptoChallenge {
	key := make([]byte, 32) // AES-256
	rand.Read(key)

	block, _ := aes.NewCipher(key)
	gcm, _ := cipher.NewGCM(block)

	nonce := make([]byte, gcm.NonceSize())
	io.ReadFull(rand.Reader, nonce)

	ciphertext := gcm.Seal(nonce, nonce, []byte(plaintext), nil)

	hint := "AES-256-GCM шифрование. Современный стандарт, невзламываем брутфорсом"

	return domain.CryptoChallenge{
		CipherType: "aes",
		Ciphertext: base64.StdEncoding.EncodeToString(ciphertext),
		Plaintext:  plaintext,
		Hint:       hint,
		Key:        base64.StdEncoding.EncodeToString(key),
		Difficulty: difficulty,
	}
}

func shuffleString(s string, r *mathrand.Rand) string {
	runes := []rune(s)
	r.Shuffle(len(runes), func(i, j int) {
		runes[i], runes[j] = runes[j], runes[i]
	})
	return string(runes)
}
