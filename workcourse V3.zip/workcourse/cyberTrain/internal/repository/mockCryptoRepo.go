package repository

import (
	"context"
	"cyber-skeleton/internal/domain"
)

type MockCryptoRepo struct{}

func NewMockCryptoRepo() *MockCryptoRepo {
	return &MockCryptoRepo{}
}

func (r *MockCryptoRepo) GetRandomChallenges(ctx context.Context, count int, difficulty int) ([]domain.CryptoChallenge, error) {
	gen := NewCryptoGenerator()
	return gen.GenerateMany(count, difficulty), nil
}

func (r *MockCryptoRepo) SaveResult(ctx context.Context, userID int64, challengeID int64, correct bool, attempts int, timeSpent int64) error {
	return nil
}
