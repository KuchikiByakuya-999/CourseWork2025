package repository

import (
	"context"
	"cyber-skeleton/internal/domain"
	"database/sql"

	"github.com/lib/pq"
)

type networkRepository struct{ db *sql.DB }

func NewNetworkRepository(db *sql.DB) NetworkRepository {
	return &networkRepository{db: db}
}

func (r *networkRepository) GetRandomIncidents(ctx context.Context, count int) ([]domain.NetworkIncident, error) {
	rows, err := r.db.QueryContext(ctx,
		`SELECT id, type, logs, action FROM network_incidents
         ORDER BY RANDOM() LIMIT $1`, count)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var res []domain.NetworkIncident
	for rows.Next() {
		var inc domain.NetworkIncident
		if err := rows.Scan(&inc.ID, &inc.Type, pq.Array(&inc.Logs), &inc.Action); err != nil {
			return nil, err
		}
		res = append(res, inc)
	}
	return res, rows.Err()
}
