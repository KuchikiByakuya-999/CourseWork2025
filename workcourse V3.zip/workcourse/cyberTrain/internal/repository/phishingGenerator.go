package repository

import (
	"math/rand"
	"time"
)

type PhishingMailGenerator struct {
	rand *rand.Rand
}

func NewPhishingMailGenerator() *PhishingMailGenerator {
	return &PhishingMailGenerator{
		rand: rand.New(rand.NewSource(time.Now().UnixNano())),
	}
}

// GenerateMany генерирует ровно 15 разнообразных писем
func (g *PhishingMailGenerator) GenerateMany(count int, phishingRatio int) []map[string]interface{} {
	if count <= 0 {
		count = 15
	}

	// Рассчитываем количество фишинговых писем (60-70%)
	phishCount := (count * 65) / 100
	legitimateCount := count - phishCount

	mails := []map[string]interface{}{}

	// Генерируем фишинговые письма
	for i := 0; i < phishCount; i++ {
		mails = append(mails, g.generatePhishingMail())
	}

	// Генерируем легитимные письма
	for i := 0; i < legitimateCount; i++ {
		mails = append(mails, g.generateLegitimateMail())
	}

	// Перемешиваем
	g.rand.Shuffle(len(mails), func(i, j int) {
		mails[i], mails[j] = mails[j], mails[i]
	})

	return mails
}

func (g *PhishingMailGenerator) generatePhishingMail() map[string]interface{} {
	templates := []struct {
		from        string
		subject     string
		body        string
		channel     string
		level       int
		redFlags    []string
		explanation string
	}{
		// ЛЁГКИЕ (очевидные)
		{
			from:    "admin@paypa1-security.tk",
			subject: "СРОЧНО!!! Ваш аккаунт заблокирован!!!",
			body: `Уважаемый пользователь!

Ваш аккаунт PayPal был временно ЗАБЛОКИРОВАН из-за подозрительной активности!!!

Для НЕМЕДЛЕННОЙ разблокировки перейдите по ссылке:
http://paypal-verify-account.tk/restore?id=12345

У вас есть 24 ЧАСА до ПОЛНОЙ БЛОКИРОВКИ!!!

С уважением,
Служба безопасности PayPaI`,
			channel:     "Email",
			level:       0,
			redFlags:    []string{"Поддельный домен paypa1-security.tk", "Множество восклицательных знаков", "Давление по времени", "Опечатка PayPaI вместо PayPal"},
			explanation: "Классический фишинг: поддельный домен (.tk - бесплатная зона), давление, угрозы, опечатки.",
		},
		{
			from:    "noreply@amaz0n-prize.com",
			subject: "Поздравляем! Вы выиграли iPhone 15 Pro Max!",
			body: `🎉 НЕВЕРОЯТНАЯ НОВОСТЬ! 🎉

Вы стали победителем розыгрыша от Amazon!

ВАША НАГРАДА: iPhone 15 Pro Max 1TB + AirPods Pro

Для получения приза заполните форму в течение 3 ЧАСОВ:
http://amaz0n-winner.ru/claim/prize

ВАЖНО: После истечения времени приз перейдёт другому участнику!`,
			channel:     "Email",
			level:       0,
			redFlags:    []string{"Домен amaz0n вместо amazon", "Слишком хорошо, чтобы быть правдой", "Давление по времени", "Запрос личных данных"},
			explanation: "Фишинг на жадности: поддельный домен с цифрой 0, нереалистичный приз, срочность.",
		},
		{
			from:    "security@goog1e.com",
			subject: "Новый вход в аккаунт Google",
			body: `Обнаружен вход в ваш аккаунт Google с неизвестного устройства:

Устройство: iPhone 13
Локация: Нигерия, Лагос
Время: 02:37 AM

Если это были НЕ ВЫ, немедленно подтвердите личность:
http://accounts-google-verify.ru/security

Вложение: security_report.exe`,
			channel:     "Email",
			level:       0,
			redFlags:    []string{"Домен goog1e.com (с единицей)", "Подозрительная локация", "Вложение .exe файл", "Поддельный URL"},
			explanation: "Фишинг под Google: домен с единицей вместо l, опасное вложение .exe, поддельная ссылка.",
		},

		// СРЕДНИЕ (требуют внимательности)
		{
			from:    "hr@company-portal.org",
			subject: "Обновление корпоративной политики паролей",
			body: `Здравствуйте!

В связи с новыми требованиями безопасности, все сотрудники должны 
обновить свои пароли в течение 48 часов.

Перейдите на корпоративный портал и обновите пароль:
https://company-portal.org/password-update

При возникновении вопросов обращайтесь в IT-отдел.

С уважением,
Отдел кадров`,
			channel:     "Email",
			level:       1,
			redFlags:    []string{"Домен .org вместо корпоративного", "Запрос смены пароля через ссылку", "Ограничение по времени"},
			explanation: "Внутренний фишинг (spear phishing): письмо выглядит легитимным, но домен не корпоративный, просят сменить пароль по ссылке.",
		},
		{
			from:    "billing@netflix-support.net",
			subject: "Проблема с оплатой подписки",
			body: `Уважаемый подписчик!

Мы не смогли списать оплату за ваш премиум аккаунт Netflix.

Ваша подписка будет отменена через 3 дня, если вы не обновите 
платёжную информацию.

Обновить данные карты:
https://netflix.com.account-update.ru

Служба поддержки Netflix`,
			channel:     "Email",
			level:       1,
			redFlags:    []string{"Домен netflix-support.net вместо netflix.com", "Поддельный поддомен в URL", "Запрос данных карты"},
			explanation: "Умеренный фишинг: ссылка выглядит как netflix.com, но реальный домен account-update.ru. Проверяйте полный URL!",
		},
		{
			from:    "no-reply@microsoft.com",
			subject: "Подозрительная активность в OneDrive",
			body: `Здравствуйте,

В вашем OneDrive обнаружена подозрительная активность:
- 15 файлов загружено из незнакомого IP
- Попытка доступа к папке "Документы"

Мы временно ограничили доступ к вашему аккаунту.

Восстановить доступ: 
https://onedrive.live.com.verify.account-security.tk

Microsoft Security Team`,
			channel:     "Email",
			level:       1,
			redFlags:    []string{"Домен заканчивается на .tk", "Длинный поддельный URL", "Запрос восстановления доступа"},
			explanation: "Хитрый фишинг: письмо от легитимного адреса (возможно поддельного), но ссылка ведёт на .tk домен.",
		},
		{
			from:    "ceo@yourcompany.com",
			subject: "Re: Срочный платёж поставщику",
			body: `Привет!

Мне нужно срочно оплатить счёт от нового поставщика, но у меня 
сейчас совещание до вечера.

Можешь перевести 150 000 руб на счёт:
40817810099910004312 (Сбербанк, ООО "ТехПоставка")

Счёт во вложении: invoice_2024.pdf.exe

Спасибо!
Александр Петров, CEO`,
			channel:     "Email",
			level:       1,
			redFlags:    []string{"Неформальный тон от CEO", "Срочный запрос денег", "Вложение .pdf.exe (двойное расширение)", "Нет стандартной процедуры"},
			explanation: "BEC (Business Email Compromise): письмо якобы от CEO с просьбой перевести деньги. Вложение .exe замаскировано под PDF.",
		},

		// СЛОЖНЫЕ (очень убедительные)
		{
			from:    "security-alert@apple.com",
			subject: "Ваш Apple ID был использован для входа на новом устройстве",
			body: `Здравствуйте!

Ваш Apple ID был использован для входа на iPhone 14 Pro.

Дата и время: 18 декабря 2024 г., 23:47
Местоположение: Казань, Россия
IP-адрес: 195.82.146.228

Если это были вы, никаких действий не требуется.

Если это были не вы, защитите свой аккаунт:
appleid.apple.com

С уважением,
Служба поддержки Apple`,
			channel:     "Email",
			level:       2,
			redFlags:    []string{"Ссылка выглядит легитимно, но может быть гиперссылкой на другой сайт", "Реальные детали (IP, локация) могут быть поддельными"},
			explanation: "Сложный фишинг: письмо выглядит очень убедительно, но ссылка может вести не на apple.com. Всегда вводите адрес вручную!",
		},
		{
			from:    "notifications@linkedin.com",
			subject: "Приглашение на собеседование от Google",
			body: `Здравствуйте!

Рекрутер из Google отправил вам приглашение на собеседование 
на позицию Senior Software Engineer.

Для подтверждения участия и получения деталей, пройдите 
верификацию на платформе LinkedIn Recruitment:

https://linkedin.com/recruiter/verify?token=a8f9d2e1

Срок подтверждения: 48 часов.

LinkedIn Talent Solutions`,
			channel:     "Email",
			level:       2,
			redFlags:    []string{"Слишком хорошая возможность", "Запрос верификации через ссылку", "Ограничение по времени"},
			explanation: "Продвинутый фишинг: используется желание получить работу в Google. Ссылка может вести на поддельную страницу LinkedIn.",
		},
		{
			from:    "support@github.com",
			subject: "Critical Security Alert: Unauthorized Access Detected",
			body: `Hi there,

We detected unusual API activity in your GitHub account:

- Repository: yourproject/backend
- Action: SSH key added
- IP: 185.220.101.52 (Tor Exit Node)
- Time: 2024-12-18 22:15 UTC

We've temporarily disabled your API tokens.

Review activity and restore access:
https://github.com/settings/security/review-session

GitHub Security Team
github.com/security`,
			channel:     "Email",
			level:       2,
			redFlags:    []string{"Технические детали могут быть поддельными", "Ссылка может быть поддельной гиперссылкой", "Запрос восстановления доступа"},
			explanation: "Продвинутый фишинг для разработчиков: использует терминологию GitHub, упоминание Tor создаёт панику. Проверяйте URL!",
		},
		{
			from:    "verification@telegram.org",
			subject: "Telegram: Код подтверждения двухфакторной аутентификации",
			body: `Код подтверждения для входа в Telegram:

94728

Если вы не запрашивали этот код, ваш аккаунт может быть взломан.

Срочно проверьте активные сессии:
https://telegram.org/account/sessions

Никому не сообщайте этот код!

Telegram Security`,
			channel:     "SMS/Email",
			level:       2,
			redFlags:    []string{"Паника о взломе", "Ссылка может быть поддельной", "Код может быть фейковым для паники"},
			explanation: "Хитрый фишинг: создаёт панику получением 'кода', хотя вы ничего не запрашивали. Цель - заставить перейти по ссылке.",
		},

		// ДОПОЛНИТЕЛЬНЫЕ ФИШИНГОВЫЕ СЦЕНАРИИ
		{
			from:    "admin@tax-refund-russia.ru",
			subject: "Возврат налогов за 2024 год: 47,350 руб",
			body: `Уважаемый налогоплательщик!

Федеральная налоговая служба рассчитала вам возврат налога 
за 2024 год в размере 47,350 рублей.

Для получения возврата на банковскую карту заполните заявление:
https://nalog.gov.ru.refund.claim-24.tk

Срок подачи заявления: до 31 декабря 2024.

ФНС России`,
			channel:     "Email",
			level:       1,
			redFlags:    []string{"Домен заканчивается на .tk", "ФНС не рассылает такие письма", "Запрос банковских данных"},
			explanation: "Фишинг на жадности: обещание возврата налогов, поддельный домен, ФНС так не работает.",
		},
		{
			from:    "courier@russian-post.ru",
			subject: "Посылка №RU184729364CN ожидает получения",
			body: `Здравствуйте!

Ваша посылка прибыла в сортировочный центр Москвы.

Трек-номер: RU184729364CN
Отправитель: AliExpress
Вес: 2.4 кг

Оплатите таможенную пошлину 450 руб для доставки:
https://track.russianpost.ru/customs-pay?track=RU184729364CN

Вложение: customs_invoice.pdf.scr

Почта России`,
			channel:     "Email",
			level:       1,
			redFlags:    []string{"Запрос оплаты через ссылку", "Вложение .scr (вредоносный скрипт)", "Почта России так не работает"},
			explanation: "Фишинг на ожиданиях: использует популярность покупок из Китая, вложение .scr - вредонос.",
		},
		{
			from:    "hr-recruitment@yandex.ru",
			subject: "Результаты собеседования в Яндекс",
			body: `Добрый день!

Поздравляем! Вы успешно прошли финальное собеседование 
на позицию Middle Python Developer в Яндексе.

Для оформления трудового договора заполните анкету:
https://career.yandex.ru/onboarding/form?id=py2024

Приложите:
- Скан паспорта
- СНИЛС
- ИНН

HR-отдел Яндекса`,
			channel:     "Email",
			level:       2,
			redFlags:    []string{"Запрос скана паспорта через интернет", "Яндекс так не работает", "Нет упоминания имени кандидата"},
			explanation: "Кража личных данных: используют радость от приёма на работу, запрашивают документы для кражи личности.",
		},
		{
			from:    "security@vk.com",
			subject: "Попытка взлома вашей страницы ВКонтакте",
			body: `Внимание!

Обнаружено 5 неудачных попыток входа в ваш аккаунт ВКонтакте:

IP: 45.142.212.61 (Украина)
Время: сегодня, 14:23

Мы временно заблокировали подозрительные действия.

Подтвердите, что это ваш аккаунт:
https://vk.com/restore_access

Вложение: security_report.zip

Служба безопасности ВК`,
			channel:     "Email",
			level:       1,
			redFlags:    []string{"Паника о взломе", "Вложение .zip может содержать вредонос", "ВК использует уведомления в приложении"},
			explanation: "Паника и страх: создают страх взлома, вложение содержит вредонос, настоящий ВК не шлёт такие письма.",
		},
		{
			from:    "billing@steam-support.com",
			subject: "Возврат средств за игру Cyberpunk 2077",
			body: `Здравствуйте!

Ваш запрос на возврат средств за игру "Cyberpunk 2077" одобрен.

Сумма возврата: 1,999 руб
Способ возврата: Steam Wallet

Для зачисления средств подтвердите данные аккаунта:
https://store.steampowered.com/refund/verify

Важно: Деньги будут зачислены в течение 3 рабочих дней.

Steam Support`,
			channel:     "Email",
			level:       1,
			redFlags:    []string{"Домен steam-support.com вместо steampowered.com", "Запрос подтверждения данных", "Steam не шлёт такие письма"},
			explanation: "Фишинг на геймеров: поддельный домен, Steam обрабатывает возвраты через платформу, а не по email.",
		},
	}

	// Выбираем случайный шаблон
	template := templates[g.rand.Intn(len(templates))]

	return map[string]interface{}{
		"from":        template.from,
		"subject":     template.subject,
		"body":        template.body,
		"channel":     template.channel,
		"is_phishing": true,
		"level":       template.level,
		"red_flags":   template.redFlags,
		"explanation": template.explanation,
	}
}

func (g *PhishingMailGenerator) generateLegitimateMail() map[string]interface{} {
	templates := []struct {
		from        string
		subject     string
		body        string
		channel     string
		explanation string
	}{
		{
			from:    "notifications@github.com",
			subject: "Pull request merged: feature/user-auth",
			body: `Hi there,

Your pull request "Add OAuth2 authentication" has been merged 
into main branch by @john-doe.

Repository: yourcompany/backend
Commits: 5 commits
Files changed: 12 files

View on GitHub:
github.com/yourcompany/backend/pull/184

GitHub`,
			channel:     "Email",
			explanation: "Легитимное уведомление от GitHub: реальное событие в репозитории, нет запросов данных, короткая ссылка.",
		},
		{
			from:    "no-reply@amazon.com",
			subject: "Ваш заказ отправлен",
			body: `Здравствуйте!

Ваш заказ #402-9834728-1736472 отправлен.

Товары:
- Беспроводная мышь Logitech MX Master 3

Ожидаемая дата доставки: 22 декабря 2024

Отследить посылку можно в личном кабинете Amazon.

Amazon.ru`,
			channel:     "Email",
			explanation: "Легитимное уведомление о заказе: конкретный номер заказа, нет ссылок, информация о товаре.",
		},
		{
			from:    "noreply@spotify.com",
			subject: "Ваш персональный плейлист готов",
			body: `Привет!

Мы составили для вас персональный плейлист на основе 
ваших прослушиваний за неделю.

Discover Weekly: 30 треков

Откройте приложение Spotify, чтобы послушать.

Приятного прослушивания!
Spotify`,
			channel:     "Email",
			explanation: "Легитимное письмо от Spotify: стандартная функция сервиса, нет ссылок, предлагает открыть приложение.",
		},
		{
			from:    "calendar-notification@google.com",
			subject: "Напоминание: Встреча с командой через 1 час",
			body: `Напоминание о событии:

Встреча с командой по проекту
Когда: сегодня, 15:00 - 16:00
Где: Конференц-зал B, офис
Участники: вы + 5 человек

Google Calendar`,
			channel:     "Email",
			explanation: "Легитимное напоминание из Google Calendar: обычное уведомление, которое вы сами настроили.",
		},
		{
			from:    "info@linkedin.com",
			subject: "Иван Петров прокомментировал вашу публикацию",
			body: `Привет!

Иван Петров (Senior Developer в Яндексе) прокомментировал 
вашу публикацию "Лучшие практики Python".

"Отличная статья! Особенно понравился раздел про async/await"

Ответить на комментарий можно в приложении LinkedIn.

LinkedIn`,
			channel:     "Email",
			explanation: "Легитимное уведомление LinkedIn: стандартное социальное взаимодействие, нет подозрительных ссылок.",
		},
		{
			from:    "support@tinkoff.ru",
			subject: "Выписка по счёту за декабрь 2024",
			body: `Здравствуйте!

Ваша ежемесячная выписка по дебетовой карте готова.

Период: 01.12.2024 - 18.12.2024
Расходы: 45,230 руб
Поступления: 120,000 руб

Выписку можно скачать в мобильном приложении Тинькофф.

Тинькофф Банк`,
			channel:     "Email",
			explanation: "Легитимное письмо от банка: стандартная выписка, предлагает использовать приложение, а не ссылки.",
		},
	}

	template := templates[g.rand.Intn(len(templates))]

	return map[string]interface{}{
		"from":        template.from,
		"subject":     template.subject,
		"body":        template.body,
		"channel":     template.channel,
		"is_phishing": false,
		"level":       0,
		"red_flags":   []string{},
		"explanation": template.explanation,
	}
}
