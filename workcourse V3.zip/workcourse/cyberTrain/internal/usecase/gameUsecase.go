package usecase

import (
	"context"
	"cyber-skeleton/internal/domain"
	"cyber-skeleton/internal/repository"
	"fmt"
)

// ================= PHISHING =================

type PhishingUsecase struct {
	repo      repository.PhishingRepository
	generator *repository.PhishingMailGenerator
}

func NewPhishingUsecase(repo repository.PhishingRepository) *PhishingUsecase {
	return &PhishingUsecase{
		repo:      repo,
		generator: repository.NewPhishingMailGenerator(),
	}
}

func (uc *PhishingUsecase) GeneratePhishingMails(ctx context.Context) []map[string]interface{} {
	if uc.generator == nil {
		uc.generator = repository.NewPhishingMailGenerator()
	}
	return uc.generator.GenerateMany(15, 2)
}

func (uc *PhishingUsecase) GetMails(ctx context.Context, lvl domain.PhishingLevel) ([]domain.PhishingMail, error) {
	return uc.repo.GetMails(ctx, lvl)
}

func (uc *PhishingUsecase) SaveResult(ctx context.Context, result *domain.PhishingResult) error {
	return uc.repo.SaveResult(ctx, result)
}

// ================= PASSWORDS =================

type PasswordUsecase struct {
	repo      repository.PasswordRepository
	generator *repository.PasswordChallengeGenerator
}

func NewPasswordUsecase(repo repository.PasswordRepository) *PasswordUsecase {
	return &PasswordUsecase{
		repo:      repo,
		generator: repository.NewPasswordChallengeGenerator(),
	}
}

func (uc *PasswordUsecase) GeneratePasswordChallenges(ctx context.Context) []repository.PasswordChallenge {
	if uc.generator == nil {
		uc.generator = repository.NewPasswordChallengeGenerator()
	}
	return uc.generator.GenerateMany(15)
}

func (uc *PasswordUsecase) GetRandomChallenges(ctx context.Context, count int) ([]domain.PasswordChallenge, error) {
	return uc.repo.GetRandomChallenges(ctx, count)
}

// ================= NETWORK =================

type NetworkUsecase struct {
	repo repository.NetworkRepository
}

func NewNetworkUsecase(repo repository.NetworkRepository) *NetworkUsecase {
	return &NetworkUsecase{repo: repo}
}

func (uc *NetworkUsecase) GenerateNetworkIncidents(ctx context.Context) ([]domain.NetworkIncident, error) {
	return uc.repo.GetRandomIncidents(ctx, 15)
}

func (uc *NetworkUsecase) GetRandomIncidents(ctx context.Context, count int) ([]domain.NetworkIncident, error) {
	return uc.repo.GetRandomIncidents(ctx, count)
}

// ================= CRYPTO USECASE ===============

type CryptoUsecase struct {
	generator *repository.CryptoGenerator
}

func NewCryptoUsecase() *CryptoUsecase {
	return &CryptoUsecase{
		generator: repository.NewCryptoGenerator(),
	}
}

func (uc *CryptoUsecase) GenerateCryptoChallenges(ctx context.Context, count int, difficulty int) []domain.CryptoChallenge {
	if uc.generator == nil {
		uc.generator = repository.NewCryptoGenerator()
	}
	return uc.generator.GenerateMany(count, difficulty)
}

// ================= GAME USECASE =================

type GameUsecase struct {
	repo repository.Repository
}

func NewGameUsecase(repo repository.Repository) *GameUsecase {
	return &GameUsecase{repo: repo}
}

func (uc *GameUsecase) SaveGameResult(ctx context.Context, userID int64, gameType string, score int) error {
	result := &domain.GameResult{
		UserID:   userID,
		GameCode: gameType,
		Score:    score,
	}
	return uc.repo.SaveGameResult(ctx, result)
}

func (uc *GameUsecase) GetUserStats(ctx context.Context, userID int64) (map[string]interface{}, error) {
	moduleStats, err := uc.repo.GetModuleStats(ctx, userID)
	if err != nil {
		// Если ошибка - возвращаем нули
		moduleStats = make(map[string]domain.ModuleStat)
	}

	totalXP := 0
	for _, stat := range moduleStats {
		totalXP += stat.TotalScore
	}

	results, err := uc.repo.GetLastResults(ctx, userID, 100)
	if err != nil {
		results = []domain.GameResult{}
	}

	// Формируем модули с реальными данными
	modules := map[string]map[string]interface{}{
		"phishing":  makeModuleInfo("📧 Фишинг", moduleStats["phishing"]),
		"password":  makeModuleInfo("🔐 Пароли", moduleStats["passwords"]),
		"network":   makeModuleInfo("🌐 Сети", moduleStats["network"]),
		"crypto":    makeModuleInfo("🔑 Криптография", moduleStats["crypto"]),
		"malware":   makeModuleInfo("🦠 Вредонос", moduleStats["malware"]),
		"socialeng": makeModuleInfo("👤 Социнженерия", moduleStats["socialeng"]),
	}

	return map[string]interface{}{
		"totalScore":  totalXP,
		"gamesPlayed": len(results),
		"modules":     modules,
	}, nil
}

func makeModuleInfo(name string, stat domain.ModuleStat) map[string]interface{} {
	maxScore := 2000
	progress := 0
	if maxScore > 0 {
		progress = (stat.TotalScore * 100) / maxScore
	}
	if progress > 100 {
		progress = 100
	}

	return map[string]interface{}{
		"name":     name,
		"score":    stat.TotalScore,
		"maxScore": maxScore,
		"progress": fmt.Sprintf("%d%%", progress),
	}
}
