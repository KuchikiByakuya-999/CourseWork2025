package screens

import (
	"context"
	"cyber-skeleton/internal/domain"
	"cyber-skeleton/internal/usecase"
	"fmt"
	"image/color"
	"os"

	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/canvas"
	"fyne.io/fyne/v2/container"
	"fyne.io/fyne/v2/dialog"
	"fyne.io/fyne/v2/layout"
	"fyne.io/fyne/v2/storage"
	"fyne.io/fyne/v2/widget"
)

type ProfileScreenV2 struct {
	w          fyne.Window
	router     MainRouter
	user       *domain.User
	gameUC     *usecase.GameUsecase
	avatarPath string
}

type MainRouter interface {
	NavigateToDashboard(u *domain.User)
	NavigateToProfile(u *domain.User)
	NavigateToAuth()
}

func NewProfileScreenV2(
	w fyne.Window,
	router MainRouter,
	u *domain.User,
	gameUC *usecase.GameUsecase,
) *ProfileScreenV2 {
	return &ProfileScreenV2{
		w:          w,
		router:     router,
		user:       u,
		gameUC:     gameUC,
		avatarPath: fmt.Sprintf("/tmp/avatar_%d.jpg", u.ID),
	}
}

func (s *ProfileScreenV2) Build() fyne.CanvasObject {
	ctx := context.Background()

	stats, err := s.gameUC.GetUserStats(ctx, s.user.ID)
	if err != nil {
		stats = map[string]interface{}{
			"totalScore":  0,
			"gamesPlayed": 0,
			"modules":     map[string]map[string]interface{}{},
		}
	}

	initials := "?"
	if len(s.user.Username) >= 1 {
		initials = string(s.user.Username[0])
	}
	if len(s.user.Username) >= 2 {
		initials = string(s.user.Username[0:2])
	}

	var avatarContainer fyne.CanvasObject
	if _, err := os.Stat(s.avatarPath); err == nil {
		img := canvas.NewImageFromFile(s.avatarPath)
		img.SetMinSize(fyne.NewSize(80, 80))
		avatarContainer = img
	} else {
		primaryColor := color.NRGBA{R: 0, G: 180, B: 200, A: 255}
		avatarBg := canvas.NewCircle(primaryColor)
		avatarBg.Resize(fyne.NewSize(80, 80))
		avatarText := canvas.NewText(initials, color.White)
		avatarText.TextSize = 32
		avatarText.TextStyle = fyne.TextStyle{Bold: true}
		avatarText.Alignment = fyne.TextAlignCenter
		avatarContainer = container.NewCenter(avatarBg, avatarText)
	}

	uploadAvatarBtn := widget.NewButton("Загрузить аватар", func() {
		fd := dialog.NewFileOpen(func(reader fyne.URIReadCloser, err error) {
			if err != nil || reader == nil {
				return
			}
			data, err := os.ReadFile(reader.URI().Path())
			if err != nil {
				dialog.ShowError(err, s.w)
				return
			}
			err = os.WriteFile(s.avatarPath, data, 0644)
			if err != nil {
				dialog.ShowError(err, s.w)
				return
			}
			dialog.ShowInformation("Успешно", "Аватар загружен!", s.w)
		}, s.w)
		fd.SetFilter(storage.NewExtensionFileFilter([]string{".png", ".jpg", ".jpeg"}))
		fd.Show()
	})

	userHeader := container.NewHBox(
		container.NewMax(
			canvas.NewRectangle(color.NRGBA{R: 40, G: 45, B: 55, A: 255}),
			container.NewPadded(
				container.NewVBox(
					container.NewHBox(
						avatarContainer,
						widget.NewLabelWithStyle(
							s.user.Username,
							fyne.TextAlignLeading,
							fyne.TextStyle{Bold: true},
						),
					),
					uploadAvatarBtn,
				),
			),
		),
	)

	// ===== СТАТИСТИКА МОДУЛЕЙ (РЕАЛЬНАЯ) =====
	statsContainer := container.NewVBox(
		widget.NewLabelWithStyle("ПРОГРЕСС МОДУЛЕЙ", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
	)

	modules := stats["modules"].(map[string]map[string]interface{})
	moduleOrder := []string{"phishing", "password", "network", "crypto", "malware", "socialeng"}

	for _, key := range moduleOrder {
		mod, ok := modules[key]
		if !ok {
			continue
		}

		name := mod["name"].(string)
		score := mod["score"].(int)
		maxScore := mod["maxScore"].(int)
		progressStr := mod["progress"].(string)

		// Прогресс бар
		progressVal := float64(score) / float64(maxScore)
		if progressVal > 1.0 {
			progressVal = 1.0
		}

		successColor := color.NRGBA{R: 0, G: 200, B: 120, A: 255}
		progressBar := canvas.NewRectangle(successColor)
		progressBar.SetMinSize(fyne.NewSize(float32(progressVal*300), 6))
		progressBg := canvas.NewRectangle(color.NRGBA{R: 60, G: 65, B: 75, A: 255})
		progressBg.SetMinSize(fyne.NewSize(300, 6))
		progContainer := container.NewMax(progressBg, progressBar)

		row := container.NewVBox(
			container.NewHBox(
				widget.NewLabel(name),
				layout.NewSpacer(),
				widget.NewLabel(fmt.Sprintf("%d/%d XP (%s)", score, maxScore, progressStr)),
			),
			progContainer,
		)
		statsContainer.Add(row)
	}

	// ===== ОБЩАЯ СТАТИСТИКА =====
	totalScore := stats["totalScore"].(int)
	gamesPlayed := stats["gamesPlayed"].(int)

	summaryStats := container.NewVBox(
		widget.NewLabelWithStyle("ОБЩАЯ СТАТИСТИКА", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		container.NewHBox(
			widget.NewLabel("Всего очков:"),
			layout.NewSpacer(),
			widget.NewLabel(fmt.Sprintf("%d", totalScore)),
		),
		container.NewHBox(
			widget.NewLabel("Игр сыграно:"),
			layout.NewSpacer(),
			widget.NewLabel(fmt.Sprintf("%d", gamesPlayed)),
		),
	)

	// ===== КНОПКИ ДЕЙСТВИЯ =====
	btnBack := widget.NewButton("Назад на главную", func() {
		s.router.NavigateToDashboard(s.user)
	})

	btnLogout := widget.NewButton("Выход", func() {
		dialog.ShowConfirm(
			"Подтверждение",
			"Вы уверены, что хотите выйти?",
			func(ok bool) {
				if ok {
					s.router.NavigateToAuth()
				}
			},
			s.w,
		)
	})

	content := container.NewVBox(
		userHeader,
		widget.NewSeparator(),
		statsContainer,
		widget.NewSeparator(),
		summaryStats,
		widget.NewSeparator(),
		container.NewHBox(
			layout.NewSpacer(),
			btnBack,
			btnLogout,
		),
	)

	return container.NewScroll(content)
}
