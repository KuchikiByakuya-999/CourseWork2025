package screens

import (
	"context"
	"cyber-skeleton/internal/domain"
	"cyber-skeleton/internal/usecase"
	"fmt"
	"strings"
	"time"

	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/container"
	"fyne.io/fyne/v2/dialog"
	"fyne.io/fyne/v2/layout"
	"fyne.io/fyne/v2/widget"
)

type NetworkRouter interface {
	NavigateToDashboard(u *domain.User)
}

type NetworkScreenV2 struct {
	w             fyne.Window
	router        NetworkRouter
	uc            *usecase.NetworkUsecase
	user          *domain.User
	gameUC        *usecase.GameUsecase
	themeManager  *ThemeManager
	incidents     []domain.NetworkIncident
	cur           int
	start         time.Time
	cancel        context.CancelFunc
	score         int
	correct       int
	wrong         int
	skipped       int
	combo         int
	maxCombo      int
	timerLbl      *widget.Label
	scoreLbl      *widget.Label
	comboLbl      *widget.Label
	list          *widget.List
	typeLbl       *widget.Label
	logsContainer *fyne.Container
	showTheory    bool
}

func NewNetworkScreenV2(
	w fyne.Window,
	r NetworkRouter,
	u *domain.User,
	uc *usecase.NetworkUsecase,
	gameUC *usecase.GameUsecase,
	themeManager *ThemeManager,
) *NetworkScreenV2 {
	return &NetworkScreenV2{
		w:            w,
		router:       r,
		user:         u,
		uc:           uc,
		gameUC:       gameUC,
		themeManager: themeManager,
		showTheory:   true,
	}
}

func (s *NetworkScreenV2) showTheoryDialog() {
	theoryText := `🌐 ТЕОРИЯ: СЕТЕВЫЕ АТАКИ И ИНЦИДЕНТЫ

## Основные концепции

**Сетевой инцидент** - событие, нарушающее конфиденциальность, целостность или доступность данных

**Киберугроза** - потенциальная опасность в сети

**Киберинцидент** - реализованная атака

---

## КЛАССИФИКАЦИЯ АТАК

### 1. DDoS-АТАКИ (Distributed Denial of Service)

**Цель:** Прервать работу сервиса перегрузкой

**Типы:**

• **Volumetric (объёмные):** забивают канал огромным трафиком
  - DNS amplification: усиление через DNS-серверы (в 50-100 раз)
  - NTP reflection: отражение через NTP-серверы (в 556 раз!)
  - UDP flood: поток UDP-пакетов

• **Protocol (протокольные):** эксплуатируют слабость протоколов
  - SYN flood: забивает очередь TCP-соединений
  - Smurf attack: ICMP flood через broadcast

• **Application (приложения):** истощают ресурсы сервера
  - HTTP flood: миллионы HTTP-запросов
  - Slowloris: медленные запросы держат соединения

**Масштаб:**
- Обычная атака: 1-10 Gbps
- Средняя: 10-100 Gbps
- Крупная: 100 Gbps - 1 Tbps

**Защита:**
- WAF (Web Application Firewall)
- Rate limiting (ограничение запросов)
- CDN с DDoS-защитой (Cloudflare, Akamai)

---

### 2. ПОПЫТКИ ВЗЛОМА (Intrusion Attempts)

#### SSH Brute Force
**Что это:** перебор пароля по SSH
- Скорость: 10-100 попыток/сек
- Словари: rockyou.txt (14M паролей)

**Защита:**
- SSH-ключи вместо паролей
- 2FA (двухфакторная аутентификация)
- Fail2ban (блокировка после N неудач)

#### SQL Injection
**Что это:** манипуляция SQL-запросами
- Пример: WHERE id = '1' OR '1'='1' (всегда true)
- Последствия: утечка БД, удаление данных

**Защита:**
- Prepared Statements (параметризованные запросы)
- Input Validation (проверка ввода)

#### RCE (Remote Code Execution)
**Что это:** выполнение произвольного кода на сервере
- Последствие: полный контроль над сервером
- Примеры: Command Injection, eval(), exec()

**Защита:**
- Input Sanitization (очистка ввода)
- Least Privilege (минимум прав)
- Sandbox (изоляция процессов)

#### Path Traversal
**Что это:** доступ к файлам вне разрешённой директории
- Пример: /download?file=../../../../etc/passwd

**Защита:**
- Проверка пути (запрет ../)
- Whitelist разрешённых файлов

#### XSS (Cross-Site Scripting)
**Что это:** внедрение JavaScript в веб-страницу
- Цель: кража cookies, сессий

**Защита:**
- Экранирование HTML
- CSP (Content Security Policy)

---

### 3. УТЕЧКИ ДАННЫХ (Data Breaches)

#### Открытые сервисы
**Примеры:**
- S3 bucket без аутентификации
- MongoDB без пароля (порт 27017)
- Elasticsearch открыт всем (порт 9200)

**Защита:**
- Firewall (закрыть порты извне)
- Аутентификация везде
- Шифрование данных

#### Insider Threat (внутренняя угроза)
**Что это:** сотрудник сливает данные
- Мотив: деньги (продажа), месть, шпионаж

**Предупреждение:**
- DLP (Data Loss Prevention)
- Least Privilege (минимум прав)
- Мониторинг доступа

#### Ransomware Exfiltration
**Что это:** вредонос копирует данные перед шифрованием
- Требование: выкуп за не-публикацию

**Защита:**
- Резервные копии (3-2-1 правило)
- Антивирус + EDR

---

### 4. КОНФИГУРАЦИОННЫЕ ОШИБКИ (Misconfigurations)

#### Firewall misconfiguration
- Порт 3306 (MySQL) открыт для всех
- RDP (3389) доступен из интернета

#### Weak SSL/TLS
- Старые протоколы: SSLv3, TLS 1.0
- Слабые шифры: DES, RC4

#### Default Credentials
- admin / admin
- root / root

**Защита:** сменить при первом запуске!

---

### 5. ПРОДВИНУТЫЕ АТАКИ (Advanced)

#### APT (Advanced Persistent Threat)
**Что это:** долгосрочное проникновение для шпионажа
- Цели: госучреждения, корпорации

#### MITM (Man-in-the-Middle)
**Что это:** перехват и модификация трафика
- Техники: ARP spoofing, DNS spoofing, SSL stripping

**Защита:**
- HTTPS везде
- VPN в публичных Wi-Fi

#### DNS Tunneling
**Что это:** утечка данных через DNS-запросы
- DNS разрешён везде (порт 53)

#### Zero-Day Exploit
**Что это:** использование неизвестной уязвимости
- Патч ещё не выпущен

---

## ФАЗЫ РЕАГИРОВАНИЯ НА ИНЦИДЕНТ

### 1. DETECTION (Обнаружение)
- Анализ логов и алертов
- IDS/IPS срабатывает

### 2. CONTAINMENT (Локализация)
- Блокировка источника атаки
- Изоляция поражённых систем

### 3. ERADICATION (Уничтожение)
- Установка патчей
- Удаление вредоноса

### 4. RECOVERY (Восстановление)
- Восстановление из резервной копии
- Перезапуск сервисов

### 5. POST-INCIDENT (Выводы)
- Анализ хронологии
- Улучшение процессов

---

## ДЕЙСТВИЯ ПРИ ИНЦИДЕНТЕ

 **BLOCK:** блокировать IP/домен источника атаки

 **PATCH:** установить критический патч, закрыть уязвимость

 **ISOLATE:** отключить от сети поражённый хост

 **IGNORE:** если это false positive (ложное срабатывание)

---

## Статистика

• 60% атак - DDoS
• Средняя стоимость утечки данных: $4.45M
• Среднее время обнаружения взлома: 207 дней
• 43% атак нацелены на малый бизнес

---

 **Помните:** Безопасность - это процесс, а не продукт!`

	richText := widget.NewRichTextFromMarkdown(theoryText)
	richText.Wrapping = fyne.TextWrapWord

	scroll := container.NewVScroll(richText)
	scroll.SetMinSize(fyne.NewSize(1000, 750))

	dialog.ShowCustom(" Теория: Сетевые атаки", "Закрыть", scroll, s.w)
}

func (s *NetworkScreenV2) buildMenu() fyne.CanvasObject {

	btnTheory := widget.NewButton(" Теория: Сетевые атаки и инциденты", func() {
		s.showTheoryDialog()
	})
	btnTheory.Importance = widget.LowImportance

	btnStart := widget.NewButton("Начать игру", func() {
		s.showTheory = false
		s.w.SetContent(s.Build())
	})
	btnStart.Importance = widget.HighImportance

	btnBack := widget.NewButton("Назад в дашборд", func() {
		s.router.NavigateToDashboard(s.user)
	})

	menu := container.NewVBox(
		widget.NewLabelWithStyle("МОДУЛЬ: СЕТЕВЫЕ ИНЦИДЕНТЫ",
			fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
		widget.NewLabel(""),
		widget.NewLabel("Научитесь правильно реагировать на сетевые атаки и инциденты."),
		widget.NewLabel("Анализируйте логи и принимайте решения: блокировать, патчить, изолировать или игнорировать."),
		widget.NewLabel(""),
		widget.NewSeparator(),
		widget.NewLabel(""),
		btnTheory,
		btnStart,
		widget.NewLabel(""),
		btnBack,
	)

	return container.NewCenter(menu)
}

func (s *NetworkScreenV2) Build() fyne.CanvasObject {

	if s.showTheory {
		return s.buildMenu()
	}

	return s.buildGameScreen()
}

func (s *NetworkScreenV2) buildGameScreen() fyne.CanvasObject {
	s.timerLbl = widget.NewLabel("00:00")
	s.timerLbl.TextStyle = fyne.TextStyle{Bold: true}
	s.timerLbl.Alignment = fyne.TextAlignCenter

	s.scoreLbl = widget.NewLabel("0")
	s.scoreLbl.TextStyle = fyne.TextStyle{Bold: true}

	s.comboLbl = widget.NewLabel("0")
	s.comboLbl.TextStyle = fyne.TextStyle{Bold: true}

	s.typeLbl = widget.NewLabel("")
	s.typeLbl.TextStyle = fyne.TextStyle{Bold: true}
	s.typeLbl.Wrapping = fyne.TextWrapWord

	if s.list == nil {
		s.list = widget.NewList(
			func() int { return len(s.incidents) },
			func() fyne.CanvasObject {
				return container.NewHBox(
					widget.NewLabel("⚠️"),
					widget.NewLabel(""),
				)
			},
			func(id widget.ListItemID, o fyne.CanvasObject) {
				if id < 0 || id >= widget.ListItemID(len(s.incidents)) {
					return
				}

				inc := s.incidents[id]
				c := o.(*fyne.Container)
				title := s.incidentTitle(inc)
				c.Objects[1].(*widget.Label).SetText(title)
			},
		)
	}

	s.list.OnSelected = func(id widget.ListItemID) {
		s.cur = int(id)
		s.showIncident()
	}

	s.logsContainer = container.NewVBox()

	btnBlock := widget.NewButton("BLOCK (Блокировать IP/источник)", func() { s.answer("block") })
	btnBlock.Importance = widget.HighImportance

	btnPatch := widget.NewButton("PATCH (Установить патч)", func() { s.answer("patch") })
	btnPatch.Importance = widget.HighImportance

	btnIsolate := widget.NewButton("ISOLATE (Изолировать систему)", func() { s.answer("isolate") })
	btnIsolate.Importance = widget.HighImportance

	btnIgnore := widget.NewButton("IGNORE (Игнорировать)", func() { s.answer("ignore") })

	btnBack := widget.NewButton("Назад в меню", func() {
		if s.cancel != nil {
			s.cancel()
		}
		s.router.NavigateToDashboard(s.user)
	})

	actions := container.NewVBox(
		widget.NewLabelWithStyle("Ваше решение:", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		btnBlock,
		btnPatch,
		btnIsolate,
		btnIgnore,
		layout.NewSpacer(),
		btnBack,
	)

	topBar := container.NewHBox(
		widget.NewLabel("⏱️"),
		s.timerLbl,
		layout.NewSpacer(),
		widget.NewLabel("💰"),
		s.scoreLbl,
		widget.NewLabel("|"),
		widget.NewLabel("🔥"),
		s.comboLbl,
	)

	info := container.NewVBox(
		widget.NewLabelWithStyle("Тип инцидента:", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		s.typeLbl,
		widget.NewSeparator(),
		widget.NewLabelWithStyle("Логи инцидента:", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		s.logsContainer,
	)

	infoScroll := container.NewVScroll(info)

	right := container.NewBorder(
		topBar,
		actions,
		nil,
		nil,
		infoScroll,
	)

	split := container.NewHSplit(s.list, right)
	split.SetOffset(0.30)

	ctx := context.Background()
	incidents, err := s.uc.GenerateNetworkIncidents(ctx)
	if err != nil || len(incidents) == 0 {
		dialog.ShowError(fmt.Errorf("не удалось загрузить инциденты"), s.w)
		return split
	}

	s.incidents = incidents
	s.cur = 0
	s.list.Refresh()
	s.list.Select(0)
	s.start = time.Now()

	ctx2, cancel := context.WithCancel(context.Background())
	s.cancel = cancel
	go s.timerLoop(ctx2)

	return split
}

func (s *NetworkScreenV2) incidentTitle(inc domain.NetworkIncident) string {
	typeMap := map[string]string{
		"ddos_volumetric":               "DDoS: Volumetric Attack",
		"ddos_application":              "DDoS: Application Layer",
		"ddos_syn_flood":                "DDoS: SYN Flood",
		"ddos_ntp_amplification":        "DDoS: NTP Amplification",
		"intrusion_ssh_bruteforce":      "Взлом: SSH Brute Force",
		"intrusion_sqli":                "Взлом: SQL Injection",
		"intrusion_rce":                 "Взлом: Remote Code Execution",
		"intrusion_path_traversal":      "Взлом: Path Traversal",
		"intrusion_xss":                 "Взлом: XSS",
		"intrusion_web_shell":           "Взлом: Web Shell",
		"leak_s3_bucket":                "Утечка: S3 Bucket",
		"leak_database_dump":            "Утечка: Database Dump",
		"leak_api_keys":                 "Утечка: API Keys",
		"leak_insider_threat":           "Утечка: Insider Threat",
		"leak_ransomware_exfiltration":  "Утечка: Ransomware",
		"misconfig_firewall_open":       "Ошибка: Firewall Open",
		"misconfig_weak_ssl":            "Ошибка: Weak SSL/TLS",
		"misconfig_default_credentials": "Ошибка: Default Credentials",
		"misconfig_directory_listing":   "Ошибка: Directory Listing",
		"advanced_apt_backdoor":         "Продвинутая: APT Backdoor",
		"advanced_mitm_ssl_strip":       "Продвинутая: MITM SSL Strip",
		"advanced_dns_tunneling":        "Продвинутая: DNS Tunneling",
		"advanced_zero_day_exploit":     "Продвинутая: Zero-Day",
		"false_positive_scanner":        "False Positive: Scanner",
		"false_positive_backup":         "False Positive: Backup",
		"false_positive_monitoring":     "False Positive: Monitoring",
		"malware_cryptominer":           "Вредонос: Cryptominer",
		"privilege_escalation":          "Взлом: Privilege Escalation",
		"data_exfiltration_ftp":         "Утечка: FTP Exfiltration",
		"lateral_movement_smb":          "Продвинутая: Lateral Movement",
		"command_and_control_beacon":    "Продвинутая: C2 Beacon",
	}

	if title, ok := typeMap[inc.Type]; ok {
		return title
	}
	return "Неизвестный инцидент"
}

func (s *NetworkScreenV2) showIncident() {
	if len(s.incidents) == 0 || s.cur < 0 || s.cur >= len(s.incidents) {
		return
	}

	inc := s.incidents[s.cur]
	s.typeLbl.SetText(s.incidentTitle(inc))

	s.logsContainer.Objects = nil
	for _, log := range inc.Logs {
		lbl := widget.NewLabel(log)
		lbl.Wrapping = fyne.TextWrapWord

		if strings.Contains(log, "[CRITICAL]") || strings.Contains(log, "[ALERT]") {
			lbl.TextStyle = fyne.TextStyle{Bold: true}
		}

		s.logsContainer.Add(lbl)
	}
	s.logsContainer.Refresh()
}

func (s *NetworkScreenV2) answer(action string) {
	if len(s.incidents) == 0 {
		return
	}

	inc := s.incidents[s.cur]
	correct := inc.Action == action

	if correct {
		s.correct++
		s.combo++
		if s.combo > s.maxCombo {
			s.maxCombo = s.combo
		}
		s.score += 50 + (s.combo * 5)
	} else {
		s.wrong++
		s.combo = 0
		s.score -= 20
		if s.score < 0 {
			s.score = 0
		}
	}

	s.scoreLbl.SetText(fmt.Sprintf("%d", s.score))
	s.comboLbl.SetText(fmt.Sprintf("%d", s.combo))

	s.showExplanation(inc, action, correct)

	if s.cur+1 < len(s.incidents) {
		s.cur++
		s.list.Select(s.cur)
	} else {
		s.finish()
	}
}

func (s *NetworkScreenV2) showExplanation(inc domain.NetworkIncident, userAction string, correct bool) {
	status := "Неверное решение"
	if correct {
		status = " Правильное решение"
	}

	actionNames := map[string]string{
		"block":   "BLOCK (блокировка)",
		"patch":   "PATCH (патч)",
		"isolate": "SOLATE (изоляция)",
		"ignore":  "IGNORE (игнорирование)",
	}

	txt := fmt.Sprintf(`%s

Ваш ответ: %s
 Правильный ответ: %s

Пояснение:
%s`,
		status,
		actionNames[userAction],
		actionNames[inc.Action],
		s.getIncidentExplanation(inc))

	dialog.ShowInformation("Разбор инцидента", txt, s.w)
}

func (s *NetworkScreenV2) getIncidentExplanation(inc domain.NetworkIncident) string {
	explanations := map[string]string{
		"block":   "Нужно заблокировать источник атаки (IP-адрес, домен) через firewall или WAF.",
		"patch":   "Необходимо установить патч безопасности или исправить конфигурацию.",
		"isolate": "Систему нужно изолировать от сети, чтобы предотвратить распространение.",
		"ignore":  "Это ложное срабатывание (false positive), реальной угрозы нет.",
	}

	return explanations[inc.Action]
}

func (s *NetworkScreenV2) timerLoop(ctx context.Context) {
	ticker := time.NewTicker(time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			el := time.Since(s.start).Truncate(time.Second)
			min := int(el.Minutes())
			sec := int(el.Seconds()) % 60
			s.timerLbl.SetText(fmt.Sprintf("%02d:%02d", min, sec))
		}
	}
}

func (s *NetworkScreenV2) finish() {
	if s.cancel != nil {
		s.cancel()
	}

	summary := fmt.Sprintf(`📊 МОДУЛЬ: СЕТЕВЫЕ ИНЦИДЕНТЫ - ЗАВЕРШЁН

 Правильных решений: %d
Ошибок: %d
Пропущено: %d
Макс. комбо: %d
Время: %s
Итоговые очки: %d

Помните: быстрая реакция на инциденты критически важна!`,
		s.correct, s.wrong, s.skipped, s.maxCombo,
		time.Since(s.start).Truncate(time.Second), s.score)

	dialog.ShowInformation("Игра окончена", summary, s.w)
	s.router.NavigateToDashboard(s.user)
}
