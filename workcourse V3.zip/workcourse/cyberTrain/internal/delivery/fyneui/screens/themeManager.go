package screens

import (
	"image/color"
)

type ThemeName string

const (
	ThemeDark  ThemeName = "dark"
	ThemeNeon  ThemeName = "neon"
	ThemeLight ThemeName = "light"
)

type ThemePalette struct {
	Background color.Color
	Surface    color.Color
	Primary    color.Color
	Secondary  color.Color
	Success    color.Color
	Danger     color.Color
	Border     color.Color
}

type ThemeManager struct {
	CurrentTheme ThemeName
}

func NewThemeManager() *ThemeManager {
	return &ThemeManager{CurrentTheme: ThemeDark}
}

func (t *ThemeManager) SetTheme(name ThemeName) {
	t.CurrentTheme = name
}

func (t *ThemeManager) GetCurrentTheme() ThemePalette {
	switch t.CurrentTheme {
	case ThemeNeon:
		return ThemePalette{
			Background: color.NRGBA{R: 8, G: 10, B: 24, A: 255},
			Surface:    color.NRGBA{R: 18, G: 20, B: 40, A: 255},
			Primary:    color.NRGBA{R: 0, G: 220, B: 255, A: 255},
			Secondary:  color.NRGBA{R: 150, G: 100, B: 255, A: 255},
			Success:    color.NRGBA{R: 0, G: 200, B: 120, A: 255},
			Danger:     color.NRGBA{R: 255, G: 60, B: 90, A: 255},
			Border:     color.NRGBA{R: 60, G: 70, B: 90, A: 255},
		}
	case ThemeLight:
		return ThemePalette{
			Background: color.NRGBA{R: 240, G: 240, B: 245, A: 255},
			Surface:    color.NRGBA{R: 255, G: 255, B: 255, A: 255},
			Primary:    color.NRGBA{R: 0, G: 120, B: 215, A: 255},
			Secondary:  color.NRGBA{R: 108, G: 117, B: 125, A: 255},
			Success:    color.NRGBA{R: 0, G: 180, B: 80, A: 255},
			Danger:     color.NRGBA{R: 220, G: 53, B: 69, A: 255},
			Border:     color.NRGBA{R: 210, G: 210, B: 220, A: 255},
		}
	default:
		return ThemePalette{
			Background: color.NRGBA{R: 18, G: 20, B: 28, A: 255},
			Surface:    color.NRGBA{R: 30, G: 34, B: 46, A: 255},
			Primary:    color.NRGBA{R: 0, G: 180, B: 200, A: 255},
			Secondary:  color.NRGBA{R: 108, G: 117, B: 125, A: 255},
			Success:    color.NRGBA{R: 0, G: 200, B: 120, A: 255},
			Danger:     color.NRGBA{R: 255, G: 70, B: 85, A: 255},
			Border:     color.NRGBA{R: 50, G: 55, B: 70, A: 255},
		}
	}
}
