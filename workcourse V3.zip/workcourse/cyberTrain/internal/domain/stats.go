package domain

import "time"

type ModuleStat struct {
	GameCode   string
	Attempts   int
	BestScore  int
	LastScore  int
	TotalScore int
	LastPlayed time.Time
}
